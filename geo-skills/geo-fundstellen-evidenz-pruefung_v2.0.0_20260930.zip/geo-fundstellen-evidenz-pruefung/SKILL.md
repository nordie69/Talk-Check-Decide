---
name: geo-fundstellen-evidenz-pruefung
description: >
  Prueft ein fertiges geologisches Fundstellendokument (Tabelle, Exkursionsbericht, Katalog, Bibliographie) gegen die Regeln aus geo-fundstellen-evidenzregeln: Fundstellenidentitaet, Regions- statt Punktangaben, Belegbindung, Literaturkategorien, Markerkonsistenz. Ausgabe: Pruefbericht als Markdown mit Befunden nach Schweregrad, Korrekturvorschlag und Freigabeempfehlung. Triggern bei: Fundstellendokument pruefen, Exkursionsbericht auditieren, stimmen die Fundortangaben, Evidenzpruefung, Fundstellenliste reviewen, vor Veroeffentlichung pruefen. NICHT fuer die Recherche selbst.
metadata:
  version: "2.0.0"
---

# Evidenzprüfung für Fundstellendokumente

Geprüft wird, ob jede Aussage über eine Fundstelle trägt. Nicht geprüft werden Stil, Gliederung oder Vollständigkeit im Sinne von Umfang: ein knappes Dokument mit belegten Angaben besteht, ein umfangreiches mit ungedeckten fällt durch.

Zuerst `geo-fundstellen-evidenzregeln` lesen. Dieser Skill wendet jene Regeln an und wiederholt sie nicht.

## Eingabe

Ein Dokument beliebiger Form: Ergebnistabelle aus `geo-fundort-datenbank-recherche`, Exkursionsbericht, Geotopliste, Fundstellenkatalog, Bibliographie, auch Fließtext. Mehrere Fundstellen werden einzeln geprüft, höchstens 6 je Durchlauf.

Liegen die zugrunde liegenden Quellen nicht vor, wird gegen das geprüft, was im Dokument steht, und jede Angabe, deren Beleg nicht nachvollziehbar ist, als solche vermerkt. Stichproben per Websuche sind erlaubt und erwünscht, aber auf die strittigen Punkte zu beschränken.

## Prüfschritte

### P1 Identität

Ist erkennbar, welches Objekt gemeint ist? Prüfen: Koordinaten vorhanden und plausibel zur Ortsangabe, Name mit Quellenschreibweise abgeglichen, Hierarchieebene der Fundstelle und nicht der Gemeinde, Mehrfachörtlichkeit benannt, Eingabekorrekturen dokumentiert.

Typischer Befund: eine Fundstelle wird über die Gemeinde geführt, obwohl ein eigener Eintrag existiert.

### P2 Ebenenvermischung

Für jede Zahl, Liste, Collection und Fundangabe prüfen, von welcher räumlichen Ebene sie stammt. Warnzeichen: runde Gesamtzahlen ohne Ebenenangabe, Artenlisten, die für eine kleine Fundstelle auffällig lang sind, Quellen, deren Titel eine Region nennt, während die Angabe einem Punkt zugeschrieben wird.

Das ist der schwerste Befundtyp, weil er sachlich falsche Aussagen erzeugt, die niemandem auffallen.

### P3 Belegbindung der Nachweise

Sind Fossil- und Mineralnennungen an Belegstücke gebunden? Inventarnummer, Status (Holotyp, Typuslokalität, referiertes Exemplar, Sammelfund), und bei Arten mit geänderter Zuordnung beide Namen mit Jahr der Umstellung. Prüfen, ob genannte Taxa noch gültig sind; bei bekannten Revisionen nachschlagen.

### P4 Literatur

Jede Referenz einer Kategorie zuordnen und prüfen, ob die Zuordnung trägt: Steht A-Literatur wirklich zur Fundstelle oder nur zur Region? Ist der Begutachtungsstatus dort gekennzeichnet, wo er unklar ist? Sind DOI oder stabile URL vorhanden, und lösen sie auf den angegebenen Titel auf? Stichprobe von zwei bis drei DOIs je Dokument genügt, bei Auffälligkeiten mehr.

Erfundene oder falsch zugeordnete DOIs sind stets ein kritischer Befund.

### P5 Marker und Negativbefunde

Werden `OFFEN`, `UNKLAR` und `---` konsistent und im richtigen Sinn verwendet? Häufigster Fehler: ein sachliches Nichtvorkommen steht als OFFEN, oder eine ungeprüfte Lücke steht als `---`. Prüfen, ob Negativbefunde mit Suchweg dokumentiert sind.

### P6 Rückführbarkeit

Gibt es Angaben, die zu genau wirken für ihre Quelle? Koordinaten mit mehr Stellen als die Quelle, Artenzahlen ohne Ebenenangabe, Jahreszahlen und Seitenzahlen ohne Beleg. Prüfen, ob nicht verifizierbare Annahmen als Annahmen gekennzeichnet sind.

## Befundklassen

- **KRITISCH**: Aussage ist sachlich falsch oder nicht gedeckt und wirkt belegt. Dazu zählen Ebenenvermischung, erfundene oder falsch zugeordnete DOIs, Verwechslung der Fundstelle, ungültige Taxonnamen ohne Hinweis.
- **LÜCKE**: Angabe fehlt, wo sie notwendig ist, etwa Koordinaten, Belegstück, Kategoriezuordnung, Begründung eines Negativbefunds.
- **UNSCHARF**: Angabe trägt, ist aber nicht rückführbar oder zu grob, etwa Quelle ohne Ebenenangabe, Marker uneindeutig verwendet.
- **HINWEIS**: Verbesserung ohne Fehlerwirkung, etwa fehlende taxonomische Historie bei stabiler Zuordnung.

## Ausgabe

Markdown-Datei `fundstellen-evidenzpruefung_<YYYY-MM-DD>.md`, danach mit `present_files` ausgeben. Aufbau:

```markdown
# Evidenzprüfung

Geprüftes Dokument: <Titel oder Dateiname> | Datum: <Datum> | Fundstellen: <n>
Ergebnis: <Freigabe / Freigabe nach Korrektur / keine Freigabe>

## Befunde

| Nr | Fundstelle | Prüfschritt | Klasse | Befund | Korrekturvorschlag |
|---|---|---|---|---|---|

## Geprüft und unauffällig

Kurze Aufzählung, was kontrolliert wurde und trägt, damit der Umfang der Prüfung erkennbar ist.

## Nicht prüfbar

Angaben, deren Beleg aus dieser Umgebung nicht erreichbar war, mit Grund.
```

Der Korrekturvorschlag ist konkret und umsetzbar: nicht "Quelle prüfen", sondern "Mineralienzahl stammt von der Regionsseite Osnabrück, als solche kennzeichnen oder auf die zwei für den Fundpunkt belegten Arten reduzieren".

## Freigaberegel

- **Freigabe**: kein KRITISCH, höchstens vereinzelte UNSCHARF.
- **Freigabe nach Korrektur**: kein KRITISCH, aber LÜCKEN vorhanden.
- **Keine Freigabe**: mindestens ein KRITISCH.

Ein einziger ungedeckter DOI oder eine Ebenenvermischung genügt für die Verweigerung, weil solche Fehler sich in Folgedokumente fortpflanzen und dort nicht mehr auffallen.

## Pflichtregeln

1. Jeder Befund nennt die Stelle im Dokument und die Regel, gegen die verstoßen wird.
2. Keine stillschweigende Korrektur am Dokument; dieser Skill prüft, er schreibt nicht um.
3. Kein Befund ohne Nachweis. Vermutungen werden als HINWEIS geführt, nicht als KRITISCH.
4. Was nicht prüfbar war, steht im Abschnitt "Nicht prüfbar" und wird nicht als Fehler gewertet.
5. Keine Em-Dashes im Dokument; Kommata, Doppelpunkte oder neue Sätze verwenden.
