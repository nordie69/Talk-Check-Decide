---
name: geo-fundort-datenbank-recherche
description: >
  Sucht geologische Fundorte (Steinbrüche, Halden, Aufschlüsse, Mineral- und Fossilfundstellen, Geotope) per Name, Koordinaten oder Fundortbeschreibung in Mindat, Mineralienatlas und Paleobiology Database (paleobiodb.org) und liefert pro Fundort die ID-basierten Links als Markdown-Tabelle mit DB-Koordinaten, Land/Region, Fundstellentyp und Anzahl der Fossil-Collections. Nur exakte Treffer, sonst OFFEN oder UNKLAR. Ausgabe als .md-Datei. Immer verwenden bei: "Fundort in Mindat suchen", "Mindat-Link", "Mineralienatlas-Link", "PBDB-Link", "paleobiodb", "Fundstelle verlinken", "Datenbanklinks für Fundorte", "Fundortrecherche", "Locality ID ermitteln", "Fossilfundstelle nachschlagen". Auch triggern wenn eine Liste von Steinbrüchen, Halden, Aufschlüssen oder Geotopen (Text, Tabelle, CSV, Excel, mit oder ohne Koordinaten) eingegeben wird und Datenbankverweise gewünscht sind, etwa für Exkursionsberichte oder Sammelreisen. NICHT für die geologische Beschreibung selbst, dafür geo-excursion-report.
metadata:
  version: "2.0.0"
---

# Fundort-Datenbank-Recherche (Mindat, Mineralienatlas, PaleobioDB)

## Aufgabe

Für jeden eingegebenen Fundort ermittelst du, ob er in **Mindat**, **Mineralienatlas** und **Paleobiology Database (PBDB)** als eigener Eintrag existiert, und lieferst pro Datenbank den kanonischen Link (ID-basiert, damit er stabil bleibt). Dazu kommen die in der Datenbank hinterlegten Koordinaten, Land/Region, der Fundstellentyp und die Anzahl der PBDB-Collections. Die Zahl der gelisteten Mineralarten wird bewusst nicht erhoben: sie steht nur selten im Suchergebnis-Snippet, lässt sich ohne Mindat-API-Token nicht verlässlich belegen, und der verlinkte Eintrag zeigt die Liste ohnehin vollständig.

Es zählt nur der **exakte Treffer**: der Eintrag muss dieselbe Fundstelle bezeichnen, nicht die Gemeinde, nicht den Landkreis, nicht ein Nachbarbruch. Wird kein exakter Treffer gefunden, steht in der Zelle `OFFEN`. Ein Treffer, der wahrscheinlich, aber nicht sicher derselbe Ort ist, wird als `UNKLAR` markiert und im Kommentar begründet.

Ausgabe ist **immer eine Markdown-Datei** (kein Chat-Text als Ergebnis), keine Em-Dashes im Dokument.

## Wichtigste technische Randbedingung

Alle drei Seiten blockieren den direkten Seitenabruf per `web_fetch` (Bot-Erkennung), auch die PBDB-Daten-API unter `/data1.2/`. Das gilt für Mindat-Locality-Seiten, Mineralienatlas-Lexikonseiten und PBDB-Collection-Seiten gleichermaßen. Versuche es trotzdem einmal pro Sitzung mit einer gefundenen URL; scheitert der Abruf, wiederhole ihn nicht.

Die Recherche läuft daher **vollständig über `web_search`**. Die Snippets der Suchergebnisse enthalten bei richtiger Suchformulierung genau die benötigten Metadaten:

- Mindat-Locality-Seiten liefern im Snippet `Latitude & Longitude (decimal): 52.48009,13.80125`, `Type: Group of Quarries (Active)`, `Mindat Locality ID: 8739`, `Name(s) in local language(s): ...`. Diese Angaben erscheinen, wenn die Suchanfrage diese Begriffe enthält (siehe Suchmuster).
- PBDB-Collection-Seiten liefern im Snippet `Where: Brandenburg, Germany (52.5° N, 13.8° E: paleocoordinates ...)`, `When: ...`, die Collection-Nummer und die Primärreferenz.
- Mineralienatlas-Seiten liefern im Snippet den hierarchischen Pfad (`Deutschland/Brandenburg/Märkisch-Oderland, Landkreis/Rüdersdorf bei Berlin/Kalksteinbruch`) und in der URL die `lokationid`.

Läuft der Skill in Claude Code oder einer Umgebung, in der `curl` gegen paleobiodb.org erlaubt ist, kann für PBDB zusätzlich die API genutzt werden: `https://paleobiodb.org/data1.2/colls/list.json?coll_match=<Name>&cc=DE&show=loc` bzw. eine Bounding-Box mit `lngmin,lngmax,latmin,latmax`. Das ist optional; die Snippet-Strategie bleibt der Standardweg.

## Eingabe

Akzeptiert werden, einzeln oder als Liste:

- Fundortname mit oder ohne Region (`Kalksteinbruch Rüdersdorf`, `Steinbruch Hummelberg, Kaiserstuhl`)
- Dezimal- oder Grad-Koordinaten (`52.4801, 13.8012` oder `52°28'48"N 13°48'04"E`)
- Freitext-Fundortbeschreibung (`aufgelassener Basaltbruch 2 km NW von Ortenberg, Vogelsberg`)
- Tabellen, CSV oder Excel mit einer Spalte Name und optional Koordinaten und ID. Excel und CSV mit pandas einlesen; jede Zeile ist ein Fundort. Vorhandene Objekt-IDs des Nutzers werden in der Ausgabe mitgeführt.

Enthält eine Eingabe nur Koordinaten, wird zuerst per Websuche die nächstgelegene Ortsbezeichnung und ein möglicher Fundstellenname ermittelt (Suche mit den Dezimalkoordinaten plus `Steinbruch` oder `mindat`). Danach läuft die Recherche wie bei einer Namenseingabe; der exakte Treffer ist dann zusätzlich an eine Koordinatendistanz von höchstens 1 km gebunden.

**Maximal 8 Fundorte pro Durchlauf.** Jeder Fundort braucht 4 bis 7 Suchanfragen. Bei mehr Fundorten: die ersten 8 bearbeiten, Datei ausgeben, dann fragen, ob die nächsten 8 folgen sollen. Die Nummerierung wird fortgesetzt.

## Recherche-Algorithmus pro Fundort

Alle Schritte durchlaufen, bevor irgendeine Zelle auf `OFFEN` gesetzt wird. Ein vorzeitiges `OFFEN` ist ein Qualitätsfehler.

### Schritt 1: Normalisieren

Aus der Eingabe ableiten: Kernname (z. B. `Rüdersdorf`), Objekttyp (Steinbruch, Halde, Grube, Aufschluss, Tongrube, Kiesgrube, Bergwerk, Geotop), Region (Bundesland, Landkreis, Land) und, wenn vorhanden, Koordinaten. Englische Typbezeichnung mitführen, weil Mindat englisch benennt: `quarry`, `quarries`, `mine`, `dump`, `pit`, `outcrop`, `clay pit`, `gravel pit`.

### Schritt 2: Mindat

1. `web_search`: `mindat <Kernname> <Objekttyp englisch> <Region>` (z. B. `mindat Rüdersdorf limestone quarries Brandenburg`)
2. `web_search`: `mindat.org <Kernname> Latitude Longitude decimal Mindat Locality ID valid minerals` (diese Formulierung zieht das Metadaten-Snippet der Locality-Seite; `valid minerals` dient nur als Ankertext für das Snippet, die Zahl selbst wird nicht ausgewertet)
3. Nur URLs der Form `https://www.mindat.org/loc-<ID>.html` zählen. Ignorieren: `locentry-`, `min-`, `photo-`, `article`, Galerie- und Forenseiten.
4. Unter mehreren `loc-`-Treffern den **spezifischsten** wählen, der die Fundstelle selbst bezeichnet. Ein Eintrag der Gemeinde oder Region (`Rüdersdorf, Märkisch-Oderland, ...` statt `Limestone quarries, Rüdersdorf ...`) ist kein exakter Treffer; er wird nur im Kommentar als übergeordneter Eintrag genannt, nicht verlinkt.
5. Aus dem Snippet übernehmen: Locality ID, Dezimalkoordinaten, `Type`, Land/Region aus dem Seitentitel (Mindat-Titel sind hierarchisch: `Fundstelle, Ort, Landkreis, Bundesland, Land`). Fehlt eine Angabe im Snippet, ein drittes Mal mit `mindat loc-<ID>` plus dem fehlenden Begriff suchen; danach `UNKLAR`.
6. Hinweis nutzen: Mindat-Seiten enthalten oft den Satz `There are N fossil localities from the PaleoBioDB database within this region`. Das ist ein Signal für Schritt 4, ersetzt aber keinen PBDB-Treffer.

Link-Form: `https://www.mindat.org/loc-<ID>.html`. Das ist die Fundstellenseite selbst. Unterseiten derselben Fundstelle (`locentry-`, `maps.php`, `locentries.php`, `paleo_loc.php`) sind keine Ersatzlinks; sie gehören allenfalls in den Kommentar.

### Schritt 3: Mineralienatlas

Der Mineralienatlas benennt Fundstellen häufig anders als Mindat und anders, als der Nutzer sie kennt. Eine Suche mit dem erwarteten Objekttyp geht deshalb regelmäßig ins Leere, obwohl die Fundstelle vorhanden ist. Maßgeblich ist nicht der vermutete Name, sondern die Trefferliste der hauseigenen Lokationssuche.

1. **Zuerst der Kernname allein**, ohne Objekttyp und ohne Region: `web_search`: `mineralienatlas Lokationen <Kernname>` oder `mineralienatlas lexikon <Kernname> Fundort`. Die Lokationssuche des Lexikons gibt einen Block `Lokationen: "<Suchbegriff>"` aus, in dem jede Zeile einen vollständigen Hierarchiepfad zeigt. Diese Liste ist die verlässlichste Auskunft darüber, was der Mineralienatlas führt.
2. `web_search`: `mineralienatlas <Kernname> <Objekttyp deutsch>` (z. B. `mineralienatlas Rüdersdorf Kalksteinbruch`)
3. `web_search`: `mineralienatlas lexikon <Bundesland> <Landkreis> <Kernname>`
4. **Namensvarianten durchprobieren, bevor `OFFEN` gesetzt wird.** Der Mineralienatlas übernimmt oft die Bezeichnung amtlicher Verzeichnisse statt der landläufigen. Zu testen sind: der Name aus dem Geotopkataster des jeweiligen Landesamts (in Bayern der UmweltAtlas, dort etwa `Sammlersteinbruch am Blumenberg` statt `Fossiliensteinbruch Blumenberg`), der deutsche Mindat-Name, der historische Name aus dem Mindat-Feld `Other/historical names`, sowie die üblichen Wortbildungen `Steinbruch am <Name>`, `Sammlersteinbruch`, `Grube`, `Bruch`, `Halde`.

**Ebenen unterscheiden.** In der Trefferliste steht derselbe Name oft mehrfach auf verschiedenen Hierarchiestufen, etwa `.../Eichstätt/Blumenberg` als Ortsteil und darunter `.../Blumenberg/Sammlersteinbruch am Blumenberg` als Fundstelle. Die Ortsebene ist kein Treffer, auch wenn sie exakt so heißt wie die gesuchte Fundstelle. Es gilt immer die tiefste Ebene, die eine Fundstelle bezeichnet. Erscheinen unter einem Ortsteil mehrere Unterlokationen (Museum, Steinbruch, Halde), wird die gewählt, die dem gesuchten Objekttyp entspricht; ein Museum ist nie die Fundstelle.

Die Suffixe in der Trefferliste (`, Ortsteil`, `, Kreisstadt`, `, Landkreis`, `, Bezirk`) sind **Bestandteil des Pfades und werden mitgeführt**. Sie sehen wie Typbezeichnungen der Anzeige aus, gehören aber zum Seitennamen: der Pfad lautet `.../Eichstätt, Landkreis/Eichstätt, Kreisstadt/Blumenberg, Ortsteil/Sammlersteinbruch am Blumenberg`. Wird ein Suffix weggelassen, antwortet der Mineralienatlas mit `Page ... does not exist`.

**Pfadlinks werden wörtlich übernommen, nie rekonstruiert.** Der Pfad wird Zeichen für Zeichen aus der Trefferliste oder dem Suchergebnis kopiert; verändert wird ausschließlich die Kodierung von Leerzeichen zu `%20` und gegebenenfalls der Umlaute. Nichts wird gekürzt, ergänzt oder normalisiert, auch dann nicht, wenn eine Ebene überflüssig wirkt. Verschiedene Zweige des Lexikons benennen dieselbe Verwaltungsebene unterschiedlich (`Eichstätt` in einem Zweig, `Eichstätt, Kreisstadt` in einem anderen); aus einem bekannten Pfad darf deshalb nicht auf einen anderen geschlossen werden.

5. Gültige Treffer sind Lexikon-URLs unter `mineralienatlas.de/lexikon/index.php/...`. Die `lokationid` steht entweder direkt in der URL (`?lokationid=350`, `LokationGeo?l=350`) oder muss aus einer Unterseite (Bilder, MediaDataShow) desselben Fundorts übernommen werden.
6. Aus Snippet und Pfad übernehmen: Land/Region (aus dem Pfad), Fundstellentyp (aus dem Fundstellennamen). Koordinaten stehen bei Mineralienatlas selten im Snippet; wenn nicht, aus Mindat übernehmen und als solche kennzeichnen.

**Belege des Nutzers.** Legt der Nutzer eine Trefferliste vor (Bildschirmfoto der Lokationssuche, kopierter Pfad), gilt sie als Beleg wie ein Suchergebnis: Existenz und Hierarchiestufe der Fundstelle sind damit nachgewiesen. Eine `lokationid` ist damit aber nicht belegt; fehlt sie, wird der Pfadlink verwendet und im Kommentar vermerkt, dass die ID nicht belegt ist.

Link-Form, Rangfolge:

1. **ID-basierter Direktlink (Vorzug)**: `https://www.mineralienatlas.de/?l=<lokationid>&lang=de`. Er löst direkt die Fundstellenseite auf, ist kurz und umlautfest.
2. **Pfadlink (nur wenn keine lokationid belegt ist)**: `https://www.mineralienatlas.de/lexikon/index.php/<Land>/<Bundesland>/<Landkreis>/<Ort>/<Fundstelle>` (Leerzeichen als `%20`, Kommas bleiben). Umlaute im Pfad werden von der Suchmaschine oft fehlerhaft kodiert; vor der Übernahme prüfen, dass keine Ersatzzeichen (`%EF%BF%BD`) enthalten sind.

`LokationGeo`, `LokationMineralBilder`, `LokationMineralData` und `MediaDataShow` sind Unterseiten (Karte, Bilder, einzelnes Mineral). Sie dienen nur als Beleg für die `lokationid` und werden nicht als Hauptlink eingetragen.

**Reichweite der Suchmaschine.** Fundstellenseiten des Mineralienatlas sind oft schlecht indexiert, weil die Inhalte per JavaScript nachgeladen werden. Ein Negativbefund aus `web_search` beweist deshalb nicht, dass die Fundstelle fehlt. Vor einem `OFFEN` müssen Schritt 1 und Schritt 4 durchlaufen sein, und im Kommentar wird vermerkt, dass die Suche über Snippets lief und die hauseigene Lokationssuche ergiebiger sein kann.

### Schritt 4: PaleobioDB

PBDB ist collection-basiert: eine Fundstelle hat oft mehrere Collections (je Schicht, Publikation oder Aufsammlung). Exakter Treffer sind alle Collections, deren Name oder `Where`-Angabe die Fundstelle selbst benennt.

1. `web_search`: `"PBDB Collection" <Kernname> <Land englisch>` (z. B. `"PBDB Collection" Rüdersdorf Germany`)
2. `web_search`: `paleobiodb <Kernname> collection <Formation oder Stratigraphie, falls bekannt>`
3. Gültige Treffer: URLs mit `collection_no=<Nr>` (`classic/basicCollectionSearch?collection_no=` oder `classic/displayCollResults?collection_no=`). Sie erscheinen auch unter Spiegel-Domains (`training.paleobiodb.org`, `taphonomy.doit.wisc.edu`); die Collection-Nummer ist dieselbe, der Link wird auf `paleobiodb.org` normalisiert.
4. Aus dem Snippet übernehmen: Koordinaten aus `Where: ... (52.5° N, 13.8° E ...)` (eine Dezimalstelle, PBDB rundet), Land/Region, Alter aus `When:`.
5. Bis zu 5 Collection-Nummern in einer Zelle, getrennt durch ` | `. Bei mehr als 5: die 5 mit dem präzisesten Namen plus Hinweis `+N weitere` im Kommentar.
6. Kein Treffer trotz Schritt 1 bis 2: einmal mit dem englischen oder lateinischen Ortsnamen und dem Formationsnamen suchen.
7. **Fossilgestützte Suche (Pflicht, bevor `OFFEN` gesetzt wird).** Häufig ist die Fundstelle in PBDB vorhanden, ohne dass eine Collection-Seite als Suchtreffer erscheint. Zwei Indizien dafür: Mindat führt eine Fossilseite `paleo_loc.php?id=<Nr>` mit dem Fundstellennamen (Mindat spiegelt ausschließlich PBDB-Daten), oder eine PBDB-Taxonseite nennt die Fundstelle als Typuslokalität. Dann über ein an der Fundstelle belegtes Leitfossil weitersuchen:
   - Leitfossil bestimmen: die Art, die in den bisherigen Snippets namentlich mit der Fundstelle verknüpft ist (Typuslokalität, bekanntes Fossil der Schicht). Ohne einen solchen Beleg keine Art erfinden und keine aus dem Gedächtnis wählen.
   - `web_search`: `paleobiodb <Gattung Art> collection <Kernname>` und, falls nötig, `paleobiodb basicTaxonInfo <Gattung Art> type locality collection`.
   - Die PBDB-Taxonseite (`classic/basicTaxonInfo?taxon_no=<Nr>`) nennt die Typuslokalität im Klartext und verlinkt sie auf die Collection; erscheint in einem Snippet dazu eine `collection_no`, ist sie damit belegt und wird eingetragen.
   - Fällt in dieser Runde eine Collection-Nummer an, gilt sie nur, wenn Fundstellenname oder `Where`-Angabe im selben Snippet zur gesuchten Fundstelle passen. Eine Nummer, die nur über die Art verknüpft ist, ohne Ortsbezug im Snippet, wird nicht eingetragen.
8. Bleibt danach jede Nummer unbelegt, gilt: ist die Fundstelle in PBDB nachweislich vorhanden (Indiz aus Schritt 7), dann `UNKLAR` mit Nennung des Belegs im Kommentar, nicht `OFFEN`. Findet sich auch kein solches Indiz, dann `OFFEN`.

Link-Form, je Collection **zwei Adressen**, getrennt durch ` / `, in dieser Reihenfolge:

1. `https://paleobiodb.org/navigator/#/?coll_id=<Nr>` (Oberfläche, zeigt die Collection auf der Karte)
2. `https://paleobiodb.org/data1.2/colls/single.txt?id=<Nr>&show=loc,stratext,ref` (Daten-API, lesbare Tabelle; `single.json` für die Weiterverarbeitung)

Beide Formen sind praktisch geprüft und laden. Der Grund, warum sie funktionieren und die Classic-Seiten nicht: Aufrufe unter `/classic/` gelten der PBDB als direkte Datenbankabfragen und laufen in eine Firewall, die wegen massenhaften Scrapings scharf gestellt ist; auch der früher empfohlene Parameter `is_real_user=1` hebt das nicht zuverlässig auf. Der Navigator lädt dagegen zuerst die reguläre Oberfläche und holt die Daten anschließend über die öffentliche Schnittstelle nach, die ihrerseits direkt unter `/data1.2/` erreichbar ist.

**Keine Links auf `/classic/`.** Weder `basicCollectionSearch` noch `displayCollResults` noch `basicTaxonInfo` werden eingetragen, auch nicht mit Parameter. Suchergebnisse liefern fast nur diese Adressen; aus ihnen wird die Collection-Nummer entnommen und in die beiden Formen oben eingesetzt. Das ist erlaubt, weil belegt sein muss die Nummer, nicht die Parameterkette.

Wird im Kommentar auf ein Taxon verwiesen, etwa bei einer Typuslokalität, gilt derselbe Weg über den Navigator: `https://paleobiodb.org/navigator/#/?taxon_name=<Gattung%20Art>`, bei bekannter Taxon-ID `?taxon_id=<Nr>`.

Kommt eine Collection nur über eine Spiegel-Domain (`training.paleobiodb.org`, `taphonomy.doit.wisc.edu`) im Suchergebnis vor, wird die Nummer übernommen und auf `paleobiodb.org` normalisiert.

**Prüfbarkeit.** Aus diesem Werkzeug heraus lässt sich keine PBDB-Adresse abrufen: `/classic/` blockt automatisierte Zugriffe, `/data1.2/` ist per robots.txt gesperrt, und der Navigator wertet seine Parameter erst im Browser aus. Linkformen können hier also nicht getestet werden; die beiden oben stehen, weil sie im Browser geprüft wurden. Meldet jemand einen Fehler, wird die Form gewechselt und nicht verteidigt.

Ergebnislisten (`displayCollResults?...`), Regionssuchen und Taxonseiten (`basicTaxonInfo?...`) sind keine Fundstellenlinks und werden nie in die Zeile PaleobioDB eingetragen. Die Taxonseite darf als Beleg im Kommentar genannt werden, wenn sie die Fundstelle als Typuslokalität ausweist.

### Schritt 4b: Inhaltslisten der Fundstelle

Mindat und Mineralienatlas führen auf ihren Fundstellenseiten bis zu vier Bestandslisten, die den Fundort inhaltlich beschreiben. Sie werden übernommen, weil sie die eigentliche Sachauskunft der Datenbanken sind:

| Zeile | Mindat | Mineralienatlas |
|---|---|---|
| Mineralien | `Mineral List` | Mineralienliste des Fundortes |
| Gesteine | `Rock Type Records` | Gesteine der Lokation |
| Fossilien | `Fossils` (aus PBDB gespiegelt) | Fossilliste, Fossilbilder |
| Formationen | `Formations` | stratigraphische Angabe im Fundorttext |

Vorgehen: je Fundort ein bis zwei zusätzliche Suchen mit dem Fundstellennamen plus `mineral list`, `rock types`, `fossils`, `formations` oder deutsch `Mineralienliste`, `Gesteine`, `Fossilien`. Die Listen erscheinen in Snippets oft nur teilweise; übernommen wird, was belegt ist, ergänzt um `(Auszug)`, wenn erkennbar unvollständig. Namen werden in der Schreibweise der Datenbank geführt, deutsch wenn beide Sprachen belegt sind. Herkunft je Eintragsblock in Klammern angeben (`Mindat`, `Mineralienatlas`, `PBDB`), weil die Listen sich unterscheiden und die Abweichung selbst aussagekräftig ist.

Keine Liste erfinden und keine aus dem Gedächtnis ergänzen: was in keinem Snippet stand, fehlt. Ist eine Liste auf der Seite vorhanden, aber im Snippet nicht sichtbar, steht `UNKLAR`; führt die Datenbank für diesen Fundort erkennbar keine solche Liste, steht `---`.

### Schritt 5: Abgleich und Status

- **Koordinatenprüfung**: liegen Eingabekoordinaten vor, muss der Datenbanktreffer innerhalb von 1 km liegen (Mindat, Mineralienatlas) bzw. 5 km (PBDB, wegen Rundung auf eine Dezimalstelle). Sonst `UNKLAR` mit Distanzangabe im Kommentar.
- **Namensprüfung**: Fundstellenname und Region müssen übereinstimmen; Übersetzungen (`Kalksteinbruch` / `Limestone quarries`) sind gleichwertig.
- **Status je Fundort**: `vollständig` (alle drei DBs exakt), `teilweise` (mindestens eine DB exakt), `offen` (keine DB exakt).
- Weichen die Koordinaten der Datenbanken untereinander um mehr als 500 m ab, im Kommentar nennen.

### Schritt 6: Literaturrecherche

Läuft erst, wenn die Schritte 1 bis 5 für den Fundort abgeschlossen sind. Grund: die Suchbegriffe für die Literatur stammen aus den dort gesicherten Angaben, nicht aus der Eingabe des Nutzers. Ohne diese Basis wird die Recherche unscharf und liefert Arbeiten zur Region statt zur Fundstelle.

**Vorbedingung.** Mindestens eine Datenbank muss einen exakten Treffer geliefert haben (Status `vollständig` oder `teilweise`). Ist der Status `offen`, wird keine Literaturliste erstellt; stattdessen steht im Literaturabschnitt ein Satz, dass die Fundstelle nicht eindeutig bestimmt war und eine gezielte Literatursuche darum nicht belastbar ist.

**Suchbegriffe aus den gesicherten Angaben bilden.** Zu verwenden sind: der Fundstellenname in allen belegten Schreibweisen (deutsch, englisch, historisch), Ort und Landkreis, die stratigraphische Einheit aus PBDB oder Mindat (Formation, Member, Stufe), sowie die an der Fundstelle belegten Leitfossilien oder Minerale. Beispiel für eine Kombination: `"Piesberg" Osnabrück Westphalian flora taphonomy`. Begriffe, die nicht aus den vorherigen Schritten stammen, werden nicht erfunden.

**Zugelassene Publikationstypen.** Ausschließlich peer-reviewed: Artikel in begutachteten Fachzeitschriften, Kapitel in begutachteten Buchreihen, sowie Preprints auf Servern wie arXiv, bioRxiv, EarthArXiv oder Zenodo **nur dann**, wenn im Suchergebnis eine begutachtete Fassung nachgewiesen ist; die Zitation nennt dann die begutachtete Fassung, nicht den Preprint. Ausgeschlossen sind: Tagungsabstracts, Dissertationen und Diplomarbeiten, Exkursionsführer, Vereinsmitteilungen und Sammlerzeitschriften ohne Begutachtung, Behördenberichte, Wikipedia, Datenbankeinträge und Webseiten. Ist bei einer regionalen Zeitschrift die Begutachtung nicht belegbar, wird der Eintrag aufgenommen und mit `[Begutachtung UNKLAR]` gekennzeichnet, statt ihn stillschweigend als peer-reviewed auszugeben.

**Zwei Kategorien.** Die Literatur wird in zwei getrennte Listen geschrieben, weil beide Arten von Arbeiten gebraucht werden, aber unterschiedlich viel über die Fundstelle aussagen:

- **A, Fundstellenliteratur.** Die Fundstelle ist Gegenstand: sie steht im Titel oder Abstract, oder die Arbeit beschreibt, bildet ab oder analysiert Material, Profile oder Grabungen von dort. Auch eine Revision, die ein einzelnes Stück von der Fundstelle behandelt, gehört hierher.
- **B, Regionale Grundlagenliteratur.** Die Fundstelle wird nicht selbst untersucht, aber die Arbeit liefert den Rahmen, ohne den ihre Daten nicht einzuordnen sind: Lithostratigraphie und Gliederung der Formation, Biostratigraphie und Ammonitenhorizonte, Sedimentologie und Diagenese des Gesteins, Faziesmodell des Ablagerungsraums, Faunenübersichten der Region. Erkennbar sind solche Arbeiten meist daran, dass die Titel aus Kategorie A sie durchgehend zitieren.

- **C, Praktische Fundortquellen.** Nicht begutachtete Quellen mit konkretem Ortsbezug: Geotopsteckbriefe der Landesämter, Sammleratlanten und Fundstellenführer, Portale und Tourismusseiten des Betreibers oder der Region, Museums- und Besuchersteinbruchseiten, regionale Fossilien- und Mineralienportale. Sie liefern, was die Fachliteratur nicht enthält: Zugang und Genehmigung, Öffnungszeiten und Gebühren, Werkzeugverleih, welche Schicht gerade aufgeschlossen ist, Wegbeschreibung, Fundhäufigkeiten. Genau diese Quellen tauchen in den Referenzlisten von Mindat und Mineralienatlas auf.

Kategorie C wird nie mit A oder B vermischt; die Trennung der Zeilenkennungen leistet die Einordnung, ein zusätzlicher Hinweistext ist nicht nötig. Ein DOI ist hier nicht zu erwarten; eingetragen wird die stabile URL. Jahr und Herausgeber werden genannt, soweit belegt, sonst `o. J.`. Kommerzielle Verkaufs- und Reiseangebote gehören nicht dazu, ebenso wenig Foren- und Blogbeiträge ohne institutionellen Träger.

- **D, Exkursionsführer.** Literatur, die dazu gedacht ist, jemanden ins Gelände zu führen: Exkursionsführer und Exkursionsberichte, Geoführer und geologische Wanderführer, Fossil- und Mineralsammelführer, Aufschlussbeschreibungen mit Anfahrt und Routenverlauf, Geopark- und Geotoproutenführer, Lehrpfad- und Fossilienpfadbeschreibungen. Form und Träger sind gleichgültig: begutachteter Exkursionsbeitrag einer geologischen Vereinigung, Buch, Behördenpublikation oder Webseite. Aufgenommen wird, was die Fundstelle oder ihre engere Region als Exkursionsziel behandelt, mit Angaben zu Aufschluss, Route oder Sammelmöglichkeit.

Kategorie D überschneidet sich absichtlich mit A bis C: dieselbe Arbeit kann A sein, wenn sie die Fundstelle wissenschaftlich beschreibt, und zugleich D, wenn sie sie als Exkursionspunkt führt. Sie wird dann in beiden Zeilen genannt, in D mit dem Exkursionsbezug im Rollensatz. Rein touristische Seiten ohne geologischen Inhalt gehören nicht nach D, sondern nach C.

Ausgeschlossen bleibt, was in keine der vier Kategorien fällt: Arbeiten, die die Fundstelle oder die Region nur in einer Aufzählung streifen, und Übersichten ohne eigenen Bezug zum Ablagerungsraum. Die Zuordnung wird nie geraten: Kategorie A braucht einen Beleg, dass Material oder Profile von der Fundstelle behandelt werden. Fehlt dieser Beleg, gehört die Arbeit nach B, auch wenn sie thematisch nah wirkt.

**Umfang.** Kategorie A: 5 bis 10 Einträge. Kategorie B: 2 bis 5 Einträge. Kategorie C: bis zu 6 Einträge, ohne Untergrenze. Kategorie D: bis zu 6 Einträge, ohne Untergrenze. Werden in A weniger als 5 gefunden, die den Filter bestehen, wird die kürzere Liste ausgegeben und darunter vermerkt, wie viele Suchen gelaufen sind; aufgefüllt wird nicht, insbesondere nicht mit Titeln aus B. Bleibt B leer, entfällt die Überschrift.

**Suchbudget.** Getrennt geführt, damit eine Kategorie die andere nicht aushungert:

| Zweck | Suchen |
|---|---|
| Kategorie A | mindestens 4, höchstens 8 |
| Kategorie B | höchstens 6 |
| Zitationsernte (siehe unten) | höchstens 4 |
| Kategorie D | höchstens 5 |
| Vervollständigung einer bereits gefundenen Referenz | 2 je Eintrag, zählen nicht auf die übrigen Budgets |

Die Vervollständigungssuchen sind der Grund, warum eine Referenz nicht mehr an fehlenden Autorennamen oder einem fehlenden DOI scheitern muss. Sobald ein Titel den Relevanzfilter besteht, aber die bibliographischen Angaben unvollständig sind, wird gezielt nachgesucht: Titel in Anführungszeichen plus `authors`, plus `doi`, oder der Titel auf einer Verlags-, Crossref- oder Repositoriumsseite. Erst wenn auch das nichts bringt, greifen die Marker `[Autoren nicht belegt]` oder `[kein DOI belegt]`.

**Suchvorgehen Kategorie A:**

1. `web_search`: `<Fundstellenname> <Ort> <stratigraphische Einheit>` plus einem Fachbegriff wie `stratigraphy`, `palaeontology`, `taphonomy`, `mineralogy`
2. `web_search`: `<Fundstellenname> <Leitfossil oder Mineral> doi`
3. `web_search`: `<Fundstellenname> site:doi.org` oder `<Fundstellenname> crossref journal article`
4. `web_search` auf Verlags- und Aggregatorseiten aus den bisherigen Treffern (Springer, Wiley, Elsevier, Taylor und Francis, GeoScienceWorld, PeerJ, PLOS, PMC, DOAJ, BioOne, Schweizerbart, Acta Palaeontologica Polonica, Palaeontologia Electronica)
5. Bei Bedarf in der Sprache der Fundstelle wiederholen, weil deutsche Fundstellen häufig in deutschsprachigen begutachteten Zeitschriften bearbeitet sind

**Suchvorgehen Kategorie D:** Gesucht wird mit Gattungsbegriffen statt mit Fachbegriffen, in beiden Sprachen: `Exkursionsführer <Region>`, `Geoführer <Region>`, `geologischer Wanderführer <Region>`, `Exkursion <Fundstelle> Aufschluss`, `Fossilien sammeln <Region> Führer`, `field trip guide <Formation>`, `Geotop Route <Region>`, `Fossilienpfad <Ort>`. Zwei ergiebige Sonderquellen: die Literaturliste im Geotopsteckbrief des Landesamts, die regelmäßig Exkursionsführer nennt, und die Exkursionsbände regionaler geologischer Vereinigungen, deren Beiträge oft einen DOI oder eine stabile Verlagsseite haben. Ein Reihentitel allein genügt nicht; der Band muss die Fundstelle oder ihre engere Region abdecken.

**Suchvorgehen Kategorie B:** Suchbegriffe sind die stratigraphische Einheit, das Becken oder der Ablagerungsraum und die Region, nicht der Fundstellenname: `<Formation> <Region> lithostratigraphy doi`, `<Formation> biostratigraphy ammonite zones`, `<Ablagerungsraum> sedimentology diagenesis facies`. Ebenso zählen die Arbeiten, die in den Treffern aus A wiederholt als Grundlage zitiert werden; deren Vollzitat wird über eine Vervollständigungssuche geholt.

**Zitationsernte.** Die Datenbanken und die bereits gefundenen Arbeiten führen selbst Literatur, und diese Angaben sind oft präziser als jede Volltextsuche. Auszuwerten sind:

- die Referenzliste der Mindat-Fundstellenseite (Abschnitt `References`, erscheint bei gezielter Suche im Snippet, etwa `<Fundstellenname> mindat references`)
- die Literaturangaben der Mineralienatlas-Fundstellenseite
- die Referenzliste der Mineralienatlas-Fossilseite zu einem an der Fundstelle belegten Taxon (`FossilData?fossil=<Gattung+Art>`). Sie spiegelt die PBDB-Literatur und führt die Erstbeschreibungen mit vollständigem Zitat, oft samt historischer Arbeiten, die über Volltextsuchen nicht auffindbar sind. Das ist bei Fundstellen mit Typuslokalitätsstatus der ergiebigste Kanal
- die Primärreferenz jeder PBDB-Collection sowie die Referenz auf der PBDB-Taxonseite, wenn die Fundstelle Typuslokalität ist
- die im Volltext oder Snippet sichtbaren Zitate der Arbeiten aus Kategorie A, besonders wiederkehrende Namen; das ist der übliche Weg zur Kategorie B

Was die Ernte ergeben hat, gehört in die Zeile Kommentar der Ergebnistabelle, nicht in einen eigenen Abschnitt: ein Satz je Datenbank, ob sie Literatur führt und was daraus verwertbar war. Ein Negativbefund wird ebenso vermerkt, weil er einem späteren Bearbeiter die Wiederholung erspart. Aus diesen Quellen stammen zunächst nur Kandidaten, keine Einträge. Jeder Kandidat durchläuft dieselbe Prüfung wie ein Suchtreffer: Publikationstyp, Kategoriezuordnung, vollständige bibliographische Angaben, DOI-Beleg. Ein Titel, der nur in einer Referenzliste steht und sonst nirgends auffindbar ist, wird nicht aufgenommen. Ältere Titel aus Mindat-Referenzlisten sind oft Bestimmungsbücher, Sammleratlanten oder Betreiberseiten; sie gehören nach C, nicht nach A oder B, und werden nicht verworfen. Historische Erstbeschreibungen in Akademieschriften des 19. Jahrhunderts gehören dagegen nach A, tragen aber `[Begutachtung UNKLAR]`, weil ein Begutachtungsverfahren für diese Reihen nicht belegbar ist.

**DOI-Pflicht und Belegregel.** Jeder Eintrag braucht einen aktiven Link der Form `https://doi.org/<DOI>`. Der DOI muss in einem Suchergebnis dieser Sitzung wörtlich vorgekommen sein. DOIs werden **niemals** aus dem Gedächtnis ergänzt, aus Mustern anderer Artikel derselben Zeitschrift abgeleitet oder geraten; ein erfundener DOI ist ein schwerer Fehler, weil er wie ein gültiger Beleg aussieht. Findet sich zu einer sonst passenden Arbeit kein DOI, wird sie mit dem Vermerk `[kein DOI belegt]` und, falls vorhanden, einer stabilen Verlags- oder Repositoriums-URL aufgenommen. Wo möglich, wird ein DOI durch einen zweiten Treffer bestätigt; weichen zwei Quellen voneinander ab, gilt die Verlagsseite.

**Zitierstil.** Harvard, je Eintrag eine Zeile, deutsche Umlaute erhalten:

`Nachname, A. und Nachname, B. (Jahr) 'Titel des Aufsatzes', Zeitschrift, Band(Heft), S. Anfang-Ende. https://doi.org/<DOI>`

Regeln dazu: bis drei Autoren alle nennen, ab vier `Erstautor et al.`; Zeitschriftenname ausgeschrieben; bei Buchkapiteln `in: Herausgeber (Hrsg.) Buchtitel. Ort: Verlag, S. x-y`. Hinter jedem Eintrag steht in einer eigenen Zeile ein Satz, was die Arbeit für diese Fundstelle leistet (Profilbeschreibung, Erstbeschreibung eines Taxons, geochemische Analyse, Revision). Dieser Satz wird aus dem Snippet gebildet, nicht aus Vorwissen, und bleibt unter 25 Wörtern.

## Linkgenauigkeit

Ein Link ist nur dann brauchbar, wenn er beim Anklicken die Fundstelle selbst zeigt. Zwei Fehler sind dabei zu vermeiden, und sie sind verschieden:

- **Zu grob (falsche Ebene)**: der Link zeigt Gemeinde, Landkreis, Berg als Ganzes, Bergrevier oder ein Suchergebnis mit vielen Fundstellen. Das ist kein Treffer, sondern gehört als Hinweis in den Kommentar.
- **Zu eng (falscher Seitentyp)**: der Link zeigt zwar die richtige Fundstelle, aber nur einen Ausschnitt davon, etwa ein einzelnes Mineral, eine Fotogalerie, eine Kartenansicht oder eine Fossil-Collection statt der Fundstellenseite. Solche Unterseiten belegen die ID, ersetzen aber den Hauptlink nicht.

Gewählt wird immer die tiefste Hierarchieebene, die noch die gesamte Fundstelle bezeichnet, und davon die Übersichtsseite:

| Datenbank | Hauptlink (eintragen) | Nur Beleg, nicht eintragen | Kein Treffer |
|---|---|---|---|
| Mindat | `mindat.org/loc-<ID>.html` der Fundstelle | `locentry-`, `min-`, `maps.php`, `locentries.php`, `paleo_loc.php`, `paleo_collection.php` | `loc-<ID>` von Gemeinde oder Region, `feature-` |
| Mineralienatlas | `mineralienatlas.de/?l=<lokationid>&lang=de`, ersatzweise der Lexikon-Pfadlink | `LokationGeo`, `LokationMineralBilder`, `LokationMineralData`, `MediaDataShow` | Lokation der Gemeinde oder des Landkreises |
| PaleobioDB | Adresspaar je Collection: `navigator/#/?coll_id=<Nr>` und `data1.2/colls/single.txt?id=<Nr>`; für Taxa im Kommentar `navigator/#/?taxon_name=` | Mindat-Spiegelseiten der Collections | alles unter `/classic/`, Regionssuchen |

Bei PBDB ist die Collection die feinste vorhandene Ebene; dort gibt es keine Fundstellen-Übersichtsseite, deshalb werden mehrere Collection-Links nebeneinander eingetragen. Existiert für eine Fundstelle sowohl ein enger als auch ein breiter Eintrag derselben Datenbank (etwa ein Bruch und die zugehörige Gemeinde), zählt ausschließlich der enge.

## Ausgabeformat

Datei: `fundort-db-links_<YYYY-MM-DD>.md` in `/mnt/user-data/outputs/`, danach mit `present_files` ausgeben. Bei Fortsetzungsläufen dieselbe Datei erweitern, Nummerierung fortsetzen.

Struktur der Datei, immer genau so:

```markdown
# Fundort-Datenbank-Recherche

Stand: <Datum> | Fundorte: <n> | Datenbanken: Mindat, Mineralienatlas, PaleobioDB
Treffermodus: nur exakte Treffer, sonst OFFEN. Metadaten aus Suchergebnis-Snippets, kein direkter Seitenabruf möglich.

## Ergebnistabelle

| Merkmal | Fundort 1 | Fundort 2 |
|---|---|---|
| Nr | 1 | 2 |
| ID (Eingabe) |  |  |
| Fundort (Eingabe) |  |  |
| Fundstelle (DB-Name) |  |  |
| Land / Region |  |  |
| Typ |  |  |
| Koordinaten (DB) |  |  |
| Karte (Google Maps) |  |  |
| Karte (OpenTopoMap) |  |  |
| Mindat |  |  |
| Mineralienatlas |  |  |
| PaleobioDB |  |  |
| PBDB-Collections |  |  |
| Status |  |  |
| Kommentar |  |  |
| Mineralien |  |  |
| Gesteine |  |  |
| Fossilien |  |  |
| Formationen |  |  |
| A. Fundstellenliteratur |  |  |
| B. Regionale Grundlagenliteratur |  |  |
| C. Praktische Fundortquellen |  |  |
| D. Exkursionsführer |  |  |

```

Die Ergebnistabelle ist transponiert: die 15 Merkmale stehen als Zeilen, jeder Fundort bekommt eine eigene Spalte. Die Kopfzeile lautet `| Merkmal | <Fundort 1> | <Fundort 2> | ... |`, wobei als Spaltenüberschrift der Eingabename in Kurzform steht (erste 30 Zeichen genügen), damit die Spalten unterscheidbar bleiben.

**Höchstens 4 Fundorte je Tabelle.** Bei 5 bis 8 Fundorten mehrere Tabellenblöcke untereinander anlegen, jeweils mit eigener Überschrift `### Fundorte 1 bis 4`, `### Fundorte 5 bis 8`. Breite Tabellen sind sonst nicht mehr lesbar, und genau dafür ist das transponierte Format gedacht.

Die Merkmale erscheinen immer in der oben gezeigten Reihenfolge, auch wenn eine Zeile für alle Fundorte leer bliebe; die feste Reihenfolge macht Fundorte spaltenweise vergleichbar. Die Datei enthält die Ergebnistabelle und darunter den Literaturteil, sonst nichts: keine Legende und kein Recherche-Protokoll.

Die Literatur steht **in derselben Tabelle**, nicht in einem eigenen Abschnitt. Sie belegt genau vier Zeilen, benannt nach den Kategorien: `A. Fundstellenliteratur`, `B. Regionale Grundlagenliteratur`, `C. Praktische Fundortquellen`, `D. Exkursionsführer`. In der jeweiligen Zelle steht die vollständige Liste dieser Kategorie.

Innerhalb einer Zelle trennt `<br><br>` die Einträge, also eine Leerzeile, damit die Titel optisch auseinanderfallen. Nummeriert wird nicht. Jeder Eintrag enthält hintereinander: das Harvard-Zitat, den DOI-Link oder die stabile URL, und nach einem Punkt die Rolle der Arbeit für die Fundstelle in einem kurzen Satz. Aufbau der Zelle:

```
Nachname, A. und Nachname, B. (Jahr) 'Titel', Zeitschrift, Band(Heft), S. 12-34. https://doi.org/10.xxxx/xxxxx Was die Arbeit für die Fundstelle leistet.<br><br>Nachname, C. (Jahr) ...
```

Bleibt eine Kategorie leer, steht in der Zelle `---`; die Zeile selbst entfällt nur, wenn sie für alle Fundorte leer wäre.

### Zeilendefinitionen

Marker in jeder Zelle: `OFFEN` heißt kein exakter Treffer nach vollständigem Recherche-Algorithmus, `UNKLAR` heißt Treffer oder Wert wahrscheinlich, aber nicht belegbar (Begründung gehört dann in den Kommentar), `---` heißt nicht anwendbar.


- **Nr**: laufende Nummer in Eingabereihenfolge
- **ID (Eingabe)**: Objekt-ID des Nutzers, sonst `---`
- **Fundort (Eingabe)**: Eingabe wörtlich, einzeilig
- **Fundstelle (DB-Name)**: Name des exakten Treffers, bevorzugt in der Schreibweise von Mindat (`Name(s) in local language(s)` falls vorhanden, sonst der englische Titel)
- **Land / Region**: `Land, Bundesland, Landkreis` aus dem Mindat-Titel oder dem Mineralienatlas-Pfad
- **Typ**: Fundstellentyp aus Mindat `Type:` ins Deutsche übertragen (`Steinbruchgruppe (aktiv)`, `Bergwerk (aufgelassen)`, `Aufschluss`, `Halde`, `Grube`); fehlt die Angabe, aus dem Namen ableiten und mit `(abgeleitet)` kennzeichnen
- **Koordinaten (DB)**: Dezimalgrad, 5 Stellen, `Breite, Länge`, Quelle in Klammern (`52.48009, 13.80125 (Mindat)`). Vorrang: Mindat vor Mineralienatlas vor PBDB. Keine Koordinaten in den Snippets: `UNKLAR`
- **Karte (Google Maps)**: `https://www.google.com/maps?q=<Breite>,<Länge>` aus der Zeile Koordinaten (DB); ohne Koordinaten `---`
- **Karte (OpenTopoMap)**: `https://opentopomap.org/#map=16/<Breite>/<Länge>`, gleiche Koordinaten, Trennzeichen ist der Schrägstrich, kein Komma. Zoomstufe 16 zeigt einen Steinbruch oder Aufschluss formatfüllend; bei sehr großen Fundstellen (Tagebaue, Bruchgruppen) 15 verwenden, bei punktförmigen Aufschlüssen 17. OpenTopoMap ergänzt Google Maps, weil sie Höhenlinien, Geländeschummerung und Abbaukanten zeigt, was für die Geländeplanung meist aussagekräftiger ist als das Satellitenbild. Ohne Koordinaten `---`
- **Mindat**: genau ein Link, `https://www.mindat.org/loc-<ID>.html` der Fundstelle, oder `OFFEN` / `UNKLAR`
- **Mineralienatlas**: genau ein Link nach der Rangfolge aus Schritt 3, oder `OFFEN` / `UNKLAR`
- **PaleobioDB**: bis zu 5 Collections, je Collection das Adresspaar aus Schritt 4 (Navigator-Link ` / ` API-Link), die Collections untereinander getrennt durch ` | ` (maskiert), oder `OFFEN` / `UNKLAR`
- **PBDB-Collections**: Anzahl exakt zugeordneter Collections, bei Abschneiden `5 (+3)`
- **Status**: `vollständig` / `teilweise` / `offen`
- **Mineralien, Gesteine, Fossilien, Formationen**: die Bestandslisten nach Schritt 4b, je Zelle eine durch Komma getrennte Aufzählung, Quelle in Klammern. Bei mehreren Quellen die Blöcke durch `<br>` trennen. Nicht belegt: `UNKLAR`, nicht vorhanden: `---`
- **A. Fundstellenliteratur, B. Regionale Grundlagenliteratur, C. Praktische Fundortquellen, D. Exkursionsführer**: je Zelle die Liste der Kategorie nach Schritt 6, ohne Nummerierung, Einträge durch `<br><br>` getrennt. Nicht belegte Angaben tragen die Marker `[kein DOI belegt]`, `[Autoren nicht belegt]` oder `[Begutachtung UNKLAR]`. Leere Kategorie: `---`
- **Kommentar**: kurz, sachlich. Enthält: Begründung für UNKLAR, übergeordnete Einträge (z. B. `Mindat führt nur Gemeindeeintrag loc-287013`), Koordinatenabweichungen, Alter/Stratigraphie aus PBDB `When:`, Zugangshinweise aus Mindat nur, wenn sie im Snippet stehen. Keine Empfehlungen zu Sammelgenehmigungen oder Behördenkontakten.

## Pflichtregeln

1. Reihenfolge der Tabellenspalten entspricht exakt der Eingabereihenfolge; jeder Fundort erzeugt genau eine Spalte, jedes Merkmal genau eine Zeile.
2. Nur Links eintragen, deren URL (oder deren ID) in einem Suchergebnis dieser Sitzung tatsächlich vorkam. Keine IDs raten, keine Links aus dem Gedächtnis. Erlaubt ist, eine belegte ID in die kanonische Linkform der jeweiligen Datenbank einzusetzen und dabei technisch nötige Parameter wie `is_real_user=1` zu ergänzen.
3. `OFFEN` erst nach vollständigem Algorithmus (alle Suchanfragen des jeweiligen Schritts).
4. Übergeordnete Einträge (Gemeinde, Landkreis, Bergrevier) sind kein Treffer. Sie gehören in den Kommentar, nicht in die Link-Spalte.
5. Alle Zellen einzeilig im Quelltext, keine echten Zeilenumbrüche; Mehrfachinhalte werden mit `<br>` getrennt. Pipe-Zeichen innerhalb einer Zelle (Trenner bei Mehrfachlinks) als `\|` maskieren, sonst bricht die Tabelle.
6. Metadaten nur aus Snippets oder erfolgreich abgerufenen Seiten. Zahlen und Koordinaten nie schätzen; fehlt die Angabe, `UNKLAR`.
7. Keine Em-Dashes im Dokument; Kommata, Doppelpunkte oder neue Sätze verwenden.
8. Kein DOI und keine Referenz ohne Beleg aus einem Suchergebnis dieser Sitzung. Lieber eine kürzere Literaturliste als ein erfundener Nachweis.
9. Im Chat nach der Dateiausgabe höchstens zwei Sätze: Anzahl vollständig / teilweise / offen und, falls Fundorte übrig sind, die Frage nach der Fortsetzung.

## Beispiel (eine Spalte)

Eingabe: `Kalksteinbruch Rüdersdorf`

| Merkmal | Kalksteinbruch Rüdersdorf |
|---|---|
| Nr | 1 |
| ID (Eingabe) | --- |
| Fundort (Eingabe) | Kalksteinbruch Rüdersdorf |
| Fundstelle (DB-Name) | Kalkbrüche, Rüdersdorf bei Berlin |
| Land / Region | Deutschland, Brandenburg, Märkisch-Oderland |
| Typ | Steinbruchgruppe (aktiv) |
| Koordinaten (DB) | 52.48009, 13.80125 (Mindat) |
| Karte (Google Maps) | https://www.google.com/maps?q=52.48009,13.80125 |
| Karte (OpenTopoMap) | https://opentopomap.org/#map=15/52.48009/13.80125 |
| Mindat | https://www.mindat.org/loc-8739.html |
| Mineralienatlas | https://www.mineralienatlas.de/?l=350&lang=de |
| PaleobioDB | UNKLAR |
| PBDB-Collections | 0 |
| Status | teilweise |
| Kommentar | Mindat: Gemeindeeintrag loc-287013 verweist auf 17 PBDB-Fundstellen in der Region, keine Collection mit Rüdersdorf im Namen gefunden. |

Die Werte dieses Beispiels stammen aus einer realen Testsuche; sie zeigen die erwartete Granularität, nicht Wissen, das ohne Suche in die Tabelle darf.
