# Consistency checklist

Run `python scripts/check_report.py Report.md` (prints findings) and then review these by hand:

1. Coordinates: Table 1 == chapter heading line == Google Maps link parameters; no two localities share
   coordinates; DMS conversions correct (deg + min/60 + sec/3600).
2. Names: identical in Table 1, chapter heading, Table 2, figure key lists, chart labels
   (renamed museums: keep "formerly ..." once in the text).
3. Ages: Table 1, Table 2, chapter text, Fig. 3 labels; ranges old to young; ICS vs national chart stated;
   long-lived processes (vein formation) given as stage range, not invented Ma numbers.
4. Types: Table 1 type column == symbol category in all figures (museum, quarry/sand pit, mine dump,
   show mine, track site, geotope). Museums excluded from Table 2 and Fig. 3.
5. Citations: every in-text key resolves to a reference; every reference is cited or is a Table 1
   homepage; letter suffixes (2026 a/b, n.d. a/b) consistent; DOIs linked.
6. Numbering: Table 1 No. == chapter 2.x; figures continuous; no "[to be assigned]" left; image paths
   exist; only Table 1 and Table 2 remain as tables.
7. Contested points appear as contested everywhere (text, synthesis, abstract).
8. Abstract promises match content (photos, themes count).
9. No em/en dashes; "stop"/"POI" not used; British spelling.
10. Companion research file (internal) may use old numbering; do not distribute it.

Report findings as: number, what conflicts where, effect on the reader, recommended fix. Ask before
changing content; fix mechanical issues directly.
