# Geological Excursion Report: [Theme], [Country]

**Excursion period:** [d to d Month yyyy]  
**Conducted and written by:** [Name, degrees]  
**Date of report:** [Month yyyy]

---

## Abstract

[100 to 150 words: period, number of localities, types, time span, regions, verification against peer-reviewed literature, formal lithostratigraphy, coordinates and websites, synthesis themes.]

---

## 1. Introduction and Itinerary

### 1.1 Introduction

[Scope, regions, geological provinces covered.]

### 1.2 Selection of the localities and preparation

[How the list was compiled: sources, AI assistants used, decision by the author, later verification.]

### 1.3 Itinerary

The localities are numbered and described in the order in which they were visited along the driven route from [dates] (Table 1). [Start city], the start and end point of the tour, is listed as point 0 with the city hall as reference location. The route and the localities are shown in Fig. 1.

Stage ages follow the ICS International Chronostratigraphic Chart [year]; [if applicable: the stratigraphic overview in section 1.5 uses the boundary ages of [national chart], which differ from the ICS values by up to [x] Ma]. Coordinates are given in decimal degrees (WGS 84) and link to Google Maps.

**Table 1.** Itinerary of the excursion in route order, with locality type, geological unit, age, website and coordinates.

| No. | Locality | Type | Geological unit | Age | Website | Coordinates (WGS 84) |
|---|---|---|---|---|---|---|
| 0 | [Start city] (start and end point of the tour) | Reference point: city hall | not applicable | not applicable | not applicable | [lat, lon](https://www.google.com/maps?q=lat,lon) |
| 1 | ... | ... | ... | ... | https://... | [lat, lon](https://www.google.com/maps?q=lat,lon) |

![Fig. 1. Route map of the excursion](images/00_route_map_v1.png)

**Fig. 1.** Route map of the excursion: [start] (0) and the [n] localities in route order, classified by type (quarry or sand pit, mine dump, historic show mine, dinosaur track site, geotope, museum), with insets for [clusters]. Coordinates as in Table 1 (WGS 84); boundaries and rivers from the GSHHG and WDBII datasets.

### 1.4 Geological overview map

Fig. 2 places the localities on a geological overview map of [country].

![Fig. 2. Localities on the geological overview map](images/00_geological_map_localities_v1.png)

**Fig. 2.** Localities of the excursion on the geological overview map of [country]: [start] (0) and the [n] localities in route order, classified by type as in the route map, with insets drawn in the style of the route map. The localities were georeferenced to the base map by a second order polynomial transformation fitted to [k] control points (mean residual about [x] px, maximum [y] px). [Edits to the base map.] Base map: [source (year)].

### 1.5 Stratigraphic position of the collecting localities

![Fig. 3. Stratigraphic overview of the field localities](images/00_stratigraphic_overview_v1.png)

**Fig. 3.** Stratigraphic overview of the [n] field localities on a linear time scale from 0 to [t] Ma, showing era, period and epoch. Boundary ages follow [chart]; locality ages as in Table 2. [Long-lived processes shown as delimited vertical lines at the right margin.]

Fig. 3 and Table 2 place the [n] field localities where finds were made (quarries, mine dumps, track sites and geotopes) on the geological time scale, from youngest at the top to oldest at the bottom, as is customary for stratigraphic tables. Museums are not listed.

**Table 2.** Stratigraphic position of the [n] field localities, youngest at the top.

| Period | Epoch and stage | Age (Ma) | Locality | Lithostratigraphic unit | Typical finds |
|---|---|---|---|---|---|
| ... | ... | ... | Name (No.) | ... | ... |

## 2. Localities

### 2.1 [Locality name, place]

**Coordinates:** [lat, lon](https://www.google.com/maps?q=lat,lon)  
**Region:** [Region (State)]

#### 2.1.1 Geological background

[About 150 words with Harvard citations: setting, formal unit, stage and age, genesis, key fossils or minerals, history, significance, contested points.]

#### 2.1.2 Finds

[Typical finds sentence with citation.]

[PHOTO: `images/01_shortname_01.jpg`]

**Fig. 4.** [Locality]: [specimen; description].

#### 2.1.3 Field notes

[Weather, access, productive spots, observations.]

---

## 3. Synthesis

### 3.1 Resources and ore

### 3.2 Exceptional fossil preservation

### 3.3 Life on land and evolution

### 3.4 Normal marine record and reef context

### 3.5 Minerals from the local collecting sites

[Each 200 to 300 words, only from verified chapter 2 information, citations as in chapter 2. Adapt the theme titles to the actual excursion.]

[Optional: personal conclusions, most important find, recommendations for future excursions.]

---

## References

[Alphabetical Harvard list.]

---

## About the Author

[Short biography supplied by the author.]
