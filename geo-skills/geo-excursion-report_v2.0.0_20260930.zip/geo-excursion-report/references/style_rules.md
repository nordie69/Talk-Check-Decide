# Style rules (binding)

## Language and wording
- Report language: English (British spelling: palaeontology, colour, sulphide). German proper names stay
  German (Steinbruch, Schieferbruch, Mineralienhalde, Urwelt-Museum).
- Never use em dashes or en dashes as punctuation. Use commas, colons, semicolons or new sentences.
  Ranges are written "80 to 75 Ma", not "80–75 Ma". Grep for "—" and "–" before delivery.
- Do not use the words "stop" or "POI" in the report. The scientific term is **locality** (plural
  localities) for the sites, and **coordinates** for positions. Table column for the running number: "No.".
- Ages: "c. 183 Ma", "about 150 million years"; ranges old to young ("c. 153 to 152 Ma"); stage names with
  epoch ("Lower Toarcian", "late Berriasian"); formal units capitalised ("Altmühltal Formation",
  "Posidonienschiefer Formation").
- Keep "Konservat-Lagerstätte", "Flinz", "Fäule", "Keuper", "Muschelkalk", "Buntsandstein",
  "Rotliegend", "Zechstein" untranslated; they are international terms.
- Never present a contested model as fact: give both views with citations ("the classic model ...;
  recent evidence suggests ...").
- Institutional figures (specimen counts, floor areas, founding years) are cited to the institution and
  may be flagged as not peer reviewed.

## Header
```
# Title
**Excursion period:** 2 to 9 September 2026
**Conducted and written by:** Dipl.-Ing. (FH) Name, BSc (X), MSc (Y)
**Date of report:** Month Year
```

## Citations (Harvard, author-date)
In text: (Author, 2021); (Author and Author, 2012); (Author, Author and Author, 1990) for three;
(Author et al., 2021) for four or more; organisations by full name (Bayerisches Landesamt für Umwelt,
n.d. a). Several works of one author-year: 2026 a, 2026 b, n.d. a, n.d. b (letters follow alphabetical
order of titles). Multiple citations in one bracket separated by semicolons.

Reference list, alphabetical, one blank line between entries, no numbering:
- Journal: `Surname, A.B. and Surname, C. (2019) 'Title', *Journal*, 57(4), pp. 427-456. DOI: [10.x/y](https://doi.org/10.x/y).`
- Book: `Surname, A. (1990) *Title*. City: Publisher.`
- Chapter: `Surname, A. (1999) 'Chapter', in Editor, B. (ed.) *Book*. City: Publisher, pp. 1-10.`
- Web: `Organisation (2026) *Page title*. Available at: https://... (Accessed: 3 September 2026).`
- Web without date: `Organisation (n.d.) ...`; personal site: `Surname, A. (n.d.) ...`.
- Dead link: append `(Accessed: date; URL returned HTTP 404 on re-check, date)` or replace.
- Every DOI as a clickable link. Every homepage in Table 1 must be in the reference list; every
  reference must be cited in text or be a Table 1 homepage, otherwise delete it.
- Mark unverified secondary citations `[to be verified]` in the internal research file only, not in the
  report.

## Tables and figures
- Exactly two tables: `**Table 1.** Itinerary ...` and `**Table 2.** Stratigraphic position ...`, caption
  in bold above the table, referenced in text before they appear.
- Table 2 lists field localities only (no museums), youngest at the top, columns: Period, Epoch and stage,
  Age (Ma), Locality (No.), Lithostratigraphic unit, Typical finds; locality number in parentheses after
  the name.
- Figures: `![Fig. N. Short title](images/file.png)` followed by `**Fig. N.** Caption.` Captions state
  data sources, projections, georeferencing accuracy and any edits to base maps (desaturation, removed
  features, translated legend).
- Photo placeholders until photos exist:
  ```
  [PHOTO: `images/05_locality_01.jpg`]

  **Fig. 12.** Locality name: [specimen; description].
  ```
  Image file names: `NN_shortname_XX.jpg` with NN = locality number in route order.

## Coordinates
Decimal degrees WGS 84, five decimals, `[53.55043, 9.99233](https://www.google.com/maps?q=53.55043,9.99233)`.
Under each locality heading:
```
**Coordinates:** [lat, lon](link)  
**Region:** Region name (State)
```

## Abstract
100 to 150 words as requested, no heading number, states period, number of localities, time span,
verification method and the synthesis themes. Do not claim photographs are included while placeholders
remain.
