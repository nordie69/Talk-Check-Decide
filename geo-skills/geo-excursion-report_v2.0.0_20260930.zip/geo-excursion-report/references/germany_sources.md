# Worked example: Germany (20 localities, September 2026)

## Authoritative sources by topic
- Formal lithostratigraphy: Deutsche Stratigraphische Kommission (LithoLex), Stratigraphische Tabelle von
  Deutschland Kompakt 2022 (STDK 2022; boundary ages 2.6, 23, 66, 145, 201.5, 252.5, 299, 361, 418,
  444, 485, 539 Ma). Franconian Alb Upper Jurassic: Niebuhr and Pürner (2014): Altmühltal, Mörnsheim,
  Painten, Treuchtlingen, Frankenalb Formations (replaces the informal "Solnhofen Formation").
- State surveys: LfU Bayern (Bayerns schönste Geotope), LGRB Baden-Württemberg (LGRBwissen), LBEG
  Niedersachsen, BGR (GK1000 open data; not reachable from the sandbox, ask the user for a download or
  an uploaded scan).
- Geoparks: TERRA.vita, Schwäbische Alb, Ries, Altmühltal; museum and operator sites for opening data.
- Key papers used: Markl et al. (2019) Clara mine; Röhl et al. (2001), Jenkyns (1988) Posidonienschiefer
  and T-OAE (c. 183 Ma); Munnecke et al. (2008), Barthel et al. (1990) plattenkalk; Hornung et al. (2012)
  Obernkirchen; Meyer et al. (2021) Barkhausen (Parabrontopodus barkhausensis, Jurabrontes teutonicus);
  Buchner et al. (2020, 2022), Schmieder et al. (2018), Stöffler et al. (2002) Ries and Steinheim;
  Mertz and Renne (2005), Lenz et al. (2015) Messel; Petmecky et al. (1999) Bramsche anomaly;
  Königer et al. (2002) Saar-Nahe volcanism; De Baets et al. (2013) Hunsrück Slate age;
  Rauhut et al. (2012, 2018), Foth and Rauhut (2017) Archaeopteryx count.

## Lessons from the worked example
- Popular claims that failed verification: Bramsche "intrusion" (now burial and inversion, contested);
  synchronous Ries-Steinheim double impact (contested); coral reefs at Solnhofen (sponge-microbial
  reefs); "470 species" at Clara (peer reviewed: more than 400, 13 type minerals); "20 percent TOC"
  (range 0.5 to 50 percent); outdated ichnotaxon names at Barkhausen.
- Base map for Fig. 2: geological overview map from geo-sports.org (2023); dashed cross-section trace
  removed by inpainting; legend redrawn in English with colours sampled from the map.
- Georeferencing: 18 city dots auto-detected (dark blobs after morphological opening), 2nd-order
  polynomial, mean residual 1.9 px, max 4.1 px on a 564 px wide scan.
- Route numbering replaced regional grouping; Hamburg city hall = point 0.
- Web reference years found in footers or meta tags (copyright 2026, modified_time); Wikipedia footers
  are not returned by the fetch tool.
- Users frequently correct coordinates in DMS; convert and re-run all three figures.
