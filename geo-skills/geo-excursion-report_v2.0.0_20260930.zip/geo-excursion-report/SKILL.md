---
name: "geo-excursion-report"
description: "Builds and iteratively improves a scientific geological excursion report (English, Markdown) for a set of visited localities (quarries, mine dumps, show mines, dinosaur track sites, geotopes, museums): itinerary table with decimal coordinates and Google Maps links, per-locality geology verified against peer-reviewed literature with Harvard citations, stratigraphic table, synthesis chapters, route map, georeferenced overlay on a geological base map, and a linear-scale stratigraphic chart, all generated as PNG with Python. Works worldwide; Germany is the worked example. Use this skill whenever the user mentions an excursion report, field trip report, Exkursionsbericht, fossil or mineral collecting trip, geology road trip, \"Fundstellen\", \"Localities\", geotrail, or wants localities placed on a map or a geological time scale, even if they only ask for one piece (a map, a stratigraphic chart, a reference list) or want an existing report checked, extended or corrected.\n"
metadata:
  version: "2.0.0"
---

# Geological Excursion Report

Produces a publication-style excursion report and keeps improving it over many turns. Two entry modes:

- **New report (minimal version):** ask for the essentials, build the whole skeleton in one pass.
- **Improve an existing report:** read it, run the consistency check, list gaps, ask targeted questions,
  apply changes in small verified steps.

Read `references/style_rules.md` first: it holds the non-negotiable conventions (terminology, citations,
no em dashes, numbering). Then follow the workflow below.

## 1. Intake (minimal version)

Ask only what cannot be inferred. Use one question round; ask the rest later while working.

Required:
1. Localities: exact names, ideally in visiting order (accept a plain list; ask for order if missing).
2. Excursion dates and start/end point (city; default reference point is the city hall).
3. Author line (name, degrees, affiliation) for the header and the "About the Author" section.
4. Output language (default English) and file/versioning wishes (default: `Report_vN.md` plus `images/`).

Optional, ask if not given: region for base map, preferred time scale (ICS latest vs a national chart),
depth of geology per locality (default 150 words), whether photos exist yet.

If the user gives only a locality list, proceed with sensible defaults and state the assumptions inline.

## 2. Locality research (per locality)

For each locality, in this order:
1. **Identity and websites.** Web search the exact name; confirm the correct place (many names are
   ambiguous, e.g. a quarry may lie in a neighbouring village). Record the operator or municipal homepage.
2. **Coordinates.** Use `places_search` or the user's coordinates. Convert DMS to decimal, five decimals,
   WGS 84. Flag duplicates (identical coordinates for two localities are almost always a copy error).
3. **Popular geology facts** (websites, Wikipedia, geopark pages) to draft the 150-word background.
4. **Peer-reviewed verification.** Search for formal lithostratigraphic unit, stage and numeric age tied to
   the ICS chart, depositional or ore-forming model, key fossils/minerals, type specimens, revisions
   (ichnotaxonomy, species counts, contested models). Prefer journal papers, geological survey
   publications and monographs. When literature and popular source disagree, the literature wins, the
   popular citation is removed from that sentence, and the correction is noted.
5. **Classify the type**: quarry or sand pit (collecting site), mine dump (collecting site), historic show
   mine, dinosaur track site, geotope, museum. Museums are not "field localities" (excluded from the
   stratigraphic table and chart).

For large sets, offer the Advanced Research tool (one deep research over all localities) and save its
output as an internal companion file `Deep_Research_Scientific_Verification_vN.md` (not for readers).

## 3. Build the report

Use `references/report_template.md` as the skeleton. Key structure:

```
Header (title, period, "Conducted and written by", date)
Abstract (100 to 150 words, no heading number; mention chapter 3 themes)
1 Introduction and Itinerary
  1.1 Introduction
  1.2 Selection of the localities and preparation (how the list was compiled, tools used)
  1.3 Itinerary: Table 1 (No., Locality, Type, Geological unit, Age, Website, Coordinates), Fig. 1 route map
  1.4 Geological overview map: Fig. 2
  1.5 Stratigraphic position of the collecting localities: Fig. 3, Table 2 (youngest on top)
2 Localities: 2.x per locality in route order
  Coordinates and Region lines under the heading
  2.x.1 Geological background (about 150 words, Harvard inline citations)
  2.x.2 Finds or Exhibits documented: one Fig. per photo, caption "Locality: [specimen; description]"
  2.x.3 Field notes (placeholder)
3 Synthesis: 3.1 to 3.5 thematic sections, each 200 to 300 words, only from verified information
References (unnumbered heading, Harvard, alphabetical, DOIs as clickable links)
About the Author (unnumbered)
```

Numbering rules:
- Localities are numbered in route order; point 0 is the start/end city. Table No. = chapter 2.x number.
- Figures: Fig. 1 to 3 in chapter 1, then one Fig. per photo placeholder in chapter 2, continuous.
- Only two tables (Table 1, Table 2) with bold captions above; finds are figures, never tables.
- Coordinates appear twice: in Table 1 and under each 2.x heading, both as
  `[lat, lon](https://www.google.com/maps?q=lat,lon)`.

Ages: state the chart used (default ICS latest). If the stratigraphic chart uses a national table (STDK,
BGS, USGS), say so in 1.3 and in the Fig. 3 caption, with the maximum deviation in Ma.

## 4. Figures (scripts in `scripts/`)

All scripts read one CSV: `localities.csv` with columns
`no,name,lat,lon,type,age_top,age_base,age_label` (see `assets/localities_template.csv`; type is one of
`start,quarry,dump,mine,track,geotope,museum`). Install once:
`pip install basemap basemap-data matplotlib scipy scikit-image pillow --break-system-packages`.

1. `scripts/route_map.py localities.csv out.png --bbox lon0 lat0 lon1 lat1 --inset "label:lon0,lat0,lon1,lat1" ...`
   Route map with numbered symbols per type, route line in visiting order, key list, optional insets for
   clusters. Boundaries and rivers come from GSHHG/WDBII bundled in basemap-data (offline).
2. `scripts/georef_overlay.py base.png control_points.csv localities.csv out.png [--desaturate 0.45]`
   Places localities on a scanned or downloaded geological map without georeference: fit a 2nd-order
   polynomial from lon/lat to pixels using control points (city dots), report residuals, overlay symbols,
   route, insets (drawn with basemap, not enlarged raster), key and source note. Control points: at least
   10, read from the image (the script can auto-detect solid dark dots with `--detect-dots`). Optional
   removal of a line feature by inpainting (`--remove-line x0 y0 x1 y1`) and legend replacement
   (`--legend legend.json`).
3. `scripts/strat_chart.py localities.csv out.png --tmax 361 --chart stdk2022|ics2023`
   Linear time scale, columns Era, Period, Epoch with boundary ages, field localities as leader lines to
   the right edge of the epoch column, long-lived processes (e.g. vein formation) as a delimited vertical
   line at the right margin. Museums are skipped automatically.

4. Redrawing a published map as a synthesis figure (no script of its own; built per project, see
   `template-dokumentprojekt` 8.4 and 8.5 for inputs and the project script). Use when source figures
   may not be reproduced or several maps are to be combined on one true-scale base.
   - Georeference every source by named control points: towns, or the places a structure is named after
     (the two ends of a shear zone called after them). Fit affine first and report the residual of every
     control point. Residuals hold only where control points lie; an area without control points is marked
     schematic in the legend and the caption.
   - Take the units by colour classification, then clean up: line colours and label boxes are read as
     units (shear-zone lines as Permian, label boxes as a unit of their own); remove them by position and
     shape and refill from the neighbours. Trace structures (shear zones, faults, symbols) by hand on gridded
     zooms of the source and state their accuracy separately, for example "about 5 to 10 km".
   - Where a zone is drawn in the source as the boundary of two units, snap it onto the redrawn colour
     boundary and report the median shift.
   - Check before delivery: project the result back onto each source and give the agreement per unit in per
     cent; overlay the lines on the source; check every locality against the unit the report names for it.
     Report agreements, deviations and non-findings (line colours read as a unit) separately.
   - Draw on a true-scale projection (Transverse Mercator, central meridian in the area) with scale bar and
     graticule labels computed at the frame edge; set the axis limits after all basemap draw calls, which
     reset them.
   - Caption and in-map note state: "redrawn and generalised after" with figure numbers, residuals, accuracy
     of hand-traced lines, schematic areas and what is left out; full Harvard references on the figure. A
     redrawing does not settle the rights of the sources: record each licence (CC BY allows reuse with
     attribution, licence link and a note on changes) and leave publication to the author.
   Occasion: NORWAY Report, Fig. 2, 29 September 2026. All control points of one source lay in Norway, and
   its Swedish part was up to 19 km off, found only in the comparison; the shear-zone lines of the other
   source were first classified as Permian.

Always view the rendered PNG before embedding; fix overlaps (move labels, add insets, shrink) and re-run.
Save under `images/00_<name>_vN.png`; the report links relatively.

## 5. Verification and consistency check (run before every delivery)

Follow `references/consistency_checklist.md`. Minimum automated checks (Python):
- Table 1 coordinates == chapter coordinates == Google Maps link parameters.
- Every in-text citation has a reference entry and vice versa (table homepages count as cited).
- Ages in Table 1, Table 2, chapter text and Fig. 3 labels agree; no invented symmetric ranges.
- Locality names identical in table, headings, figures and key lists.
- Figure numbers continuous; no leftover "[to be assigned]" markers; image paths exist.
- No em dashes anywhere (grep for "—").
Report inconsistencies to the user as a numbered list with a recommendation each; fix only on approval,
unless the fix is mechanical (numbering, links).

## 6. Improve mode (existing report supplied)

1. Read the whole file; extract localities, ages, citations, figure list into a working table.
2. Run the consistency check and list findings.
3. Ask targeted questions in one round (route order, missing coordinates, photos, author line,
   which time scale, which localities lack literature).
4. Apply changes in small, reversible steps; after each step re-run the affected check.
5. Version on request: copy report, companion file and images with the new `_vN` suffix and rewrite the
   image links; never overwrite the working copy.

Typical improvement requests seen in practice and how to handle them: reorder chapters to route order
(renumber headings, sub-headings, figure ids, image names); replace a popular source with a paper (edit the
sentence, remove the popular cite there, keep it elsewhere if still used); relabel a locality type (update
CSV, re-run all three figures, update Table 1 and captions); add an unnumbered section after References.

## 7. Reference verification of web sources

For each web reference marked n.d.: fetch the page (search first if the URL is not in context), look for
a copyright year, "last updated", meta `modified_time`, or dated content, and set the Harvard year; keep
n.d. when nothing is found and say so. Wikipedia footers are not returned by the fetch tool: keep n.d. or
ask the user for the revision year. Dead links: replace with a live source, or keep with a dated 404 note.

## Files in this skill

- `references/style_rules.md`: terminology, Harvard formats, DOI links, caption formats, wording bans.
- `references/report_template.md`: full Markdown skeleton with placeholders.
- `references/consistency_checklist.md`: the check list and a ready-to-run Python check.
- `references/germany_sources.md`: worked example, German data sources and formal unit names.
- `scripts/route_map.py`, `scripts/georef_overlay.py`, `scripts/strat_chart.py`, `scripts/check_report.py`.
- `assets/localities_template.csv`, `assets/legend_example.json`, `assets/control_points_example.csv`.
