#!/usr/bin/env python3
"""Linear-scale stratigraphic overview with Era, Period, Epoch columns and field localities.

Usage:
  python strat_chart.py localities.csv out.png --tmax 361 --chart stdk2022|ics2023 \
      [--process "9:Mineralienhalde Grube Clara, vein formation:66:201.5:Jurassic to Cretaceous (c. 201.5 to 66 Ma)"]

Localities with type 'museum' or 'start' are skipped. Localities whose age span exceeds --process-threshold
(default 30 Ma) are automatically drawn as a delimited vertical line at the right margin (long-lived process);
--process adds or overrides such lines explicitly (no:label:top:base:age_label).
Boundary ages: stdk2022 = Stratigraphische Tabelle von Deutschland Kompakt 2022 (STD 2016 values);
ics2023 = International Chronostratigraphic Chart 2023.
"""
import argparse, sys, os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
sys.path.insert(0, os.path.dirname(__file__))
from common import STYLE, read_localities, FIELD_TYPES

CHARTS = {
 'stdk2022': dict(
  periods=[("Quaternary",0,2.6,"#F9F97F"),("Neogene",2.6,23.0,"#FFE619"),("Palaeogene",23.0,66.0,"#FD9A52"),
   ("Cretaceous",66.0,145,"#7FC64E"),("Jurassic",145,201.5,"#34B2C9"),("Triassic",201.5,252.5,"#812B92"),
   ("Permian",252.5,299,"#F04028"),("Carboniferous",299,361,"#67A599"),("Devonian",361,418,"#CB8C37"),
   ("Silurian",418,444,"#B3E1B6"),("Ordovician",444,485,"#009270"),("Cambrian",485,539,"#7FA056")],
  epochs=[("Holocene",0,0.0117,"#FEF2E0"),("Pleistocene",0.0117,2.6,"#FFF2AE"),("Pliocene",2.6,5.3,"#FFFF99"),("Miocene",5.3,23.0,"#FFFF00"),
   ("Oligocene",23.0,33.9,"#FDC07A"),("Eocene",33.9,56.0,"#FDB46C"),("Palaeocene",56.0,66.0,"#FDA75F"),
   ("Late Cretaceous",66.0,100.5,"#A6D84A"),("Early Cretaceous",100.5,145,"#8CCD57"),
   ("Late Jurassic",145,163.5,"#B3E3EE"),("Middle Jurassic",163.5,174,"#80CFD8"),("Early Jurassic",174,201.5,"#42AED0"),
   ("Late Triassic",201.5,237,"#BD8CC3"),("Middle Triassic",237,247,"#B168B1"),("Early Triassic",247,252.5,"#983999"),
   ("Lopingian",252.5,259,"#FBA794"),("Guadalupian",259,272.5,"#FB745C"),("Cisuralian",272.5,299,"#EF5845"),
   ("Pennsylvanian",299,323,"#99C2B5"),("Mississippian",323,361,"#678F66"),
   ("Late Devonian",361,383,"#F1D8A0"),("Middle Devonian",383,393,"#F1C868"),("Early Devonian",393,418,"#E5AC4D"),
   ("Pridoli",418,423,"#E6F5E1"),("Ludlow",423,427,"#BFE6CF"),("Wenlock",427,433,"#B3E1C2"),("Llandovery",433,444,"#99D7B3"),
   ("Late Ordovician",444,458,"#7FCA93"),("Middle Ordovician",458,470,"#4DB47E"),("Early Ordovician",470,485,"#1A9D6F"),
   ("Furongian",485,497,"#B3E095"),("Miaolingian",497,509,"#A6CF86"),("Series 2",509,521,"#99C078"),("Terreneuvian",521,539,"#8CB06C")],
  eras=[("Cenozoic",0,66.0,"#F2F91D"),("Mesozoic",66.0,252.5,"#67C5CA"),("Palaeozoic",252.5,539,"#99C08D")],
  note="Boundary ages after Deutsche Stratigraphische Kommission (2022), Stratigraphische Tabelle von Deutschland Kompakt 2022 (STD 2016 values)."),
 'ics2023': dict(
  periods=[("Quaternary",0,2.58,"#F9F97F"),("Neogene",2.58,23.04,"#FFE619"),("Palaeogene",23.04,66.0,"#FD9A52"),
   ("Cretaceous",66.0,145.0,"#7FC64E"),("Jurassic",145.0,201.4,"#34B2C9"),("Triassic",201.4,251.9,"#812B92"),
   ("Permian",251.9,298.9,"#F04028"),("Carboniferous",298.9,358.9,"#67A599"),("Devonian",358.9,419.2,"#CB8C37"),
   ("Silurian",419.2,443.8,"#B3E1B6"),("Ordovician",443.8,485.4,"#009270"),("Cambrian",485.4,538.8,"#7FA056")],
  epochs=[("Holocene",0,0.0117,"#FEF2E0"),("Pleistocene",0.0117,2.58,"#FFF2AE"),("Pliocene",2.58,5.33,"#FFFF99"),("Miocene",5.33,23.04,"#FFFF00"),
   ("Oligocene",23.04,33.9,"#FDC07A"),("Eocene",33.9,56.0,"#FDB46C"),("Palaeocene",56.0,66.0,"#FDA75F"),
   ("Late Cretaceous",66.0,100.5,"#A6D84A"),("Early Cretaceous",100.5,145.0,"#8CCD57"),
   ("Late Jurassic",145.0,161.5,"#B3E3EE"),("Middle Jurassic",161.5,174.7,"#80CFD8"),("Early Jurassic",174.7,201.4,"#42AED0"),
   ("Late Triassic",201.4,237,"#BD8CC3"),("Middle Triassic",237,247.2,"#B168B1"),("Early Triassic",247.2,251.9,"#983999"),
   ("Lopingian",251.9,259.5,"#FBA794"),("Guadalupian",259.5,273.0,"#FB745C"),("Cisuralian",273.0,298.9,"#EF5845"),
   ("Pennsylvanian",298.9,323.2,"#99C2B5"),("Mississippian",323.2,358.9,"#678F66"),
   ("Late Devonian",358.9,382.7,"#F1D8A0"),("Middle Devonian",382.7,393.3,"#F1C868"),("Early Devonian",393.3,419.2,"#E5AC4D"),
   ("Pridoli",419.2,423.0,"#E6F5E1"),("Ludlow",423.0,427.4,"#BFE6CF"),("Wenlock",427.4,433.4,"#B3E1C2"),("Llandovery",433.4,443.8,"#99D7B3"),
   ("Late Ordovician",443.8,458.4,"#7FCA93"),("Middle Ordovician",458.4,470.0,"#4DB47E"),("Early Ordovician",470.0,485.4,"#1A9D6F"),
   ("Furongian",485.4,497,"#B3E095"),("Miaolingian",497,509,"#A6CF86"),("Series 2",509,521,"#99C078"),("Terreneuvian",521,538.8,"#8CB06C")],
  eras=[("Cenozoic",0,66.0,"#F2F91D"),("Mesozoic",66.0,251.9,"#67C5CA"),("Palaeozoic",251.9,538.8,"#99C08D")],
  note="Boundary ages after the ICS International Chronostratigraphic Chart 2023."),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('csv'); ap.add_argument('out')
    ap.add_argument('--tmax', type=float, default=361); ap.add_argument('--chart', default='stdk2022', choices=CHARTS)
    ap.add_argument('--process', action='append', default=[], help='no:label:top:base:age_label')
    ap.add_argument('--process-threshold', type=float, default=30)
    a = ap.parse_args()
    C = CHARTS[a.chart]; T = a.tmax
    clip = lambda lst: [(n, t, min(b, T), c) for n, t, b, c in lst if t < T]
    periods, epochs, eras = clip(C['periods']), clip(C['epochs']), clip(C['eras'])
    eras = [(n + (' (part)' if b0 > T else ''), t, b, c) for (n, t, b, c), (_, _, b0, _) in zip(eras, [e for e in C['eras'] if e[1] < T])]

    pts = [p for p in read_localities(a.csv) if p['type'] in FIELD_TYPES and p['age_top'] is not None]
    procs = {}
    for s in a.process:
        no, label, top, base, al = s.split(':'); procs[int(no)] = (label, float(top), float(base), al)
    for p in pts:
        if p['no'] not in procs and p['age_base'] - p['age_top'] > a.process_threshold:
            procs[p['no']] = (p['name'], p['age_top'], p['age_base'], p['age_label'])
    locs = [p for p in pts if p['no'] not in procs]

    fig = plt.figure(figsize=(13.5, 11), dpi=220)
    ax = fig.add_axes([0.07, 0.05, 0.90, 0.86])
    xmax = 9.15 + 1.4 * max(len(procs), 1)
    ax.set_ylim(T, 0); ax.set_xlim(0, xmax); ax.set_xticks([])
    ax.set_ylabel('Age (Ma), linear scale', fontsize=9); ax.set_yticks(range(0, int(T) + 1, 20)); ax.tick_params(axis='y', labelsize=9)
    for sp in ['top', 'right', 'bottom']: ax.spines[sp].set_visible(False)
    for name, t, b, c in eras:
        ax.add_patch(Rectangle((0, t), 1.2, b - t, fc=c, ec='k', lw=0.6)); ax.text(0.6, (t + b) / 2, name, rotation=90, ha='center', va='center', fontsize=12, fontweight='bold')
    for name, t, b, c in periods:
        ax.add_patch(Rectangle((1.2, t), 2.0, b - t, fc=c, ec='k', lw=0.6))
        if b - t >= 10: ax.text(2.2, (t + b) / 2, name, ha='center', va='center', fontsize=12, fontweight='bold')
        ax.text(4.68, b, f"{b:g}", fontsize=12, va='center', ha='left', color='#222', zorder=8, bbox=dict(boxstyle='round,pad=0.1', fc='white', ec='none'))
    pb = {b for _, _, b, _ in periods}
    for name, t, b, c in epochs:
        ax.add_patch(Rectangle((3.2, t), 1.4, b - t, fc=c, ec='k', lw=0.5))
        if b - t >= 9: ax.text(3.9, (t + b) / 2, name, ha='center', va='center', fontsize=9)
        elif b - t >= 5: ax.text(3.9, (t + b) / 2, name, ha='center', va='center', fontsize=7)
        if b not in pb and b >= 5: ax.text(4.68, b, f"{b:g}", fontsize=9, va='center', ha='left', color='#444', zorder=8, bbox=dict(boxstyle='round,pad=0.08', fc='white', ec='none'))
    for lab, x in [('Era', 0), ('Period', 1.2), ('Epoch', 3.2), ('Field localities (Table 2)', 5.7)]:
        ax.text(x, -T / 90, lab, fontsize=24, fontweight='bold', va='bottom')
    q = periods[0]
    ax.annotate(f'{q[0]} (0 to {q[2]:g} Ma): ' + ', '.join(e[0] for e in epochs if e[2] <= q[2]), xy=(4.6, q[2] / 2), xytext=(5.7, T / 72), fontsize=12, va='center', arrowprops=dict(arrowstyle='-', lw=0.6, color='#333'))
    lasty = T / 30
    for p in sorted(locs, key=lambda p: (p['age_top'] + p['age_base']) / 2):
        col, mk, _ = STYLE[p['type']]; mid = (p['age_top'] + p['age_base']) / 2
        ly = max(mid, lasty + T / 42.5); lasty = ly
        ax.plot([4.6, 5.65], [mid, ly], color='#555', lw=0.6)
        ax.scatter(5.8, ly, s=70, c=col, marker=mk, edgecolors='white', linewidths=0.6, zorder=5)
        ax.text(6.05, ly, f"{p['no']}  {p['name']}  ({p['age_label']})", fontsize=12, va='center')
    xc = xmax - 0.2
    for no, (label, top, base, al) in sorted(procs.items()):
        typ = next((p['type'] for p in pts if p['no'] == no), 'dump'); ccol, cmk, _ = STYLE[typ]
        ax.plot([xc, xc], [top, base], color=ccol, lw=2.2, solid_capstyle='butt', zorder=4)
        for yv in (top, base): ax.plot([xc - 0.15, xc + 0.15], [yv, yv], color=ccol, lw=2.2)
        ax.scatter(xc, (top + base) / 2, s=70, c=ccol, marker=cmk, edgecolors='white', linewidths=0.6, zorder=5)
        ax.text(xc, top - T / 120, f'{no}  {label}\n{al}', fontsize=12, ha='right', va='bottom')
        xc -= 1.4
    fig.text(0.07, 0.006, f"Stratigraphic overview of the field localities, linear time scale 0 to {T:g} Ma.\n{C['note']}\nLocality ages as in Table 2. Colours follow the international chronostratigraphic chart.", fontsize=6.2, color='#333')
    plt.savefig(a.out); print('written', a.out)


if __name__ == '__main__':
    main()
