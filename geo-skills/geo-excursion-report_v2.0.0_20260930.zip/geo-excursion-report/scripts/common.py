"""Shared definitions for the geo-excursion-report figure scripts."""
import csv

STYLE = {
    'start':   ('#111111', '*', 'Start and end point'),
    'quarry':  ('#c0392b', 'o', 'Quarry or sand pit (collecting site)'),
    'dump':    ('#e67e22', '^', 'Mine dump (collecting site)'),
    'mine':    ('#6d4c41', 'D', 'Historic show mine'),
    'track':   ('#27ae60', 'P', 'Dinosaur track site'),
    'geotope': ('#8e44ad', 'v', 'Geotope'),
    'museum':  ('#2e6db4', 's', 'Museum'),
}
ORDER = ['start', 'quarry', 'dump', 'mine', 'track', 'geotope', 'museum']
FIELD_TYPES = {'quarry', 'dump', 'mine', 'track', 'geotope'}


def read_localities(path):
    """Read localities.csv -> list of dicts with no(int), name, lat, lon, type, age_top, age_base, age_label."""
    rows = []
    with open(path, newline='', encoding='utf-8') as f:
        for r in csv.DictReader(f):
            if not r.get('name'):
                continue
            rows.append({
                'no': int(r['no']), 'name': r['name'].strip(),
                'lat': float(r['lat']), 'lon': float(r['lon']),
                'type': (r.get('type') or 'quarry').strip(),
                'age_top': float(r['age_top']) if r.get('age_top') else None,
                'age_base': float(r['age_base']) if r.get('age_base') else None,
                'age_label': (r.get('age_label') or '').strip(),
                'region': (r.get('region') or '').strip(),
            })
    rows.sort(key=lambda r: r['no'])
    return rows


def legend_handles(plt, types=ORDER, route=True, route_color='#c0392b'):
    hs = [plt.Line2D([0], [0], marker=STYLE[k][1], color='w', markerfacecolor=STYLE[k][0],
                     markeredgecolor='white', markersize=(12 if STYLE[k][1] == '*' else 9),
                     label=STYLE[k][2]) for k in types]
    if route:
        hs.append(plt.Line2D([0], [0], color=route_color, lw=1.5, alpha=0.8, label='Route in visiting order'))
    return hs
