#!/usr/bin/env python3
"""Automated consistency check for a geo-excursion report (Markdown). Usage: python check_report.py Report.md"""
import re, sys, os, unicodedata
t = open(sys.argv[1], encoding='utf-8').read()
findings = []
body, _, refs = t.partition('\n## References')
# 1 dashes and banned words
for ch, nm in [('\u2014', 'em dash'), ('\u2013', 'en dash')]:
    if ch in t: findings.append(f"{nm} found {t.count(ch)} times")
for w in [r'\bstops?\b', r'\bPOIs?\b']:
    if re.search(w, body): findings.append(f"banned word matches {w}")
# 2 Table 1 vs chapter coordinates
lines = t.split('\n'); t1 = {}
for l in lines:
    m = re.match(r'^\| (\d+) \| (.*?) \|.*\[([\d.]+), ([\d.]+)\]\(https://www\.google\.com/maps\?q=([\d.]+),([\d.]+)\)', l)
    if m: t1[int(m.group(1))] = (m.group(2), (m.group(3), m.group(4)), (m.group(5), m.group(6)))
ch = {}
for m in re.finditer(r'### 2\.(\d+) (.*?)\n\n\*\*Coordinates:\*\* \[([\d.]+), ([\d.]+)\]\(https://www\.google\.com/maps\?q=([\d.]+),([\d.]+)\)', t):
    ch[int(m.group(1))] = (m.group(2), (m.group(3), m.group(4)), (m.group(5), m.group(6)))
for n, (nm, c, l) in t1.items():
    if c != l: findings.append(f"Table 1 no. {n}: coordinates {c} differ from link {l}")
    if n in ch:
        if ch[n][1] != c: findings.append(f"no. {n}: Table 1 {c} vs chapter {ch[n][1]}")
        if ch[n][1] != ch[n][2]: findings.append(f"no. {n}: chapter coordinates vs link differ")
        if nm.split(',')[0].split(' (')[0].lower() not in ch[n][0].lower(): findings.append(f"no. {n}: name '{nm}' vs heading '{ch[n][0]}'")
    elif n != 0: findings.append(f"no. {n} in Table 1 has no chapter 2.{n}")
seen = {}
for n, (nm, c, l) in t1.items():
    if c in seen: findings.append(f"no. {n} and no. {seen[c]} share coordinates {c}")
    seen[c] = n
# 3 citations vs references (robust to commas in author lists and organisation names)
entries = [e.strip() for e in refs.split('\n\n') if e.strip() and not e.startswith('#')]
def norm(s): return unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode().lower()
keys = []
for e in entries:
    m = re.match(r"(.+?) \(((?:n\.d\.(?: [a-z])?)|\d{4}(?: [a-z])?)\)", e)
    if m: keys.append((m.group(1), m.group(2), e))
nbody = norm(body)
def key_cited(author, year):
    first = norm(re.split(r',| and | \(ed', author)[0]).strip()
    tok = first[:12]
    for m in re.finditer(re.escape(tok), nbody):
        window = nbody[m.start():m.start() + 160]
        if re.search(r'(,|\s)\s*\(?' + re.escape(year) + r'(?![\d])', window): return True
    return False
turls = {u.rstrip('/') for u in re.findall(r'\| (https?://[^\s|]+)', body)}
for a0, y, e in keys:
    urls = [u.rstrip('/') for u in re.findall(r'https?://[^\s)]+', e)]
    if not key_cited(a0, y) and not any(u in turls for u in urls): findings.append(f"reference never cited: {e[:70]}")
# citations whose year+author combination matches no reference
for c in re.findall(r'\(([^()]*?(?:\d{4}|n\.d\.)[^()]*?)\)', body):
    for part in c.split(';'):
        part = part.strip(); m = re.search(r'((?:n\.d\.(?: [a-z])?)|\d{4}(?: [a-z])?)\s*$', part)
        if not m or 'http' in part or ',' not in part: continue
        year = m.group(1); auth = norm(part[:m.start()].rstrip(', '))
        if not auth or not auth[0].isalpha(): continue
        ok = any(k[1] == year and norm(re.split(r',| and | \(ed', k[0])[0])[:10] in auth for k in keys)
        if not ok: findings.append(f"citation without reference: ({part})")
missing = [u for u in turls if 'google.com/maps' not in u and not any(u in e for e in entries)]
for u in missing: findings.append(f"Table 1 homepage not in references: {u}")
# 4 figures and images
figs = [int(x) for x in re.findall(r'^\*\*Fig\. (\d+)\.\*\*', t, re.M)]
if figs != list(range(1, len(figs) + 1)): findings.append(f"figure numbering not continuous: {figs}")
for im in re.findall(r'!\[[^\]]*\]\(([^)]+)\)', t):
    if not os.path.exists(os.path.join(os.path.dirname(os.path.abspath(sys.argv[1])), im)): findings.append(f"image file missing: {im}")
if 'to be assigned' in t: findings.append("leftover 'to be assigned' marker")
ntab = len(re.findall(r'^\*\*Table (\d+)\.\*\*', t, re.M))
if ntab != 2: findings.append(f"{ntab} table captions found (expected 2)")
print('\n'.join(f"- {f}" for f in findings) if findings else 'no findings')
