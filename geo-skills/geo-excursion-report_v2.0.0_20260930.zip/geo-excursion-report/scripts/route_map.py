#!/usr/bin/env python3
"""Route map with numbered localities, type symbols, route line, key list and optional insets.

Usage:
  python route_map.py localities.csv out.png --bbox 5.5 47.2 15.4 55.2 \
      --inset "Solnhofen and Eichstätt area:10.90,48.83,11.25,48.96" \
      --inset "Idar-Oberstein and Fischbach area:7.20,49.67,7.42,49.78" \
      --title "Geological excursion, 2 to 9 September 2026: localities in route order (WGS 84)"
Requires: basemap, basemap-data, matplotlib (pip install --break-system-packages).
Localities with type 'start' are drawn as the first and last point of the route.
"""
import argparse, sys, os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from mpl_toolkits.basemap import Basemap
sys.path.insert(0, os.path.dirname(__file__))
from common import STYLE, ORDER, read_localities, legend_handles


def parse_inset(s):
    label, box = s.split(':')
    lon0, lat0, lon1, lat1 = map(float, box.split(','))
    return label, (lon0, lat0, lon1, lat1)


def draw_points(m, ax, pts, members, fontsize, offsets=None, s=70):
    for p in pts:
        if p['no'] not in members:
            continue
        x, y = m(p['lon'], p['lat']); col, mk, _ = STYLE[p['type']]
        m.scatter(x, y, s=(s * 2.2 if p['type'] == 'start' else s), c=col, marker=mk,
                  edgecolors='white', linewidths=0.8, zorder=5)
        dx, dy = (offsets or {}).get(p['no'], (0.12, 0.06))
        tx, ty = m(p['lon'] + dx, p['lat'] + dy)
        ax.text(tx, ty, str(p['no']), fontsize=fontsize, fontweight='bold', ha='center', va='center',
                zorder=6, bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none', alpha=0.85))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('csv'); ap.add_argument('out')
    ap.add_argument('--bbox', nargs=4, type=float, required=True, metavar=('LON0', 'LAT0', 'LON1', 'LAT1'))
    ap.add_argument('--inset', action='append', default=[], help='"label:lon0,lat0,lon1,lat1"')
    ap.add_argument('--title', default='Localities in route order (WGS 84)')
    ap.add_argument('--resolution', default='i', help='basemap resolution c/l/i/h')
    ap.add_argument('--note', default='Boundaries and rivers: GSHHG/WDBII via basemap-data. Coordinates as in Table 1 (WGS 84).')
    a = ap.parse_args()

    pts = read_localities(a.csv)
    start = [p for p in pts if p['type'] == 'start']
    route = start + [p for p in pts if p['type'] != 'start'] + start
    insets = [parse_inset(s) for s in a.inset]
    in_inset = {}
    for label, (lon0, lat0, lon1, lat1) in insets:
        for p in pts:
            if lon0 <= p['lon'] <= lon1 and lat0 <= p['lat'] <= lat1 and p['type'] != 'start':
                in_inset[p['no']] = label

    fig = plt.figure(figsize=(12, 11), dpi=200)
    ax = fig.add_axes([0.03, 0.04, 0.66, 0.92])
    lon0, lat0, lon1, lat1 = a.bbox
    m = Basemap(projection='merc', llcrnrlon=lon0, llcrnrlat=lat0, urcrnrlon=lon1, urcrnrlat=lat1,
                resolution=a.resolution, ax=ax)
    m.drawmapboundary(fill_color='#dfeef7'); m.fillcontinents(color='#f4f1ea', lake_color='#dfeef7')
    m.drawcoastlines(linewidth=0.5, color='#666'); m.drawcountries(linewidth=0.9, color='#444')
    m.drawrivers(linewidth=0.3, color='#9fc2d9')
    m.drawparallels(range(int(lat0), int(lat1) + 2), labels=[1, 0, 0, 0], linewidth=0.3, color='#bbb', fontsize=8)
    m.drawmeridians(range(int(lon0), int(lon1) + 2), labels=[0, 0, 0, 1], linewidth=0.3, color='#bbb', fontsize=8)
    xs, ys = zip(*[m(p['lon'], p['lat']) for p in route])
    m.plot(xs, ys, '-', color='#c0392b', linewidth=0.9, alpha=0.6, zorder=3)
    draw_points(m, ax, pts, {p['no'] for p in pts if p['no'] not in in_inset}, 8)
    for label, (ilon0, ilat0, ilon1, ilat1) in insets:
        x0, y0 = m(ilon0, ilat0); x1, y1 = m(ilon1, ilat1)
        ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, ec='#333', lw=0.8, ls='--', zorder=7))
        nos = sorted(n for n, l in in_inset.items() if l == label)
        tx, ty = m(ilon1 + 0.05, ilat0)
        ax.text(tx, ty, f"{nos[0]} to {nos[-1]}\n(inset)", fontsize=7.5, fontweight='bold', va='center')
    ax.set_title(a.title, fontsize=10.5)

    y = 0.60
    for label, (ilon0, ilat0, ilon1, ilat1) in insets:
        axi = fig.add_axes([0.70, y, 0.28, 0.30])
        mi = Basemap(projection='merc', llcrnrlon=ilon0, llcrnrlat=ilat0, urcrnrlon=ilon1, urcrnrlat=ilat1,
                     resolution=a.resolution, ax=axi)
        mi.drawmapboundary(fill_color='#dfeef7'); mi.fillcontinents(color='#f4f1ea', lake_color='#dfeef7')
        mi.drawrivers(linewidth=0.8, color='#9fc2d9')
        step = round((ilat1 - ilat0) / 3, 2)
        mi.drawparallels([round(ilat0 + step * k, 2) for k in range(1, 3)], labels=[1, 0, 0, 0], linewidth=0.3, color='#bbb', fontsize=6)
        stepl = round((ilon1 - ilon0) / 4, 2)
        mi.drawmeridians([round(ilon0 + stepl * k, 2) for k in range(1, 4)], labels=[0, 0, 0, 1], linewidth=0.3, color='#bbb', fontsize=6)
        members = {n for n, l in in_inset.items() if l == label}
        draw_points(mi, axi, pts, members, 7.5, offsets={n: (stepl * 0.18, 0.0) for n in members}, s=65)
        axi.set_title(f'Inset: {label}', fontsize=7.5)
        for sp in axi.spines.values(): sp.set_linestyle('--'); sp.set_color('#333')
        y -= 0.26
    key = "\n".join(f"{p['no']:>2}  {p['name']}" for p in pts)
    fig.text(0.705, y + 0.22, key, fontsize=7.4, va='top', family='DejaVu Sans Mono',
             bbox=dict(boxstyle='round,pad=0.5', fc='white', ec='#999'))
    types = [k for k in ORDER if any(p['type'] == k for p in pts)]
    ax.legend(handles=legend_handles(plt, types), loc='lower left', fontsize=7.5, frameon=True)
    fig.text(0.98, 0.015, a.note, ha='right', fontsize=6, color='#555')
    plt.savefig(a.out); print('written', a.out)


if __name__ == '__main__':
    main()
