#!/usr/bin/env python3
"""Overlay localities on a non-georeferenced geological base map (scan or download).

Usage:
  python georef_overlay.py base.png control_points.csv localities.csv out.png \
      [--desaturate 0.45] [--lighten 0.15] [--remove-line x0 y0 x1 y1 ...] \
      [--legend legend.json] [--inset "label:lon0,lat0,lon1,lat1" ...] \
      [--source "Base map: ... (year), URL"] [--detect-dots]

control_points.csv: lon,lat,x,y[,name] with pixel coordinates of at least 10 identifiable points
(city dots). --detect-dots prints candidate dark solid dots (x,y) to help fill that file.
Fits a 2nd-order polynomial lon/lat -> pixel, prints residuals (keep mean < 3 px), draws symbols,
route, optional basemap-style insets, key list, legend and source note.
--remove-line: inpaints dark pixels within 3.5 px of the segment (x0,y0)-(x1,y1); repeat for
several segments. --legend: JSON (see assets/legend_example.json) to crop the raster legend and
redraw it in English with colours sampled at the given swatch pixel positions.
"""
import argparse, sys, os, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image, ImageEnhance
sys.path.insert(0, os.path.dirname(__file__))
from common import STYLE, ORDER, read_localities, legend_handles


def feats(lon, lat):
    lon = np.asarray(lon, float); lat = np.asarray(lat, float)
    return np.column_stack([np.ones_like(lon), lon, lat, lon * lat, lon ** 2, lat ** 2])


def detect_dots(im):
    from scipy import ndimage as ndi
    a = np.array(im.convert('RGB')).astype(int)
    dark = a.max(axis=2) < 110
    op = ndi.binary_opening(dark, structure=np.ones((3, 3)))
    lab, n = ndi.label(op)
    for i, sl in enumerate(ndi.find_objects(lab), 1):
        h = sl[0].stop - sl[0].start; w = sl[1].stop - sl[1].start; area = (lab[sl] == i).sum()
        if 3 <= h <= 8 and 3 <= w <= 8 and area / (h * w) > 0.6:
            cy, cx = ndi.center_of_mass(lab == i); print(f"dot candidate x={cx:.0f} y={cy:.0f}")


def remove_line(im, segs):
    from scipy import ndimage as ndi
    from skimage.restoration import inpaint
    a = np.array(im.convert('RGB'))
    H, W, _ = a.shape; yy, xx = np.mgrid[0:H, 0:W]
    mask = np.zeros((H, W), bool)
    for x0, y0, x1, y1 in segs:
        p = np.array([x0, y0], float); q = np.array([x1, y1], float); u = (q - p) / np.linalg.norm(q - p)
        n = np.array([-u[1], u[0]]); d = np.abs((xx - p[0]) * n[0] + (yy - p[1]) * n[1])
        al = (xx - p[0]) * u[0] + (yy - p[1]) * u[1]
        corridor = (d <= 3.5) & (al >= -4) & (al <= np.linalg.norm(q - p) + 4)
        mask |= corridor & (a.max(axis=2) < 130)
    mask = ndi.binary_dilation(mask, iterations=1)
    res = inpaint.inpaint_biharmonic(a, mask, channel_axis=-1)
    return Image.fromarray((res * 255).astype(np.uint8))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('base'); ap.add_argument('cp'); ap.add_argument('csv'); ap.add_argument('out')
    ap.add_argument('--desaturate', type=float, default=0.45); ap.add_argument('--lighten', type=float, default=0.15)
    ap.add_argument('--remove-line', nargs=4, type=float, action='append', default=[])
    ap.add_argument('--legend'); ap.add_argument('--inset', action='append', default=[])
    ap.add_argument('--source', default='Base map: [source to be added]'); ap.add_argument('--detect-dots', action='store_true')
    ap.add_argument('--title', default='Localities of the excursion on the geological overview map')
    a = ap.parse_args()

    im = Image.open(a.base).convert('RGB')
    if a.detect_dots:
        detect_dots(im); return
    if a.remove_line:
        im = remove_line(im, a.remove_line)
    imfull = im
    cp = np.loadtxt(a.cp, delimiter=',', skiprows=1, usecols=(0, 1, 2, 3))
    A = feats(cp[:, 0], cp[:, 1])
    cx = np.linalg.lstsq(A, cp[:, 2], rcond=None)[0]; cy = np.linalg.lstsq(A, cp[:, 3], rcond=None)[0]
    res = np.sqrt(((A @ cx) - cp[:, 2]) ** 2 + ((A @ cy) - cp[:, 3]) ** 2)
    print(f"georef residual: mean {res.mean():.2f} px, max {res.max():.2f} px")
    proj = lambda lon, lat: (float((feats([lon], [lat]) @ cx)[0]), float((feats([lon], [lat]) @ cy)[0]))

    legend = json.load(open(a.legend)) if a.legend else None
    im = ImageEnhance.Color(im).enhance(a.desaturate)
    im = Image.blend(im, Image.new('RGB', im.size, (255, 255, 255)), a.lighten)
    if legend:
        im = im.crop((0, 0, im.size[0], legend['crop_below_y']))
    W, H = im.size
    pts = read_localities(a.csv)
    start = [p for p in pts if p['type'] == 'start']
    route = start + [p for p in pts if p['type'] != 'start'] + start

    fig = plt.figure(figsize=(13, 9.6), dpi=220)
    ax = fig.add_axes([0.005, 0.235 if legend else 0.02, 0.60, 0.745 if legend else 0.96])
    ax.imshow(im); ax.set_xlim(0, W); ax.set_ylim(H, 0); ax.axis('off')
    xs, ys = zip(*[proj(p['lon'], p['lat']) for p in route])
    ax.plot(xs, ys, '-', color='#c0392b', lw=2.0, alpha=0.8, zorder=3)
    insets = []
    for s in a.inset:
        label, box = s.split(':'); insets.append((label, tuple(map(float, box.split(',')))))
    in_inset = {p['no']: l for l, (lo0, la0, lo1, la1) in insets for p in pts if lo0 <= p['lon'] <= lo1 and la0 <= p['lat'] <= la1 and p['type'] != 'start'}
    for p in pts:
        x, y = proj(p['lon'], p['lat']); col, mk, _ = STYLE[p['type']]
        ax.scatter(x, y, s=(170 if p['type'] == 'start' else 80), c=col, marker=mk, edgecolors='white', linewidths=0.8, zorder=5)
        if p['no'] not in in_inset:
            ax.text(x + 9, y - 4, str(p['no']), fontsize=10.5, fontweight='bold', ha='center', va='center', zorder=6,
                    bbox=dict(boxstyle='round,pad=0.12', fc='white', ec='none', alpha=0.85))
    for label, (lo0, la0, lo1, la1) in insets:
        c = [proj(lo, la) for lo, la in [(lo0, la0), (lo1, la1), (lo0, la1), (lo1, la0)]]
        x0 = min(q[0] for q in c) - 3; x1 = max(q[0] for q in c) + 3; y0 = min(q[1] for q in c) - 3; y1 = max(q[1] for q in c) + 3
        ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, ec='#111', lw=0.9, ls='--', zorder=7))
        nos = sorted(n for n, l in in_inset.items() if l == label)
        ax.text(x1 + 6, y1 + 10, f"{nos[0]} to {nos[-1]}\n(inset)", fontsize=9.75, fontweight='bold', va='center')
    ax.set_title(a.title, fontsize=11)

    from mpl_toolkits.basemap import Basemap
    y = 0.70
    for label, (lo0, la0, lo1, la1) in insets:
        nos = sorted(n for n, l in in_inset.items() if l == label)
        axi = fig.add_axes([0.63, y, 0.34, 0.26])
        mi = Basemap(projection='merc', llcrnrlon=lo0, llcrnrlat=la0, urcrnrlon=lo1, urcrnrlat=la1, resolution='i', ax=axi)
        mi.drawmapboundary(fill_color='#dfeef7'); mi.fillcontinents(color='#f4f1ea', lake_color='#dfeef7'); mi.drawrivers(linewidth=0.8, color='#9fc2d9')
        step = round((la1 - la0) / 3, 2); stepl = round((lo1 - lo0) / 4, 2)
        mi.drawparallels([round(la0 + step * k, 2) for k in range(1, 3)], labels=[1, 0, 0, 0], linewidth=0.3, color='#bbb', fontsize=6)
        mi.drawmeridians([round(lo0 + stepl * k, 2) for k in range(1, 4)], labels=[0, 0, 0, 1], linewidth=0.3, color='#bbb', fontsize=6)
        for p in pts:
            if in_inset.get(p['no']) == label:
                x, yv = mi(p['lon'], p['lat']); col, mk, _ = STYLE[p['type']]
                mi.scatter(x, yv, s=80, c=col, marker=mk, edgecolors='white', linewidths=0.8, zorder=5)
                tx, ty = mi(p['lon'] + stepl * 0.18, p['lat'])
                axi.text(tx, ty, str(p['no']), fontsize=12, fontweight='bold', va='center', ha='center', zorder=6, bbox=dict(boxstyle='round,pad=0.12', fc='white', ec='none', alpha=0.85))
        axi.set_title(f'Inset: {label} ({nos[0]} to {nos[-1]})', fontsize=11.25)
        for sp in axi.spines.values(): sp.set_linestyle('--'); sp.set_color('#111')
        y -= 0.30
    key = "\n".join(f"{p['no']:>2}  {p['name']}" for p in pts)
    fig.text(0.62, y + 0.27, key, fontsize=7.2, va='top', family='DejaVu Sans Mono', bbox=dict(boxstyle='round,pad=0.4', fc='white', ec='#999'))
    types = [k for k in ORDER if any(p['type'] == k for p in pts)]
    ax.legend(handles=legend_handles(plt, types), loc='upper right', fontsize=7.2, frameon=True, title='Localities', title_fontsize=7.5)
    if legend:
        axl = fig.add_axes([0.02, 0.02, 0.58, 0.20]); axl.set_xlim(0, 100); axl.set_ylim(0, 100); axl.axis('off')
        colx = [0, 28, 58, 80]
        for ci, col in enumerate(legend['columns']):
            yv = 95
            for item in col:
                if item[0] == 'head':
                    axl.text(colx[ci], yv, item[1], fontsize=7.2, fontweight='bold', va='center'); yv -= 10
                elif item[0] == 'sw':
                    px, py = item[1]; c = tuple(np.array(imfull.getpixel((px + 10, py + 8))) / 255)
                    axl.add_patch(Rectangle((colx[ci], yv - 2.6), 4.5, 4.2, fc=c, ec='#888', lw=0.4)); axl.text(colx[ci] + 5.6, yv - 0.5, item[2], fontsize=6.6, va='center'); yv -= 9
                elif item[0] == 'line':
                    axl.plot([colx[ci], colx[ci] + 4.5], [yv, yv], color=item[1], lw=1, ls=item[2]); axl.text(colx[ci] + 5.6, yv, item[3], fontsize=6.6, va='center'); yv -= 9
        axl.text(0, 3, legend.get('note', ''), fontsize=6, color='#333')
    fig.text(0.62, 0.09, a.source + f"\nLocalities georeferenced with a second order polynomial fitted to {len(cp)} control points\n(mean residual {res.mean():.1f} px, maximum {res.max():.1f} px). Coordinates as in Table 1 (WGS 84).", fontsize=6.5, va='top', color='#333')
    plt.savefig(a.out); print('written', a.out)


if __name__ == '__main__':
    main()
