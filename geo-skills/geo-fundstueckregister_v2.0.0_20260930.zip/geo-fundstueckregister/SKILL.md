---
name: geo-fundstueckregister
description: Ueberfuehrt eine geologische, mineralogische oder palaeontologische Aufsammlung in ein sammlungsfaehiges Fundstueckregister. Pro Belegstueck eine Zeile mit Inventarnummer, Fundpunktverweis, Fundschicht, Sammeldatum, Sammler, Bestimmung mit Autor und Jahr, Bestimmungssicherheit, Erhaltung, Praeparationsstand, Massen, Verbleib und Fotoverweis. Bindet jede Bestimmung an den einzelnen Beleg statt an die Lokalitaet, fuehrt Unsicheres als cf. oder aff. und prueft stratigraphische Angaben gegen den Fundpunkt, nicht gegen die Region. Ausgabe als Markdown-Tabelle und CSV, dazu ein Etikettensatz. Immer verwenden bei Formulierungen wie Fundstuecke erfassen, Aufsammlung inventarisieren, Belegstuecke katalogisieren, Inventarnummern vergeben, Sammlungsliste erstellen, Etiketten fuer die Sammlung, Funde einer Exkursion dokumentieren, Bestimmung festhalten. Auch triggern wenn Fundnotizen, Fototabellen oder Sammelkisten-Listen vorliegen und daraus ein geordnetes Register entstehen soll.
metadata:
  version: "2.0.0"
---

# Fundstückregister

Überführt eine Aufsammlung in ein Register, das einer Sammlung standhält: jedes Stück einzeln, jede Bestimmung an ihren Beleg gebunden, jede Unsicherheit benannt.

## Grundregeln

1. **Ein Stück, eine Zeile.** Auch Serien gleicher Art werden einzeln geführt, sonst lässt sich später kein Stück mehr zuordnen. Nur echte Sammelbelege (ein Handstück mit mehreren Individuen, Schlämmproben) bekommen eine Zeile und einen Vermerk zur Stückzahl.
2. **Bestimmung gehört zum Beleg, nicht zur Lokalität.** Dass eine Art an einem Fundpunkt vorkommt, macht ein dortiges Stück nicht zu dieser Art. Was am Stück nicht erkennbar ist, bleibt offen.
3. **Unsicheres wird nicht geglättet.** Offene Nomenklatur nach den üblichen Konventionen: `cf.` bei wahrscheinlicher, `aff.` bei ähnlicher, aber abweichender Zuordnung, `gen. et sp. indet.` bei unbestimmbarem Material, `?` vor einem Rangnamen bei Zweifel an diesem Rang.
4. **Stratigraphie gegen den Fundpunkt prüfen.** Die Fundschicht wird aus dem Aufschluss belegt, nicht aus der Regionalstratigraphie abgeleitet. Fehlt die Schichtangabe im Feldprotokoll, steht `OFFEN`, nicht die Formation des Gebiets.
5. **Keine erfundenen Angaben.** Fehlende Maße, Daten oder Sammler bleiben leer oder `OFFEN`. Rekonstruktionen aus dem Kontext werden als solche gekennzeichnet.

## Inventarnummern

Schema: `<Präfix>-<Jahr>-<laufende Nummer>`, etwa `SM-2026-0147`. Das Präfix ist frei wählbar (Initialen, Sammlungskürzel), Jahr vierstellig, laufende Nummer mindestens vierstellig mit führenden Nullen, damit die Sortierung stimmt.

Ergänzungen: Teilstücke eines zusammengehörigen Fundes bekommen Buchstabensuffixe (`SM-2026-0147a`, `-0147b`), etwa Platte und Gegenplatte. Ein später abgetrenntes Stück behält die Stammnummer mit neuem Suffix, bekommt keine neue Nummer.

Bestehende Nummern des Nutzers werden übernommen, nicht umnummeriert. Liegt bereits ein Register vor, wird die Zählung fortgesetzt und die höchste vergebene Nummer im Kopf vermerkt.

## Felder

| Feld | Inhalt |
|---|---|
| Inv-Nr | Inventarnummer nach obigem Schema |
| Fundpunkt | Name und, wenn vorhanden, die ID aus der Fundorttabelle, damit Register und Fundortdokument verknüpft sind |
| Koordinaten | Dezimalgrad WGS 84, sofern am Fundpunkt erhoben; sonst Verweis auf die Fundorttabelle |
| Fundschicht | Bank, Lage oder Horizont wie im Feld angesprochen, mit Angabe über oder unter einer Leitbank, wenn vorhanden |
| Formation | Lithostratigraphische Einheit, nur wenn für die Fundschicht belegt |
| Alter | Stufe, nur wenn aus der Fundschicht ableitbar |
| Sammeldatum | ISO-Format, JJJJ-MM-TT |
| Sammler | Name oder Kürzel |
| Bestimmung | Wissenschaftlicher Name mit Autor und Jahr, bei Mineralen der IMA-gültige Name |
| Sicherheit | `sicher`, `cf.`, `aff.` oder `indet.` |
| Bestimmt durch | Wer bestimmt hat und wann; bei Revision die frühere Bestimmung in Klammern |
| Erhaltung | Erhaltungszustand und Erhaltungsart, etwa Steinkern, Schalenerhaltung, Pyritisierung, Verdrückung |
| Präparation | `unpräpariert`, `angelegt`, `fertig`, mit Methode, wenn bekannt |
| Maße | Länge x Breite x Höhe in mm, bei Mineralstufen zusätzlich Kristallgröße |
| Verbleib | Sammlungsteil, Schublade, Kiste oder Leihnehmer |
| Foto | Dateiname oder Verweis, mehrere durch Komma |
| Bemerkung | Besonderheiten, offene Fragen, Literaturhinweis zum Vergleichsstück |

Felder ohne Inhalt bleiben leer; nur wo eine Angabe erwartet, aber nicht ermittelbar ist, steht `OFFEN`.

## Ablauf

### Schritt 1: Eingaben sichten

Quellen können Feldnotizen, Fotolisten, Kistenzettel, Tabellen oder Diktate sein. Zuerst klären, was je Stück vorliegt und was fehlt. Liegt eine Fundorttabelle vor (etwa aus `fundort-datenbank-recherche`), wird sie für Fundpunktnamen, IDs und Koordinaten herangezogen, statt diese neu zu erfassen.

### Schritt 2: Stücke trennen

Aus der Eingabe die einzelnen Belege herauslösen. Häufige Fallen: Sammelnotizen wie "drei Ammoniten" ergeben drei Zeilen; "Platte mit Gegenplatte" ergibt eine Nummer mit zwei Suffixen; eine Tüte Schlämmprobe ist ein Beleg mit Mengenangabe.

### Schritt 3: Bestimmung prüfen

Jede vom Nutzer gelieferte Bestimmung auf Gültigkeit des Namens prüfen: Synonymie, aktueller Gattungsname, korrektes Autorzitat, bei Mineralen IMA-Status. Abweichungen nicht stillschweigend korrigieren, sondern beide Namen führen, den gültigen voran, den gelieferten in Klammern.

Wo die Bestimmung erkennbar über das hinausgeht, was das Material hergibt, wird die Sicherheitsstufe herabgesetzt und das in der Bemerkung begründet. Der Skill bestimmt nicht selbst anhand von Fotos, er ordnet und prüft; eine eigene Bestimmung ist immer als Vorschlag zu kennzeichnen.

### Schritt 4: Stratigraphie prüfen

Fundschicht, Formation und Alter müssen zueinander und zum Fundpunkt passen. Widersprüche werden markiert, nicht aufgelöst. Ist eine Klärung nötig, an `geo-frage-belegbasiert-klaeren` übergeben statt im Register zu entscheiden.

### Schritt 5: Ausgabe erzeugen

Drei Artefakte, alle über ein kurzes Python-Skript aus derselben Datenstruktur erzeugt:

- **Register als Markdown**, Tabelle mit allen Feldern, sortiert nach Inventarnummer, mit Kopf (Stand, Anzahl Stücke, Nummernbereich, zugehöriges Fundortdokument) und einem kurzen Abschnitt zu offenen Punkten.
- **CSV** mit denselben Spalten, UTF-8 mit BOM und Semikolon als Trenner, damit Excel es direkt öffnet.
- **Etikettensatz als Markdown**, ein Block je Stück im Format Inventarnummer, Bestimmung mit Autor und Jahr, Fundpunkt, Fundschicht und Formation, Sammeldatum und Sammler. Etiketten bleiben knapp, Bemerkungen kommen nicht aufs Etikett.

Dateinamen: `fundstueckregister_<YYYY-MM-DD>.md`, `fundstueckregister_<YYYY-MM-DD>.csv`, `fundstueck-etiketten_<YYYY-MM-DD>.md`. Alle drei mit `present_files` übergeben.

### Schritt 6: Fortschreiben

Liegt ein Register vor, wird angehängt, nie überschrieben: bestehende Zeilen bleiben unverändert, neue Stücke werden unten ergänzt, die Zählung läuft weiter. Revisionen einer Bestimmung ändern die Zeile und tragen die frühere Bestimmung mit Datum in `Bestimmt durch` nach.

## Abgrenzung zu benachbarten Skills

- Fundpunkt in Datenbanken nachweisen, Koordinaten und Links: `fundort-datenbank-recherche`.
- Strittige Alters-, Formations- oder Zuordnungsfrage klären: `geo-frage-belegbasiert-klaeren`.
- Literatur zu den Fundpunkten ordnen: `fundstellen-bibliographie`.
- Bericht mit Karten und Stratigraphiediagramm: `geo-excursion-report`.

## Häufige Fehler

- Die Fauna der Lokalität auf das einzelne Stück übertragen.
- Die Regionalstratigraphie als Fundschicht eintragen, obwohl im Feld keine Bank angesprochen wurde.
- Serien zu einer Zeile zusammenfassen und damit die Einzelzuordnung verlieren.
- Eine Bestimmung ohne Autor und Jahr führen, sodass unklar bleibt, welches Taxonkonzept gemeint ist.
- Bei Revision die alte Bestimmung löschen statt sie mitzuführen.
- Beim Fortschreiben neu durchnummerieren und damit Etiketten und Register auseinanderlaufen lassen.
