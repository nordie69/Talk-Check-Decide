# Prüfraster

Die Pflichtelemente je Typ als prüfbare Kriterien. Jede Zeile trägt das Element, die Zählvorschrift und den Belegstatus. **Belegt** heißt aus einer Primärquelle des jeweiligen Herausgebers oder Regelgebers; **Konvention** heißt aus Sekundärquellen und typischen Beispielen abgeleitet, also verhandelbar.

Typkürzel wie in `geo-exkursionsbericht-erstellen/references/typologie.md`: A1 wissenschaftlicher Exkursionsführer, A2 populärer Führer, A3 digitaler Feldführer, A4 Geotop-Dokumentation, B1 Nachbericht, B2 Fundstellen- und Sammelbericht, B3 Aufschluss- und Profilaufnahme, B4 Expeditionsbericht, B5 Reisebericht, C1 studentischer Bericht, C2 Kartier- und Geländebericht, C3 Forschungsprojektbericht, C4 Kurzmitteilung, C5 Explorationsbericht, C6 interdisziplinärer Projektbericht.

---

## 0 Typunabhängiger Kern

Diese Kriterien gelten für jeden Kandidaten. Ihre Maßnahmen gehören in den Kernplan, nie in einen Delta-Plan.

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| K.1 | Jede Lokalität hat Koordinaten mit Bezugssystem | Lokalitäten gesamt, davon mit Koordinate, davon mit Bezugssystem | Belegt |
| K.2 | Keine Übertragung von Regions- auf Punktangaben | Anzahl Angaben, deren räumliche Ebene nicht benannt ist | Belegt |
| K.3 | Beobachtung, Deutung und Literaturaussage sind getrennt | Anzahl Sätze, die zwei davon ohne Kennzeichnung verbinden, an einer Stichprobe von zehn Absätzen | Belegt |
| K.4 | Jede Zitation hat einen Verzeichniseintrag und umgekehrt | Zitationen, Einträge, Differenz in beide Richtungen | Belegt |
| K.5 | Abbildungs- und Tabellennummern sind lückenlos und im Text referenziert | Nummernlücken, nicht referenzierte Nummern | Konvention |
| K.6 | Jede Abbildung hat Bildunterschrift, erklärte Symbole und Quellenangabe | Abbildungen gesamt, davon vollständig beschriftet | Belegt |
| K.7 | Jede Karte hat Titel, Legende, Maßstab, Quelle, bei Bedarf Nordpfeil | Karten gesamt, davon vollständig | Belegt |
| K.8 | Jeder Marker OFFEN oder UNKLAR trägt einen Satz dazu, was fehlt | Marker gesamt, davon ohne Satz | Belegt |
| K.9 | Einheiten nach SI, Doppelangaben nur nach Vorgabe des Zielorgans | Anzahl Stellen mit abweichender Einheit | Belegt |
| K.10 | Stratigraphische Nomenklatur aktuell, historische Namen gekennzeichnet | Anzahl veralteter Namen ohne Kennzeichnung | Belegt |
| K.11 | Kein Statusapparat im Bericht | Anzahl Absätze über Bearbeitungsstand, Erledigung oder Entstehung | Konvention |
| K.12 | Keine Em-Dashes | Trefferzahl | Konvention |

---

## A1 Wissenschaftlicher Exkursionsführer

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| A1.1 | Abstract, höchstens 300 Wörter | Wortzahl | Belegt (GFT&M) |
| A1.2 | Key words, 5 bis 10 | Anzahl | Belegt |
| A1.3 | Program summary, höchstens 2 Seiten, mit mindestens einer Itinerarabbildung | Vorhanden, Abbildung vorhanden | Belegt |
| A1.4 | Sicherheitsabschnitt: Kleidung, Ausrüstung, Notrufnummern, Bergrettung, Feuerwehr | fünf Teilangaben, davon vorhanden | Belegt |
| A1.5 | Krankenhäuser mit Adresse und Telefon | Anzahl genannter Häuser | Belegt |
| A1.6 | Unterkunft: Tourist office, Hotels, Hütten, Campingplätze | Anzahl Teilangaben | Belegt |
| A1.7 | Stops fortlaufend nummeriert, bei Mehrtagesexkursionen als n.m | Stops gesamt, davon regelkonform nummeriert | Belegt |
| A1.8 | Je Stop WGS84-Koordinate | Stops mit Koordinate | Belegt |
| A1.9 | Road log mit Fahrdistanzen zwischen den Stops | Anzahl Übergänge mit Distanzangabe | Belegt (GSA, USGS) |
| A1.10 | Regionalgeologisches Kapitel vor dem Itinerar | Vorhanden, Wortzahl | Belegt |
| A1.11 | Zugangs- und Genehmigungslage je Stop | Stops mit Angabe | Belegt |
| A1.12 | Figure captions und References als eigene Abschnitte am Ende | Vorhanden | Belegt |
| A1.13 | Abbildungen in .eps, .tiff oder .jpg, 300 dpi, Beschriftung 6 bis 8 pt | Anzahl konformer Abbildungen | Belegt (GFT&M) |
| A1.14 | Prospektives Tempus, Route als Ordnungsprinzip | Kapitelreihenfolge | Belegt |

**Rückbau bei Wechsel nach A1**: Diskussionskapitel, Reflexion, Teilnehmerliste.

---

## A2 Populärer Führer

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| A2.1 | Route mit Zugangs- und Anfahrtsangaben | Vorhanden | Konvention |
| A2.2 | Highlights je Abschnitt benannt | Anzahl | Konvention |
| A2.3 | Erklärende Grafik je Hauptthema | Anzahl Grafiken zu Anzahl Themen | Konvention |
| A2.4 | Fachbegriffe erklärt oder vermieden | Anzahl unerklärter Fachbegriffe in einer Stichprobe | Konvention |
| A2.5 | Quellenhinweis am Ende | Vorhanden | Konvention |

**Rückbau bei Wechsel nach A2**: Methodikkapitel, vollständiger Apparat, Formationsschärfe in der Nomenklatur.

---

## A3 Digitaler Feldführer

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| A3.1 | Georeferenzierte Stationen | Stationen gesamt, davon mit Koordinate | Belegt |
| A3.2 | Eingebettete Medien je Station | Stationen mit Medium | Belegt |
| A3.3 | Didaktischer Erzählfaden über die Stationen | Vorhanden | Belegt |
| A3.4 | Lizenzangabe | Vorhanden | Belegt |
| A3.5 | Technische Plattform benannt | Vorhanden | Belegt |
| A3.6 | Quellenangabe des physischen Aufschlusses je Station | Stationen mit Angabe | Belegt |

---

## A4 Geotop-Dokumentation

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| A4.1 | Lage mit Koordinate | Vorhanden | Belegt |
| A4.2 | Erdgeschichtliche Bedeutung | Vorhanden | Belegt |
| A4.3 | Schutzstatus | Vorhanden | Belegt |
| A4.4 | Bewertung nach Bedeutung, Seltenheit, Eigenart, Schönheit | vier Kriterien, davon bewertet | Belegt |
| A4.5 | Übersichtskarte und Foto | Vorhanden | Konvention |

---

## B1 Nachbericht

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| B1.1 | Teilnehmer benannt | Vorhanden | Konvention |
| B1.2 | Zeitraum benannt | Vorhanden | Konvention |
| B1.3 | Route nachvollziehbar | Lokalitäten in erkennbarer Reihenfolge | Konvention |
| B1.4 | Beobachtungen je Lokalität | Lokalitäten mit eigenem Beobachtungsteil | Konvention |
| B1.5 | Erkenntnisabschnitt, der über die Einzellokalität hinausgeht | Vorhanden, Wortzahl | Konvention |
| B1.6 | Retrospektives Tempus | Stichprobe | Konvention |

**Rückbau bei Wechsel nach B1**: road log, Sicherheits-, Krankenhaus- und Unterkunftsangaben; sie wandern in den Anhang oder entfallen.

---

## B2 Fundstellen- und Sammelbericht

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| B2.1 | Fundortangabe, bei Schutzbedarf bewusst unscharf und als Entscheidung vermerkt | Vorhanden, Vermerk vorhanden | Belegt |
| B2.2 | Paragenese benannt | Anzahl Mineralarten mit Beziehung zueinander | Belegt |
| B2.3 | Kristallisationssukzession | Vorhanden | Belegt |
| B2.4 | Typlokalitätsstatus geklärt | Vorhanden oder ausdrücklich verneint | Belegt (Mindat) |
| B2.5 | Belegstücke mit Sammlungsverbleib und Inventarnummer | Stücke gesamt, davon mit Nummer | Belegt |
| B2.6 | Bei Fossilien: Fundschichtbindung je Stück | Stücke mit Horizont | Belegt |
| B2.7 | Bei Fossilien: offene Nomenklatur nach Sigovini et al. 2016 konsistent | Anzahl Bestimmungen, davon mit korrektem Kürzel | Belegt |
| B2.8 | Stufenfotos in Makro oder Mikro mit Maßstab | Anzahl | Konvention |
| B2.9 | Rechtslage geprüft, wo Denkmalschutz greift | Vorhanden | Belegt |

---

## B3 Aufschluss- und Profilaufnahme

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| B3.1 | Lithologische Säule mit Korngröße als horizontaler Achse | Vorhanden | Belegt |
| B3.2 | Schichtdicken | Anzahl Schichten mit Maß | Belegt |
| B3.3 | Sedimentstrukturen, Farbe, Kontakte | drei Angaben, davon vorhanden | Belegt |
| B3.4 | Koordinate des Aufschlusses | Vorhanden | Belegt |
| B3.5 | Foto mit Maßstab | Vorhanden | Konvention |

---

## B4 Expeditionsbericht

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| B4.1 | Expedition summary | Vorhanden | Belegt (IODP) |
| B4.2 | Methods-Kapitel | Vorhanden | Belegt |
| B4.3 | Site- oder Stationskapitel je Station | Stationen gesamt, davon mit Kapitel | Belegt |
| B4.4 | Je Station operations und Ergebnisse nach Fachdisziplin | Disziplinen je Station | Belegt |
| B4.5 | Stationsliste | Vorhanden | Belegt |
| B4.6 | Routenkarte | Vorhanden | Belegt |
| B4.7 | Unsichere Werte gekennzeichnet | Anzahl | Belegt |

---

## C1 Studentischer Bericht

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| C1.1 | Gelände kurz beschrieben | Vorhanden | Konvention |
| C1.2 | Kartierpunkte benannt | Anzahl | Konvention |
| C1.3 | Schichtabfolge dargestellt | Vorhanden | Konvention |
| C1.4 | Strukturen beschrieben | Vorhanden | Konvention |
| C1.5 | Beobachtung und Interpretation sichtbar getrennt, etwa durch eigene Abschnitte | Anzahl Lokalitäten mit Trennung | Belegt |
| C1.6 | Umfang 5 bis 15 Seiten | Seitenzahl | Konvention |

---

## C2 Kartier- und Geländebericht

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| C2.1 | Geologische Karte als Beilage | Vorhanden | Belegt |
| C2.2 | Profilschnitte | Anzahl | Belegt |
| C2.3 | Abstract, etwa 100 Wörter | Wortzahl | Konvention |
| C2.4 | Regionalgeologischer Rahmen | Vorhanden, Wortzahl | Belegt |
| C2.5 | Methodikkapitel | Vorhanden | Belegt |
| C2.6 | Lithostratigraphie und Kartiereinheiten | Anzahl Einheiten mit Beschreibung | Belegt |
| C2.7 | Struktur und Tektonik | Vorhanden | Belegt |
| C2.8 | Geologische Geschichte | Vorhanden | Belegt |
| C2.9 | Schlussfolgerungen | Vorhanden | Belegt |
| C2.10 | Anhänge mit Messdaten | Vorhanden | Belegt |
| C2.11 | Normierte Kartensymbole | Abweichungen | Belegt |
| C2.12 | Erkenntnis als Ordnungsprinzip, nicht Route | Kapitelreihenfolge | Belegt |

**Rückbau bei Wechsel nach C2**: Teilnehmerliste, Reisebericht-Passagen, road log.

---

## C3 Forschungsprojektbericht

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| C3.1 | Forschungsfrage ausdrücklich formuliert | Vorhanden, im Einleitungskapitel | Konvention |
| C3.2 | Datenerhebung beschrieben | Vorhanden | Konvention |
| C3.3 | Ergebnisse von Diskussion getrennt | eigene Kapitel | Konvention |
| C3.4 | Modell oder Interpretation in der Diskussion | Vorhanden | Konvention |
| C3.5 | Messunsicherheiten benannt | Anzahl Messgrößen mit Unsicherheitsangabe | Konvention |
| C3.6 | Schlussfolgerungen beantworten die Frage aus C3.1 | Bezug vorhanden | Konvention |

---

## C4 Kurzmitteilung

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| C4.1 | Ein einziger Befund im Mittelpunkt | Anzahl Befunde | Konvention |
| C4.2 | Interpretation des Befundes | Vorhanden | Konvention |
| C4.3 | Umfang 2 bis 6 Seiten | Seitenzahl | Konvention |
| C4.4 | Keine Methodik- und Kartenanhänge | Anzahl vorhandener Anhänge | Konvention |

---

## C5 Explorationsbericht

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| C5.1 | 27 Items nach Form 43-101F1 in Nummer und Reihenfolge | Items gesamt vorhanden, Abweichungen | Belegt |
| C5.2 | Qualified oder Competent Person benannt | Vorhanden | Belegt |
| C5.3 | Site visit dokumentiert, mit Datum | Vorhanden | Belegt |
| C5.4 | Ressourcenklassifikation als measured, indicated, inferred | Anzahl klassifizierter Ressourcen | Belegt |
| C5.5 | Reliance on Other Experts ausgewiesen | Vorhanden | Belegt |
| C5.6 | Data Verification dokumentiert | Vorhanden | Belegt |

Wird dieser Typ Kandidat, hört die Analyse als Gattungsprüfung auf und der Bericht geht in das regulierte Regime. Der Delta-Plan sagt das ausdrücklich und listet nur die Lücken gegenüber der Item-Struktur.

---

## C6 Interdisziplinärer Projektbericht

| Nr | Pflichtelement | Zählvorschrift | Status |
|---|---|---|---|
| C6.1 | Eigenes Fachkapitel je beteiligter Disziplin | Disziplinen gesamt, davon mit Kapitel | Konvention |
| C6.2 | Gemeinsame Karte oder gemeinsames Modell | Vorhanden | Konvention |
| C6.3 | Disziplinen im Text unterscheidbar, nicht verschmolzen | Anzahl Kapitel mit Disziplinzuordnung | Konvention |
| C6.4 | Gesamtsynthese über die Disziplinen | Vorhanden | Konvention |

---

## Aufwandsmaß

Aufwand wird in betroffenen Abschnitten gezählt, nicht in Stunden. Drei Größenordnungen:

- **klein**: ein bis drei Abschnitte, keine Umnummerierung.
- **mittel**: vier bis zehn Abschnitte, oder eine Umnummerierung von Abbildungen oder Lokalitäten.
- **groß**: mehr als zehn Abschnitte, oder ein Wechsel des Ordnungsprinzips zwischen Route und Erkenntnis.

Ein Wechsel des Ordnungsprinzips ist immer groß, auch wenn er nach wenig aussieht: er zieht Überschriften, Unterüberschriften, Abbildungskennungen, Dateinamen und jede Querverweiskette hinter sich her.
