# Befundkatalog

Die wiederkehrenden Befunde und die Maßnahmenformulierung, die jeweils trägt. Jeder Eintrag nennt den Befund, die Zählung, die ihn belegt, die Maßnahme im Wortlaut und den Plan, in den sie gehört.

Eine Maßnahme sagt, was zu tun ist, wo es hingehört und woher der Inhalt kommt. Ohne Ort und Quelle wird sie beim nächsten Öffnen neu durchdacht statt abgearbeitet.

**Gut**: "In 1.3 hinter Tabelle 1 eine Tabelle Tagesetappen einfügen, acht Zeilen, Spalten Tag, Start, Ziel, Lokalitäten, Kilometer, Fahrzeit. Quelle ist die Routendatei."

**Schlecht**: "Die Etappen sollten besser dokumentiert werden."

---

## 1 Georeferenzierung unvollständig

**Zählung** Lokalitäten gesamt, davon ohne Koordinate, davon ohne Bezugssystem, davon mit Koordinate an zwei Stellen mit abweichendem Wert.

**Maßnahme** "Unter jede Lokalitätsüberschrift in Kapitel 2 eine Koordinatenzeile in Dezimalgrad mit fünf Nachkommastellen und dem Zusatz WGS84 setzen. Für die N Lokalitäten ohne Koordinate den Marker OFFEN mit einem Satz dazu, warum keine vorliegt. Quelle sind die Feldnotizen, sonst AUTOR."

**Plan** Kern. Immer Block 1, weil jede spätere Tabelle und jede Karte darauf zugreift.

**Fallstrick** Eine Koordinate, die in Tabelle und Kapitel steht, ist zwei Aussagen. Beide werden gegeneinander geprüft, nicht eine abgeschrieben.

---

## 2 Regionsangabe als Fundpunktangabe

**Zählung** Anzahl übernommener Listen, Zahlen oder Collections, deren räumliche Ebene nicht benannt ist.

**Maßnahme** "Bei den N Angaben in 2.x die Ebene der Quelle ergänzen, also Region, Gemeinde oder Fundpunkt. Angaben von einer übergeordneten Ebene aus der Fundstellenbeschreibung in den Kommentar verschieben. Quelle ist die jeweils zitierte Datenbank."

**Plan** Kern.

**Weitergabe** Bei systematischem Befund an `geo-fundstellen-evidenz-pruefung` abgeben, nicht hier vollständig behandeln.

---

## 3 Beobachtung und Deutung vermengt

**Zählung** Stichprobe von zehn Absätzen, darin Anzahl Sätze, die Befund und Deutung ohne Kennzeichnung verbinden.

**Maßnahme** "In den Lokalitätsabschnitten je Lokalität zwei Absätze bilden: zuerst, was im Gelände zu sehen war, dann, was daraus folgt und was die Literatur dazu sagt. Betrifft die N in Anlage A gelisteten Stellen. Quelle ist der vorhandene Text, keine neue Information nötig."

**Plan** Kern.

**Fallstrick** Das ist eine Umformulierung, keine Ergänzung. Sie läuft vor jeder Belegprüfung, weil sie die Sätze verschiebt, auf die sich Belege beziehen.

---

## 4 Quellenapparat unrund

**Zählung** Zitationen im Text, Einträge im Verzeichnis, Einträge ohne Zitation, Zitationen ohne Eintrag, Anteil Primärliteratur.

**Maßnahme** "Die N Zitationen ohne Verzeichniseintrag ergänzen und die M Einträge ohne Zitation entweder im Text verankern oder streichen. Liste in Anlage B. Quelle sind die vorhandenen Angaben, bei N Fällen AUTOR."

**Plan** Kern.

**Weitergabe** Formfehler einzelner Einträge und nicht auflösende DOI gehören an `science-quellenapparat-pruefung`.

---

## 5 Abbildungen ohne Apparat

**Zählung** Abbildungen gesamt, davon ohne Bildunterschrift, ohne erklärte Symbole, ohne Maßstabsobjekt, ohne Blickrichtung, ohne Quellenangabe; Nummernlücken.

**Maßnahme** "Für die N Abbildungen in Anlage C eine Bildunterschrift nach dem Muster Objekt, Standort, Blickrichtung, Maßstab, Quelle ergänzen. Nummerierung fortlaufend schließen, Verweise im Text nachziehen."

**Plan** Kern.

**Fallstrick** Das Schließen von Nummernlücken verschiebt alle folgenden Nummern. Es geht jeder inhaltlichen Ergänzung voraus, nie umgekehrt.

---

## 6 Karte ohne Pflichtangaben

**Zählung** Karten gesamt, davon mit Titel, Legende, Maßstab, Nordpfeil, Quelle der Grundlage.

**Maßnahme** "Bei den N Karten die fehlenden Elemente ergänzen und die Kartengrundlage mit Herausgeber, Blatt und Maßstab zitieren. Quelle ist die verwendete Grundlage, bei N Fällen AUTOR."

**Plan** Kern.

---

## 7 Gattungsfremde Elemente vorhanden

**Zählung** Anzahl Abschnitte, die der Zieltyp ausdrücklich nicht verlangt, mit Wortzahl.

**Maßnahme** "Die Abschnitte X und Y mit zusammen N Wörtern in einen Anhang verschieben, weil der Zieltyp sie nicht trägt. Alternativ streichen. Kein Inhalt geht verloren, die Verweise darauf in 1.2 und 3.1 werden angepasst."

**Plan** Delta des Zieltyps.

**Fallstrick** Verschieben statt Streichen ist die Vorgabe, solange die Typentscheidung nicht endgültig ist. Gestrichener Text kommt nicht zurück.

---

## 8 Pflichtelement des Zieltyps fehlt vollständig

**Zählung** Element aus dem Prüfraster, Status FEHLT, Aufwand in betroffenen Abschnitten.

**Maßnahme** Wortlaut aus dem Prüfraster übernehmen und um Ort und Quelle ergänzen. Beispiel: "Hinter dem regionalgeologischen Kapitel einen Abschnitt Safety einfügen mit Kleidung und Ausrüstung, Notrufnummern, Bergrettung und Feuerwehr für das Exkursionsgebiet. Quelle AUTOR, ersatzweise Recherche der örtlichen Rettungsdienste."

**Plan** Delta.

---

## 9 Ordnungsprinzip passt nicht zum Zieltyp

**Zählung** Kapitelreihenfolge, Anzahl Kapitel, die umzustellen sind, Anzahl abhängiger Kennungen (Überschriften, Abbildungen, Dateinamen, Querverweise).

**Maßnahme** "Kapitel 2 von thematischer auf Routenreihenfolge umstellen, N Unterkapitel neu nummerieren, M Abbildungskennungen und die Bilddateinamen entsprechend ändern, danach alle Querverweise prüfen."

**Plan** Delta, und dort Block 1, weil alles Weitere darauf aufsetzt.

**Aufwand** Immer groß. Ein Wechsel des Ordnungsprinzips zieht jede Kennung hinter sich her.

---

## 10 Umfang passt nicht zum Zieltyp

**Zählung** Seitenzahl oder Wortzahl gegen die Spanne des Typs, dazu die Wortzahl je Kapitel.

**Maßnahme** Bei Überschreitung: "Die Kapitel mit den größten Wortzahlen auf die Zielspanne kürzen, zuerst X mit N Wörtern; der gekürzte Stoff geht in den Anhang." Bei Unterschreitung: das fehlende Pflichtelement benennen, nicht den Text strecken.

**Plan** Delta.

**Fallstrick** Eine Unterschreitung ist fast nie ein Längenproblem, sondern ein fehlendes Element. Wer Text streckt, verdeckt den Befund.

---

## 11 Marker ohne Aussage

**Zählung** Marker OFFEN und UNKLAR gesamt, davon ohne Satz, was fehlt.

**Maßnahme** "Bei den N Markern in Anlage D je einen Satz ergänzen, was genau fehlt und wer es liefern kann. Marker ohne diesen Satz entfernen, weil sie nichts aussagen."

**Plan** Kern.

---

## 12 Fundortangabe ohne Schutzentscheidung

**Zählung** Fundstellen mit metergenauer Koordinate, davon zugangsbeschränkt oder sammelrechtlich sensibel.

**Maßnahme** "Für die N sensiblen Fundstellen entscheiden, ob die Koordinate grob gehalten wird, und die Entscheidung im Text vermerken. Quelle AUTOR, weil nur er die Absprache mit Eigentümer oder Betreiber kennt."

**Plan** Delta von B2, sonst Kern, wenn mineralogische oder paläontologische Fundstellen im Bericht vorkommen.

**Fallstrick** Stillschweigende Ungenauigkeit sieht aus wie Schlamperei. Die Entscheidung wird benannt.

---

## 13 Rechtslage nicht geprüft

**Zählung** Anzahl Fundstellen in Deutschland mit entnommenem Material, davon mit Angabe zur Melde- oder Genehmigungslage.

**Maßnahme** "Für die N Fundstellen das Denkmalschutzgesetz des jeweiligen Bundeslandes und die Schatzregal- oder Meldepflicht prüfen und das Ergebnis je Fundstelle in einem Satz festhalten. Quelle ist die Landesgesetzgebung."

**Plan** Delta von B2, bei Typmaterial zwingend.

---

## 14 Evidenzgrade fehlen, wo der Typ sie verlangt

**Zählung** Anzahl Aussagen mit Ressourcen-, Mengen- oder Altersangabe ohne Klassifikation oder Unsicherheitsangabe.

**Maßnahme** Bei C5: "Die N Ressourcenangaben als measured, indicated oder inferred klassifizieren." Bei B4: "Die N unsicheren Messwerte als solche kennzeichnen." Bei C3: "Je Messgröße die Unsicherheit angeben."

**Plan** Delta.

---

## 15 Statusapparat im Bericht

**Zählung** Anzahl Absätze, Spalten oder Vermerke über Bearbeitungsstand, Erledigung oder Entstehung des Dokuments.

**Maßnahme** "Die N Stellen in Anlage E entfernen und, soweit sie den Arbeitsstand betreffen, in den Arbeitsplan übernehmen. Was offen ist, zeigen die Marker im Text."

**Plan** Kern.

---

## Anlagen

Wo eine Maßnahme eine Liste von Fundstellen nennt, wird diese Liste als Anlage an den Plan gehängt und nicht in die Maßnahme geschrieben. Die Maßnahme nennt die Anzahl und verweist auf die Anlage. Ändert sich die Liste, wird die Anzahl in der Maßnahme nachgezählt, nicht aus dem Gedächtnis fortgeschrieben.
