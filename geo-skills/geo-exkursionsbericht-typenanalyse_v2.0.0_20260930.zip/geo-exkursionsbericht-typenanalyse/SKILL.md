---
name: "geo-exkursionsbericht-typenanalyse"
description: "Prüft einen fertigen Exkursions-, Gelände-, Kartier- oder Fundstellenbericht aus der Sicht aller Gattungen, die für ihn in Frage kommen, zählt je Kandidat die erfüllten und fehlenden Pflichtelemente aus und liefert das Ergebnis als Arbeitspläne: einen Kernplan mit dem, was jeder Kandidat verlangt, und je Kandidat einen Delta-Plan mit dem, was nur dieser Typ zusätzlich fordert. Die Typwahl bleibt Sache des Autors und wird als Zweckentscheidung vorgelegt. Immer verwenden bei: Exkursionsbericht analysieren, welcher Berichtstyp ist das, was fehlt meinem Geländebericht, Bericht gegen Gattung prüfen, Verbesserungsvorschläge als Arbeitsplan, passt mein Bericht zur Zielpublikation. NICHT für das Schreiben eines neuen Berichts, dafür geo-exkursionsbericht-erstellen."
metadata:
  version: "2.0.0"
---

# Typenanalyse eines Exkursions- oder Geländeberichts

Vierte Prüfachse neben `science-faktenbeleg-pruefung` (Richtigkeit), `science-interne-konsistenz-pruefung` (Selbstkonsistenz) und `science-dokumentkritik-drei-sichten` (Brauchbarkeit für seine Leser). Diese Achse fragt nach der Gattung.

Ein Bericht ist nicht für sich richtig oder falsch, sondern gemessen an einem Typ vollständig oder lückenhaft. Derselbe Text kann als Nachbericht fertig und als Exkursionsführer unbrauchbar sein. Deshalb wird nicht gegen einen Typ geprüft, sondern gegen alle, die in Frage kommen, und die Wahl dem Autor vorgelegt.

Die Regeldateien:

- `references/pruefraster.md`: je Typ die Pflichtelemente als prüfbare Kriterien mit Zählvorschrift.
- `references/befundkatalog.md`: die wiederkehrenden Befunde und die Maßnahmenformulierung, die jeweils trägt.

Die Gattungsbeschreibungen selbst stehen in `geo-exkursionsbericht-erstellen/references/typologie.md`. Ist dieser Skill verfügbar, wird die Datei gelesen; sonst genügt das Prüfraster, das die Kriterien ohne die Prosa trägt.

## Grundregeln

- **Zuerst zählen, dann urteilen.** Ein Befund ohne Zahl oder Fundstelle ist kein Befund. "Die Lokalitätsbeschreibungen sind uneinheitlich" ist keiner, "17 Lokalitäten, davon 11 mit Koordinaten, 6 ohne, 4 ohne Bezugssystem" ist einer.
- **Keine stille Änderung.** Die Analyse ändert den Bericht nicht. Sie liefert Befunde und Pläne; geändert wird nach Freigabe und maßnahmenweise.
- **Kein Kandidat ohne Merkmal.** Geprüft wird nur ein Typ, für den das Dokument mindestens ein Merkmal zeigt. Zwei Kandidaten sind das Minimum, vier das Maximum. Mehr erzeugt Pläne, die niemand liest.
- **Die Typwahl ist eine Zweckentscheidung.** Sie wird als D Z vorgelegt, mit ausgezählten Folgen und ohne Empfehlung. Eine Empfehlung nähme dem Autor die Entscheidung ab, für wen er schreibt.
- **Sprache** ist die des Nutzers, nicht die des Berichts. Die Ausgabe ist eine Arbeitsanweisung.
- **Keine Em-Dashes, keine doppelten Bindestriche.**

## Phase 1: Bestandsaufnahme

Den Bericht vollständig lesen und auszählen, bevor irgendein Typ genannt wird. Erhoben wird:

| Größe | Zählvorschrift |
|---|---|
| Lokalitäten | Anzahl, davon mit Koordinaten, davon mit Bezugssystem, davon mit stratigraphischer Einordnung |
| Abbildungen | Anzahl, Nummernlücken, Anzahl ohne Bildunterschrift, ohne Maßstab, ohne Quellenangabe |
| Tabellen | Anzahl, Position der Überschrift, Einheiten in den Spaltenköpfen |
| Karten | Anzahl, davon mit Titel, Legende, Maßstab, Nordpfeil, Quelle der Grundlage |
| Literatur | Anzahl Einträge, Anzahl Zitationen im Text, Einträge ohne Zitation, Zitationen ohne Eintrag, Anteil Primärliteratur |
| Kapitel | Liste mit Wortzahl je Kapitel |
| Marker | Anzahl OFFEN, Anzahl UNKLAR, Anzahl ohne erläuternden Satz |
| Apparat | Vorhandensein von Abstract, Methodik, Sicherheitsangaben, road log, Teilnehmerliste, Diskussion, Anhang |
| Ordnungsprinzip | Reihenfolge der Kapitel: Route oder Erkenntnis |
| Tempus und Person | prospektiv oder retrospektiv, dritte Person oder erste |

Die Zahlen werden im Analysedokument festgehalten. Sie sind die Grundlage jedes späteren Befundes und werden beim Ändern nachgezählt, nicht fortgeschrieben.

## Phase 2: Kandidaten bestimmen

Aus der Bestandsaufnahme ergeben sich die Kandidaten. Die Zuordnung wird begründet, und zwar mit den gefundenen Merkmalen, nicht mit dem Titel des Dokuments. Ein Dokument, das "Exkursionsbericht" heißt, aber Fahranweisungen und Treffpunkte trägt, hat den Exkursionsführer als Kandidaten.

Leitmerkmale: Fahranweisungen und Uhrzeiten zeigen den Führer. Teilnehmerliste und Rückblick zeigen den Nachbericht. Eine einzige Fundstelle mit Stufenfotos zeigt den Fundstellenbericht. Kartenblatt und Profilschnitte zeigen den Kartierbericht. Eine Frage, die der Text beantwortet, zeigt den Projektbericht. Eine Ressourcenzahl zwingt in das regulierte Regime.

Zu jedem Kandidaten wird gesagt, was für ihn spricht und was gegen ihn. Der Kandidat mit den meisten vorhandenen Merkmalen ist der **Istzustand**, nicht das Ziel. Die übrigen sind mögliche Zielzustände.

## Phase 3: Konformitätsmatrix

Je Kandidat eine Tabelle nach `references/pruefraster.md`:

| Spalte | Inhalt |
|---|---|
| Pflichtelement | aus dem Prüfraster, Wortlaut unverändert |
| Stand | ERFÜLLT, TEILWEISE, FEHLT, NICHT ANWENDBAR |
| Beleg | Fundstelle im Bericht oder Zählergebnis aus Phase 1 |
| Aufwand | Anzahl der betroffenen Abschnitte, nicht Stunden |
| Quelle | vorhanden im Material, oder AUTOR, wenn nur der Verfasser die Angabe hat |

TEILWEISE verlangt die Angabe, was fehlt. NICHT ANWENDBAR verlangt die Begründung, warum das Element bei diesem Bericht entfällt.

Unter jeder Matrix steht eine Zeile mit der Auszählung: erfüllt von gesamt, davon wie viele nur mit Angaben des Autors zu schließen sind. Diese Zahl ist die eigentliche Aussage der Analyse.

## Phase 4: Kern und Delta trennen

Der wichtigste Schritt, und der, der die Analyse von einer Mängelliste unterscheidet.

**Kern.** Maßnahmen, die in jeder Kandidatenmatrix auftauchen, sind typunabhängig. Sie werden aus allen Einzelplänen herausgezogen und in einen eigenen Plan gestellt. Sie sind sofort ausführbar, weil sie von der noch offenen Typentscheidung nicht abhängen. Der Kern trägt regelmäßig die Georeferenzierung, den Quellenapparat, die Abbildungsformalia, die Markerdisziplin und die Trennung von Beobachtung und Deutung.

**Delta.** Was nur ein einzelner Kandidat zusätzlich verlangt, steht allein in dessen Plan. Ein Delta-Plan enthält nichts, was schon im Kernplan steht.

**Rückbau ist eine Maßnahme.** Ein Element, das der Zieltyp ausdrücklich nicht verlangt, wird nicht stehengelassen, weil es schon da ist. Sicherheits- und Anfahrtsangaben in einem Nachbericht, Diskussionskapitel in einem Führer: Solche Maßnahmen lauten "entfernen" oder "in den Anhang verschieben" und gehören in den Delta-Plan.

## Phase 5: Arbeitspläne schreiben

Die Form der Pläne kommt aus `science-arbeitsplan-erstellen` und wird hier nicht wiederholt. Verbindlich davon: Blöcke mit begründeter Reihenfolge, Schritte mit Kennung, Auftrag im Wortlaut, Ergebnis, prüfbarem Abbruchkriterium und Abhängigkeit, Entscheidungspunkte in den zwei Sorten D und D Z, Abnahmekriterien mit Angabe der fehlbaren, Fortschrittstabelle, Abschlussregel.

Fachlich kommt hinzu:

- **Das Abbruchkriterium ist eine Zahl aus Phase 1.** "Alle Lokalitäten georeferenziert" ist untauglich, weil ein Marker es erfüllt. "17 von 17 Lokalitäten mit Koordinate und Bezugssystem, oder mit OFFEN und einem Satz dazu, warum" ist prüfbar.
- **Jede Maßnahme nennt den Ort im Bericht und die Quelle des Inhalts.** Fehlt die Quelle, steht dort AUTOR, und die Maßnahme wandert in die Liste dessen, was ohne Rückfrage nicht geht.
- **Reihenfolge nach Fehleranfälligkeit.** Was den Text an vielen Stellen berührt, kommt zuerst, sonst prüft der zweite Block einen Zustand, den der erste bereits geändert hat. Umnummerierungen und Umstellungen gehen inhaltlichen Ergänzungen voraus.
- **Der Typwechsel wird ausgezählt, nicht behauptet.** Steht ein Wechsel im Raum, nennt der Plan, wie viele Abschnitte betroffen sind, wie viele Elemente hinzukommen und wie viele zurückgebaut werden. Erst diese Zahl macht die Zweckentscheidung entscheidbar.

## Ausgabe

Mehrere Dateien mit demselben Datumsstempel:

1. `<Bericht>_Typenanalyse_<JJJJMMTT>.md`
   - Kopf: geprüftes Dokument, Fassung, Datum, Annahme über den Bearbeitungsstand
   - Lesehinweis: Die Bestandsaufnahme und die Matrizen sind der Befund des Erstellungstags und bleiben unverändert; der laufende Stand steht in den Fortschrittstabellen der Pläne; bei Widerspruch gilt die Tabelle. Dieser Absatz ist nicht optional.
   - Urteil in einem Satz: Istzustand, die tragfähigste Zielgattung und die eine Lücke, die alle Kandidaten teilen
   - Was trägt: was der Bericht in seinem Istzustand bereits leistet. Vor den Mängeln, sonst wird die Analyse als Verriss gelesen und nicht abgearbeitet
   - Bestandsaufnahme mit allen Zahlen aus Phase 1
   - Kandidaten mit Begründung
   - je Kandidat die Konformitätsmatrix
   - die Zweckentscheidung D Z 1 zur Typwahl, mit ausgezählten Folgen je Möglichkeit und ohne Empfehlung
   - Verweis auf die Plandateien
2. `<Bericht>_Work_Plan_Kern_<JJJJMMTT>.md`, sofort ausführbar
3. `<Bericht>_Work_Plan_<Typkuerzel>_<JJJJMMTT>.md` je Kandidat, ausführbar erst nach D Z 1

Diese Dateien sind Arbeitsdokumente. Statusspalten, Erledigungsvermerke und Datumsangaben gehören hinein. Aus dem Bericht selbst bleiben sie heraus.

## Verhältnis zu den anderen Prüfachsen

Befunde, die in eine andere Achse gehören, werden benannt und weitergegeben, nicht hier behandelt.

| Befund | Achse |
|---|---|
| Aussage ohne Beleg, Beleg trägt die Aussage nicht | `science-faktenbeleg-pruefung` |
| Dokument widerspricht sich, Zahlen stimmen nicht überein | `science-interne-konsistenz-pruefung` |
| Literaturverzeichnis fehlerhaft, DOI löst nicht auf | `science-quellenapparat-pruefung` |
| Bericht leistet für seine Leser nicht, was er soll | `science-dokumentkritik-drei-sichten` |
| Fundstelle falsch identifiziert, Regionsangabe als Punktangabe | `geo-fundstellen-evidenz-pruefung` |
| Eine einzelne strittige Fachfrage | `geo-frage-belegbasiert-klaeren` |
| Ein einzelner Entscheidungspunkt soll aufgelöst werden | `science-entscheidungspunkt-klaeren` |

Sinnvolle Reihenfolge: erst diese Typenanalyse, denn sie entscheidet, welche Elemente der Bericht überhaupt braucht, dann Faktenbeleg und Konsistenz für das, was bleibt. Wer zuerst Belege für Abschnitte sucht, die der Zieltyp gar nicht verlangt, arbeitet umsonst.

Nach einer Reihe abgearbeiteter Maßnahmen folgt ein Konsistenzlauf, weil jede Umstellung Nummern, Verweise und Zählungen verschiebt.

## Rückfragen

Höchstens zwei, einzeln und nacheinander, und nur wenn die Antwort den Zuschnitt der Analyse ändert. Nicht fragen, was aus dem Bericht selbst hervorgeht, und den Typ nicht erfragen: ihn zu bestimmen ist die Aufgabe.

Zulässig ist die Frage nach dem Zielort der Publikation, wenn der Bericht keinen erkennen lässt, denn die Vorgabe eines Zielorgans geht jedem Gattungsstandard vor.

## Häufige Fehler

- **Nur gegen einen Typ prüfen.** Dann ist die Analyse eine Mängelliste und nimmt die Entscheidung vorweg, die dem Autor zusteht.
- **Kern und Delta vermischen.** Der Autor kann dann nichts tun, solange die Typfrage offen ist, und die Analyse bleibt liegen.
- **Rückbau vergessen.** Es wird nur ergänzt, nie entfernt, und der Bericht wird mit jedem Durchgang unschärfer in seiner Gattung.
- **Die Bestandsaufnahme fortschreiben.** Sobald sie mit den Plänen mitläuft, geht die Ausgangslage verloren, gegen die der Fortschritt gemessen wird.
- **Aufwand in Stunden schätzen.** Unprüfbar. Gezählt wird in betroffenen Abschnitten.
- **Den Typ aus dem Titel nehmen.** Titel sind Absichtserklärungen, die Merkmale im Text sind der Befund.

## Herkunft und Prüfstand

Der Skill entstand am 2026-09-19 zusammen mit `geo-exkursionsbericht-erstellen` aus der Konsolidierung von vier Rechercheberichten. Die Pflichtelemente im Prüfraster sind für GSA, GFT&M, IODP, NI 43-101, AWI und Mindat aus Primärquellen belegt; für die informellen Gattungen sind sie Konvention und als solche im Raster gekennzeichnet.

Der Skill ist erprobt, am Germany-Bericht in der Fassung v13 vom 2026-09-19: geprüft gegen vier Kandidatengattungen; der Bericht erfüllte 9 von 11 Pflichten eines Exkursionsberichts, und der Autor wählte den Projektbericht als Zielgattung. Wer ihn anwendet, meldet zurück, wie viele Kandidaten sich ergeben haben und wie groß der Kernplan gegenüber den Delta-Plänen ausfiel. **Ein Kernplan, der fast alles enthält, ist ein Befund über die Kandidatenauswahl: dann lagen die Typen zu nah beieinander.**