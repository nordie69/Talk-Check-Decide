---
name: "science-arbeitsplan-erstellen"
description: "Schreibt vor der Ausführung einen prüfbaren Arbeitsplan für ein Vorhaben: Blöcke mit begründeter Reihenfolge, Schritte mit Auftrag, Ergebnis und Abbruchkriterium, Entscheidungspunkte in zwei Sorten, Abnahmekriterien mit Angabe der fehlbaren, eine Fortschrittstabelle und die Pflicht, eigene Vorarbeiten beim Erledigen zu entfernen. Der Plan ist die Ausgabe, nicht die Ausführung. Immer verwenden bei, Arbeitsplan erstellen, Vorgehen planen, wie gehen wir das an, bevor wir anfangen, Plan für die Abarbeitung, in welcher Reihenfolge."
metadata:
  version: "2.1.0"
---

# Arbeitsplan erstellen

Der Rahmen für jeden Arbeitsplan, unabhängig vom Gegenstand, auch für geologische Berichte. Fachliche Skills, die eigene Pläne schreiben, etwa `geo-exkursionsbericht-typenanalyse`, übernehmen diese Form und ergänzen nur ihr Fachliches.

Ein Plan ist nicht die Aufzählung dessen, was zu tun ist. Er ist der Versuch, vor der Ausführung herauszufinden, woran sie scheitern wird. Ein Plan, der nichts gefunden hat, war überflüssig.

## Grundregeln

- **Der Plan ändert nichts.** Wer ihn schreibt, führt ihn nicht im selben Zug aus. Das ist keine Formsache: Die Erhebung für den Plan deckt regelmäßig auf, dass eine Voraussetzung fehlt, und dann ändert sich der Zuschnitt.
- **Voraussetzungen werden geprüft, nicht angenommen.** Wer eine Quelle als Grundlage nennt, sieht vorher hinein. Ein Plan, der auf eine leere Datei baut, erzeugt nur Arbeit.
- **Sprache:** Der Plan steht in der Sprache des Nutzers, denn er ist eine Arbeitsanweisung, kein Teil des Ergebnisses.
- **Keine Em-Dashes, keine doppelten Bindestriche.**

## Pflichtteil

Diese sechs Elemente hat jeder Plan.

### 1. Blöcke mit begründeter Reihenfolge

Nicht nach Nummer ordnen, sondern nach Fehleranfälligkeit oder Abhängigkeit. Jede Position bekommt eine Begründung, warum sie dort steht und nicht woanders. Wo die Begründung nicht gelingt, ist die Reihenfolge beliebig, und das gehört gesagt.

Ein Block wird vollständig abgeschlossen, bevor der nächste beginnt, wenn die Blöcke dieselben Stellen berühren. Sonst prüft der zweite einen Zustand, den der erste schon geändert hat.

### 2. Schritte mit prüfbarem Abbruchkriterium

Jeder Schritt bekommt: Kennung, Auftrag im Wortlaut, Ergebnis, Abbruchkriterium, Abhängigkeit, und wo vorhanden den Skill.

**Das Abbruchkriterium muss scheitern können.** "Jede Aussage ist belegt oder markiert" ist untauglich, weil die Markierung es immer erfüllt. Brauchbar ist eine Obergrenze oder eine Zählung, die man nachrechnen kann.

### 3. Entscheidungspunkte, zwei Sorten

**Sachentscheidung, gekennzeichnet mit D.** Es gibt eine belegbar bessere Antwort. Die Möglichkeiten werden vorgelegt, die Folgen ausgezählt, und eine wird empfohlen. Die Empfehlung muss so begründet sein, dass sie ohne Einsicht in die Quelle prüfbar ist.

**Zweckentscheidung, gekennzeichnet mit D Z.** Beide Antworten sind sachlich richtig, und die Wahl hängt davon ab, was das Ergebnis leisten soll. Hier werden die Folgen ausgezählt und ausdrücklich keine Empfehlung gegeben, weil eine Empfehlung eine Entscheidung vorwegnähme, die dem Auftraggeber zusteht.

Das Kriterium ist scharf zu halten. Eine Zweckentscheidung liegt nur vor, wenn beide Antworten sachlich richtig sind. Wer jede zweite Frage so kennzeichnet, um keine Empfehlung geben zu müssen, macht die Unterscheidung wertlos.

Das Auflösen eines einzelnen Entscheidungspunkts, also das Auszählen der Folgen bis zu einer anwendbaren Regel, führt `science-entscheidungspunkt-klaeren`. Dieser Skill legt Entscheidungspunkte an, jener löst sie auf.

### 4. Abnahmekriterien, davon die fehlbaren benannt

Kriterien, an denen sich prüfen lässt, ob der Plan erfüllt ist. Am Ende steht, welche davon fehlbar sind, also welche tatsächlich scheitern können. Die übrigen sind Buchführung; sie schaden nicht, aber sie sichern nichts.

### 5. Fortschrittstabelle

Je Block eine Zeile mit Schritten und Stand. Zustände: offen, erledigt mit Datum, teilweise mit Angabe was fehlt.

### 6. Abschlussregel

**Beim Erledigen eines Punktes werden die eigenen Vorarbeiten dazu entfernt.** Ein Abschnitt, der einen Punkt als vertagt begründet, ein ausgearbeitetes Muster, eine Zwischenerhebung: Sobald der Punkt erledigt ist, beschreiben sie einen Zustand, den es nicht mehr gibt, und widersprechen der Statustabelle desselben Dokuments.

Die Regel gilt auch für abgeleitete Zahlen. Steht eine Zahl im Ergebnis, die aus dem Plan stammt, wird sie bei jeder Änderung nachgezählt und nicht aus dem Gedächtnis fortgeschrieben.

Sie gilt ebenso für Namen und Kennungen, die der Plan vergibt. Wird ein Anhang, ein Block oder eine Datei im Plan vorgemerkt und trägt dabei einen Buchstaben oder eine Nummer, ist beim Erledigen zu prüfen, ob diese inzwischen anderweitig vergeben ist.

## Für umfangreiche Vorhaben

Diese vier Abschnitte haben sich bei großen Dokumenten bewährt und dürfen bei kleinen Vorhaben entfallen.

**Vorüberlegung korrigieren.** Ein Abschnitt 0, der festhält, welche Annahme aus der Vorbesprechung der Prüfung nicht standgehalten hat. Er verhindert, dass der Plan auf einer Grundlage steht, die beim Schreiben bereits widerlegt war.

**Entscheidungen des Auftraggebers.** Was vorab entschieden wurde und den Zuschnitt bestimmt. Später ist sonst nicht nachvollziehbar, warum der Plan so aussieht.

**Regeln für diesen Durchgang.** Was durchgehend gilt, etwa welche Quelle vorgeht oder was unangetastet bleibt.

**Was schiefgehen kann.** Der wahrscheinlichste Fehler, benannt bevor er eintritt. Dieser Abschnitt rechtfertigt den ganzen Plan, wenn er trifft.

**Was der vorige Durchgang gelehrt hat.** Wo dasselbe Verfahren schon einmal gelaufen ist, gehört an den Anfang, was es ergeben hat und was daraus für die Auswahl folgt. Anders als die Vorüberlegungskorrektur betrifft das nicht eine widerlegte Annahme, sondern eine bestätigte Erfahrung.

**Warum dieser Gegenstand anders zu behandeln ist.** Wo das Verfahren bekannt ist, der Gegenstand aber einen eigenen Fehlertyp hat, wird dieser vorab benannt. Er bestimmt dann den Zuschnitt der Blöcke.

**Verhältnis zu einem parallelen Vorhaben.** Wo zwei Pläne dieselben Stellen auf verschiedenen Achsen bearbeiten, gehört ihre Reihenfolge in beide. Ohne diesen Abschnitt prüft der eine Belege für Aussagen, die der andere anschließend umformuliert.

**Umfang und Etappen.** Wo der Plan zu groß für eine Sitzung ist, wird das gesagt und eine Etappenfolge vorgeschlagen. Ein Plan, der seine eigene Größe verschweigt, wird begonnen und nicht beendet.

## Rückfragen

Höchstens drei, einzeln und nacheinander, und nur wenn die Antwort den Zuschnitt ändert. Nicht fragen, was aus dem Gegenstand selbst hervorgeht.

Fragen, deren Antwort nur der Auftraggeber kennt, gehören nicht vor den Plan, sondern in ihn, als Entscheidungspunkt an der Stelle, an der sie gebraucht werden.

## Ausgabe

Eine Markdown-Datei, benannt nach dem Schema des Projekts, sonst `<Vorhaben>_Work_Plan_<JJJJMMTT>.md`. Reihenfolge der Abschnitte: die vier für umfangreiche Vorhaben zuerst, soweit vorhanden, dann Blöcke, Schritte, Abnahme, Fortschritt.

## Herkunft und Prüfstand

Dieser Skill entstand am 2026-09-17 aus drei Arbeitsplänen zu demselben Dokument, einem geologischen Exkursionsbericht. Der Pflichtteil hat dort dreimal getragen; der Teil für umfangreiche Vorhaben ist nur an diesem einen Gegenstand erprobt.

Der Skill wurde am selben Tag gegen diese drei Pläne geprüft. Die Abschlussregel hätte vier von fünf veralteten Abschnitten verhindert; der fünfte war eine Buchstabenkollision und führte zum zweiten Absatz der Abschlussregel. Vier Abschnitte der drei Pläne fanden im ersten Entwurf keine Entsprechung und sind seither im Teil für umfangreiche Vorhaben aufgeführt.

Wer den Skill zum ersten Mal auf etwas anderes anwendet, achtet darauf, welche Abschnitte leer bleiben, und meldet das zurück. **Ein leerer Abschnitt ist ein Befund über den Skill, nicht über den Plan.**
