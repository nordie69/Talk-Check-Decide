---
name: "science-faktenbeleg-pruefung"
description: "Prüft in vier Phasen, ob die Aussagen eines Textabschnitts durch die angegebenen Quellen gedeckt sind: Faktentabelle mit Quelle und Geltungsbereich, Prüfung in den Originalquellen, Recherche peer-reviewed Ersatzquellen, Einarbeitung samt Referenzverzeichnis und Änderungsreport als Markdown. Immer verwenden bei: Fakten prüfen, Faktentabelle, Quellen prüfen, Belegprüfung, sind die Aussagen belegt, fehlende Quellen ergänzen, Referenzen korrigieren."
metadata:
  version: "2.0.0"
---

# Faktenbeleg-Prüfung

Vierphasiges Verfahren, das die Aussagen eines Textabschnitts gegen die genannten Quellen prüft, Lücken durch begutachtete Literatur schließt und die Korrekturen dokumentiert einarbeitet.

Die vier Phasen laufen getrennt und in dieser Reihenfolge. Phase 1 ist reine Erfassung ohne Bewertung. Erst Phase 2 bewertet. Zwischen den Phasen wird der Zwischenstand ausgegeben, damit der Nutzer eingreifen kann.

## Grundregeln

- **Sprache**: Alle Ausgaben dieses Skills stehen in der Sprache des geprüften Dokuments, unabhängig von der Sprache, in der der Nutzer schreibt. Das gilt für die Faktentabellen, die Spaltenüberschriften, die Werte der Spalten Scope und Status, die Befundmeldungen und Zwischenstände im Chat, die Vorschlagstabelle der Phase 3, den Dateinamen und den gesamten Inhalt des Änderungsreports. Ist die Sprache des Dokuments nicht eindeutig, gilt die Sprache des Fließtextes im geprüften Abschnitt. Ein einzelner Satz zur Einordnung darf in der Sprache des Nutzers vorangestellt werden, die Tabellen und Befunde selbst nicht.

  Standardbezeichnungen für die beiden häufigsten Fälle:

  | Feld | Deutsch | Englisch |
  |---|---|---|
  | Spalten Phase 1 | Nr., Aussage, Im Text genannte Quelle, Geltungsbereich | No., Statement, Source cited in the text, Scope |
  | Geltungsbereich | Satz, Satzgruppe (wahrscheinlich), Absatz, keine | sentence, sentence group (probable), paragraph, none |
  | Status Phase 2 | verifiziert, teilweise verifiziert, nicht prüfbar, Fehlzuordnung | verified, partly verified, not verifiable, wrong attribution |
  | Report-Kapitel | Zusammenfassung, Faktentabelle mit Prüfergebnis, Einzelne Änderungen, Referenzverzeichnis, Offene Punkte | Summary, Fact table with verification result, Individual changes, Reference list, Open points |
  | Dateiname | <Dokument>_Pruefreport_<JJJJMMTT-HHMM>.md | <document>_check_report_<YYYYMMDD-HHMM>.md |
- **Keine stille Änderung**: Am Dokument wird erst nach ausdrücklicher Freigabe des Nutzers etwas geändert (Phase 4). Die Phasen 1 bis 3 liefern nur Tabellen.
- **Nichts erfinden**: Wenn eine Quelle nicht auffindbar ist, wird das so vermerkt. Keine Belegstelle behaupten, die nicht gelesen wurde. Keine DOI aus dem Gedächtnis konstruieren.
- **Referenzen sind der kritischste Teil der Prüfung**: Bei jeder Referenz, die in einem geprüften Abschnitt zitiert wird, sind drei Dinge einzeln zu klären, und keines davon darf aus dem Gedächtnis beantwortet werden. Erstens die bibliografische Richtigkeit: Autorenliste vollständig und in der richtigen Reihenfolge, Jahr, Titel, Zeitschrift, Band, Heft, Seiten oder Artikelnummer. Zweitens die Auflösbarkeit des Links: Die DOI muss auf genau diese Arbeit führen, nicht auf eine andere desselben Autors oder Bandes. Drittens, und das ist der eigentliche Kern, die inhaltliche Deckung: Trägt die Arbeit die Aussage, für die sie zitiert wird? Eine formal einwandfreie Referenz, die etwas anderes behandelt, ist ein schwererer Fehler als eine unvollständige Angabe. Jede dieser drei Prüfungen wird gegen Verlagsseite, Crossref oder eine gleichwertige Quelle geführt, nicht gegen die Erinnerung. Seitenzahlen, Bandnummern oder Artikelnummern, die sich nicht bestätigen lassen, werden weggelassen statt geschätzt; eine geschätzte Seitenangabe ist eine Falschangabe. Besondere Vorsicht gilt bei mehrteiligen Arbeiten (Teil I und Teil II derselben Autorengruppe), bei Sammelbandkapiteln, bei Arbeiten mit ähnlichem Titel desselben Autors und bei Institutsreihen ohne durchgehende Paginierung.
- **Eigennamen nie aus dem Gedächtnis bilden**: Taxonnamen, Formationsnamen, Ichnotaxa, Mineralnamen, Kartenblattnamen und Personennamen werden vor jeder Aufnahme in einen Text gegen die Originalbeschreibung, ein amtliches Verzeichnis oder eine fachliche Datenbank geprüft. Aus dem Gedächtnis zusammengesetzte Kombinationen sind die gefährlichste Fehlerquelle, weil sie plausibel aussehen und mit einer Quellenangabe daneben glaubwürdig wirken. Gattung und Art gehören zusammen: Wird nur ein Teil erinnert, ist der ganze Name zu prüfen. Ist ein Name nicht verifizierbar, wird er nicht genannt oder als unbestätigt gekennzeichnet, nicht durch eine Aufforderung an den Leser ersetzt, die Originalbeschreibung selbst nachzuschlagen.
- **Klasse der Aussage vor Klasse der Quelle bestimmen**: Bevor eine Quelle bewertet wird, ist zu entscheiden, ob die Aussage eine Sachaussage über den Gegenstand ist oder eine Angabe über eine Einrichtung. Die beiden Klassen haben verschiedene Quellenrangfolgen, siehe Phase 3. Wer das übergeht, verlangt für eine Öffnungszeit einen begutachteten Beleg und akzeptiert für ein Fossilalter eine Museumsseite.
- **Zitatrecht**: Aus jeder Quelle höchstens ein wörtliches Zitat von unter 15 Wörtern, alles Übrige paraphrasieren.
- **Ein Report je Prüfung**: Jeder angeforderte Prüflauf erzeugt eine eigene, neue Report-Datei. Bestehende Reports früherer Läufe werden nicht überschrieben und nicht erweitert, auch wenn dasselbe Dokument erneut geprüft wird. Das gilt auch bei kleinen Korrekturen und auch dann, wenn ein Lauf ohne Änderung am Dokument endet.
- **Mehrfachaussagen-Register führen**: Neben dem Prüfreport wird zu jedem geprüften Dokument ein Register der Aussagen gepflegt, die an mehreren Stellen vorkommen: Zahlen, Altersangaben, Stufen- und Formationsnamen, Taxon- und Ortsnamen, mehrfach verwendete Quellenzuordnungen und erklärte Konventionen. Es liegt als eigene Markdown-Datei neben dem Dokument, heißt `<Dokument>_Mehrfachaussagen-Register.md` (englisch: `<document>_cross-reference-register.md`) und wird bei jedem Lauf ergänzt und bei neuen Erkenntnissen aktualisiert. Ohne dieses Register bleiben Korrekturen regelmäßig auf einen Abschnitt beschränkt, während dieselbe Aussage anderswo unverändert stehen bleibt.
- **Zeitstempel im Dateinamen**: Der Dateiname trägt immer Datum und Uhrzeit im Format `JJJJMMTT-HHMM`, damit mehrere Läufe desselben Tages unterscheidbar bleiben. Die Uhrzeit ist die des Prüfbeginns.

## Phase 1: Faktentabelle erstellen

Reine Erfassung. Keine Bewertung, keine Recherche, keine Empfehlung in dieser Phase.

Den Abschnitt Satz für Satz durchgehen und jede überprüfbare Aussage als eigene Zeile aufnehmen. Ein Satz mit mehreren unabhängigen Aussagen (Aufzählungen, Jahreszahlen, Ortsangaben) wird in mehrere Zeilen zerlegt. Nicht aufgenommen werden reine Überleitungen, Verweise auf andere Kapitel und Aussagen über den Aufbau des Dokuments selbst.

**Geltungsbereich der Quellenangabe.** Eine Quelle am Satzende belegt oft nicht nur diesen Satz, sondern auch die vorangehenden Sätze desselben Gedankengangs. Das ist bei wissenschaftlichen Texten der Normalfall und muss abgebildet werden. Für jeden Fakt eine der vier Einstufungen vergeben:

| Einstufung | Bedeutung |
|---|---|
| `Satz` | Die Quelle steht am Ende genau dieses Satzes. |
| `Satzgruppe, wahrscheinlich` | Der Fakt steht in einem unbelegten Satz, der einem belegten Satz desselben Absatzes vorausgeht und thematisch zu ihm gehört; die Quelle deckt ihn vermutlich mit. |
| `Absatz` | Die Quelle steht am Ende des Absatzes und deckt den ganzen Absatz ab. |
| `keine` | Kein Beleg zuordenbar. |

Faustregeln für die Einstufung: Ein Themenwechsel innerhalb des Absatzes beendet den Geltungsbereich. Zahlen, Datierungen und Eigennamen, die im belegten Satz nicht vorkommen, sind vorsichtiger einzustufen. Steht am Absatzende keine Quelle, gibt es keinen absatzweiten Geltungsbereich; dann kommt höchstens `Satzgruppe, wahrscheinlich` in Frage.

Ausgabeformat der Tabelle:

| No. | Statement | Source cited in the text | Scope |
|---|---|---|---|

Nach der Tabelle nichts weiter, außer einem Hinweis, wie viele Fakten erfasst wurden. Die Bewertung folgt in Phase 2.

## Phase 2: Belegstellen in den Originalquellen prüfen

Jetzt jede genannte Quelle aufsuchen und prüfen, ob sie den Fakt tatsächlich trägt.

1. Zugang über die DOI oder den Link aus dem Referenzverzeichnis des geprüften Dokuments suchen. Erst `web_search` nach Titel und Autoren, dann den Treffer per `web_fetch` öffnen; ein DOI-Link lässt sich nicht direkt abrufen, wenn er nicht vorher in einem Suchergebnis stand.
2. Fundstelle so genau wie möglich benennen: Abstract, Kapitel, Abbildungslegende, Seite. Ein kurzes wörtliches Zitat (unter 15 Wörter) je Quelle ist erlaubt, der Rest wird paraphrasiert.
3. Bei Zugangsbeschränkung: Abstract, Autoren-PDF, Repositorium oder eine zitierende Arbeit nutzen. Der Abstract ist dabei kein Notbehelf, sondern ein regulärer Beleg; der Umfang des Zugangs wird nur dann vermerkt, wenn die Aussage über das hinausgeht, was der Abstract behandelt.
   Reicht auch das nicht, folgt als letzte Stufe vor "nicht prüfbar" die **Beschaffung durch den Nutzer**: Dem Nutzer wird der direkte Link oder die DOI genannt, eine Quelle je Nachricht, und erst nach seiner Antwort die nächste. Er lädt die PDF herunter oder beschafft sie und hängt sie an. Bei einem Band ohne Onlinezugang werden Titel, Reihe, ISBN und das gesuchte Kapitel genannt, damit er in seinen eigenen Beständen suchen kann, dazu, welche Seiten oder Stellen genügen. Aus der gelieferten Datei werden nur die benötigten Stellen gelesen, jeder Befund trägt die Seitenzahl, und neuer Wortlaut wird vor dem Einfügen vollständig vorgelegt. Im Prüfreport erhält der Beleg die Herkunftsangabe "vom Nutzer bereitgestellt". Erst wenn der Nutzer die Quelle nicht beschaffen kann, gilt der Fakt als "nicht prüfbar".
4. Beim Prüfen den Geltungsbereich aus Phase 1 anwenden: Ein Fakt der Stufe `Satzgruppe, wahrscheinlich` gilt als belegt, wenn die Quelle ihn inhaltlich abdeckt, auch wenn er im Text keine eigene Klammer trägt.

Status je Fakt: `verifiziert`, `teilweise verifiziert` (Kernaussage ja, Detail nicht), `nicht prüfbar` (Quelle nicht zugänglich), `Fehlzuordnung` (Quelle behandelt das Thema nicht).

Die häufigste Fehlzuordnung ist keine falsche Quelle, sondern eine eigene Schlussfolgerung innerhalb einer belegten Klammer. Ein Satz, der eine gelesene Angabe und einen daraus gezogenen Schluss zusammenfasst und am Ende eine Quelle trägt, gibt den Schluss als Quellenaussage aus. Beim Prüfen ist deshalb Teilsatz für Teilsatz zu fragen, ob die Quelle ihn trägt, nicht nur der Satz als Ganzes.

Vor der Tabelle eine kurze Übersicht ausgeben, welche Quellen in welchem Umfang zugänglich waren.

## Phase 3: Peer-reviewed Belege recherchieren

Für alle Fakten mit Status `nicht prüfbar`, `Fehlzuordnung`, `teilweise verifiziert` und für alle mit Scope `keine`.

Vorher drei Punkte klären, wenn sie nicht aus dem Gespräch hervorgehen: Umfang der Recherche, Umgang mit den bestehenden Quellen (behalten und ergänzen, ersetzen, oder nur Vorschlag ohne Änderung), und ob Open Access bevorzugt werden soll.

Zugelassen sind begutachtete Zeitschriftenaufsätze, Kapitel in begutachteten Sammelbänden und wissenschaftliche Monografien. Nicht zugelassen sind Wikipedia, Tourismus- und Betreiberseiten, Blogs und Verkaufslisten. Amtliche Publikationen geologischer oder statistischer Landesämter sind zulässig, wenn sie zitierfähig sind, und werden als solche gekennzeichnet.

**Ausnahme für institutionelle Angaben.** Die vorstehende Rangfolge gilt für Sachaussagen über den Gegenstand, also Geologie, Stratigraphie, Taxonomie, Datierungen, Messwerte. Für Angaben über eine Einrichtung gilt sie nicht: Gründungs- und Umbaudaten, Sammlungsumfang, Öffnungszeiten, Preise, Zugangsregeln, Ausstattung, Laufzeiten von Wechselausstellungen, Wegelängen und Geländeanlagen. Solche Angaben stehen nicht in begutachteter Literatur, und dort nach ihnen zu suchen ist verlorene Zeit.

Für sie gilt eine eigene Rangfolge:

1. Die Selbstauskunft der Einrichtung oder des Betreibers, also die eigene Webseite, ein Jahresbericht, ein Faltblatt, eine Pressemitteilung des Hauses.
2. Die zuständige Gebietskörperschaft oder Aufsichtsstelle, also Gemeinde, Landkreis, Landesamt, Kulturportal des Landes.
3. Jede andere greifbare Quelle, nur wenn die ersten beiden schweigen, und dann als einzige gefundene gekennzeichnet.

Die Selbstauskunft ist damit für diese Klasse die zulässige Höchststufe und kein Notbehelf. Ein Fakt dieser Klasse, der durch die Selbstauskunft gedeckt ist, gilt als verifiziert und erzeugt keinen Rechercheauftrag in Phase 3.

Zwei Einschränkungen bleiben. Erstens gilt die Ausnahme nicht für Superlative und Rangaussagen über die Einrichtung selbst, etwa zweitgrößtes Haus des Landes, größte Sammlung ihrer Art, einzige Anlage Europas. Diese sind zu prüfen wie jede andere Sachaussage, denn manche stammen von der Einrichtung, viele aber von Dritten, und der Unterschied ist für den Leser nicht erkennbar. Trägt die Einrichtung den Superlativ nicht selbst, wird er im Text als Fremdzuschreibung gekennzeichnet, nicht stillschweigend übernommen. Zweitens bleibt die Selbstauskunft ungeeignet für Aussagen über den Gegenstand, die die Einrichtung nebenbei macht: Eine Museumsseite ist kein Beleg für ein Fossilalter, auch wenn sie eines nennt.

Jeder Vorschlag braucht: vollständige Harvard-Angabe, DOI als Link, Angabe der Fundstelle innerhalb der Quelle und einen Satz dazu, was genau die Quelle abdeckt. Die DOI immer gegen Verlag oder Crossref prüfen, nie aus dem Gedächtnis bilden. Ergebnis als Vorschlagstabelle, noch ohne Eingriff ins Dokument.

## Phase 4: Einarbeiten und Änderungsreport

Erst nach Freigabe. Reihenfolge:

0. **Register befragen**: Vor der ersten Änderung im Mehrfachaussagen-Register nachsehen, ob die betroffene Aussage dort geführt wird. Wenn ja, sind alle dort genannten Fundstellen mitzuändern, nicht nur die des geprüften Abschnitts. Existiert noch kein Register, wird es in diesem Lauf angelegt.
1. **Text ändern**: Zitate an den betreffenden Stellen ergänzen oder austauschen. Mehrere Quellen in einer Klammer mit Semikolon trennen, chronologisch ordnen. Die Zitierform des Dokuments übernehmen (Dreiautorenwerke ausgeschrieben, "et al." erst ab vier Autoren, sofern das Dokument es so hält).
2. **Referenzverzeichnis pflegen**: Neue Einträge im Format des Dokuments ergänzen und alphabetisch einsortieren; bestehende Unterteilungen des Verzeichnisses beachten. Eine Quelle wird nur dann entfernt, wenn sie nach der Korrektur an **keiner** Stelle des Fließtextes mehr vorkommt. Das ist maschinell zu prüfen, nicht nach Gefühl.
3. **Gegenprüfung**: Jede Klammer im Text hat einen Eintrag, jeder Eintrag mindestens eine Nennung im Text, keine doppelten Buchstabenkennungen, alphabetische Ordnung intakt.
4. **Register fortschreiben**: Jede geänderte Aussage, die an mehr als einer Stelle steht, kommt mit allen Fundstellen, dem Datum des Laufs und einem kurzen Hinweis ins Register. Neu entdeckte Mehrfachaussagen werden aufgenommen, auch wenn sie in diesem Lauf nicht geändert wurden. Überholte Einträge werden korrigiert, nicht gelöscht.
5. **Prüfreport schreiben** und zusammen mit dem geänderten Dokument und dem Register ausgeben.

Das Prüfskript und die Formatvorlage des Reports stehen in den Anhängen A und B.

## Prüfreport und Register

Für jede angeforderte Prüfung entsteht genau eine neue Markdown-Datei neben dem geänderten Dokument, in der Sprache des geprüften Dokuments. Dateiname `<Dokumentname>_Pruefreport_<JJJJMMTT-HHMM>.md`, bei englischen Dokumenten `<document>_check_report_<YYYYMMDD-HHMM>.md`, zum Beispiel `Excursion_Report_check_report_20260908-1615.md`.

Ein früherer Report wird nie überschrieben oder fortgeschrieben. Wird dasselbe Dokument mehrfach geprüft, etwa Abschnitt für Abschnitt, entsteht je Lauf ein eigener Report; im Kopf wird vermerkt, welcher Abschnitt geprüft wurde und auf welchen früheren Report sich der Lauf gegebenenfalls bezieht. Aufbau (Überschriften in der Dokumentsprache):

```markdown
# Prüfreport: <Dokument>, Abschnitt <x.y>
Datum und Uhrzeit des Laufs, geprüfter Abschnitt, Anzahl Fakten, Anzahl Änderungen, Verweis auf frühere Reports zum selben Dokument

## 1. Zusammenfassung
Drei bis fünf Sätze: was geprüft wurde, wie viele Fakten belegt waren, was korrigiert wurde.

## 2. Faktentabelle mit Prüfergebnis
No. | Statement | Quelle vorher | Scope | Status | Quelle nachher

## 3. Einzelne Änderungen
Je Änderung: Fundstelle, Wortlaut vorher, Wortlaut nachher, Begründung, Beleg mit DOI.

## 4. Referenzverzeichnis
Hinzugefügt (mit DOI) / entfernt (mit Begründung, dass keine Nennung mehr vorliegt) / geändert.

## 5. Offene Punkte
Nicht prüfbare Fakten, gesperrte Quellen, bewusst unverändert Gelassenes.
```

## Typische Fehler

- Bewertung schon in Phase 1 einstreuen. Der Nutzer will erst die reine Erfassung sehen.
- Den Geltungsbereich zu eng ziehen und dadurch belegte Sätze als unbelegt melden.
- Eine Quelle aus dem Verzeichnis werfen, die an anderer Stelle noch zitiert wird.
- Buchstabenkennungen (2026 a, 2026 b) nach dem Löschen eines Eintrags nicht nachziehen.
- Tabellen, Statuswerte oder den Änderungsreport in der Sprache des Nutzers statt in der des Dokuments ausgeben.
- Einen Taxon- oder Formationsnamen aus dem Gedächtnis bilden, statt ihn zu prüfen.
- Eine Seitenzahl, Bandnummer oder Artikelnummer schätzen, weil sie plausibel erscheint.
- Eine Referenz als geprüft ausgeben, wenn nur ihr Titel gelesen wurde, ohne die inhaltliche Deckung zu klären.
- Eine im Abstract eindeutig gedeckte Aussage vorsichtshalber als "teilweise verifiziert" führen. Der Abstract ist Teil der begutachteten Publikation und genügt als Beleg.
- Den Prüfreport weglassen, weil die Änderung klein war oder gar nichts geändert wurde.
- Eine Aussage nur im geprüften Abschnitt korrigieren, obwohl sie laut Register auch anderswo steht.
- Das Register nach einem Lauf nicht fortschreiben.
- Einen bestehenden Report eines früheren Laufs erweitern, statt eine neue Datei mit eigenem Zeitstempel anzulegen.

---

## Anhang A: Prüfverfahren im Detail

Inhalt: A.1 Zerlegung in Fakten, A.2 Geltungsbereich bestimmen, A.3 Quellen aufsuchen, A.4 Referenzen prüfen, A.5 Eigennamen prüfen, A.6 Statusvergabe, A.7 durchgearbeitetes Beispiel.

### A.1 Zerlegung in Fakten

Ein Fakt ist eine Aussage, die für sich genommen wahr oder falsch sein kann und an einer Quelle überprüfbar wäre.

Zerlegen:
- Aufzählungen mit unterschiedlicher Belegsituation ("aufgeschlossen im Harz, im Erzgebirge und im Schwarzwald") in eine Zeile, solange dieselbe Quelle für alle Glieder in Frage kommt; in mehrere Zeilen, sobald die Glieder verschiedene Belege bräuchten.
- Zusammengesetzte Sätze mit Datierung plus Prozess ("wurde im Devon zusammengeschweißt und im Perm gedehnt") in zwei Zeilen.

Nicht aufnehmen:
- Verweise auf andere Kapitel ("wie in Abschnitt 3.1 gezeigt").
- Aussagen über den Bericht selbst ("Dieser Abschnitt behandelt...").
- Wertungen und Empfehlungen des Autors, sofern sie nicht als Tatsachenbehauptung formuliert sind.
- Eigene Beobachtungen des Autors, die als solche gekennzeichnet sind. Diese aber in der Tabelle als Zeile mit Scope `keine` und dem Vermerk "eigene Beobachtung" führen, damit sie nicht später fälschlich als Beleglücke gelten.

### A.2 Geltungsbereich bestimmen

Der häufigste Fehler ist, jede Quelle nur auf ihren eigenen Satz zu beziehen. In wissenschaftlichen Texten deckt eine Klammer am Satzende regelmäßig den vorangehenden Gedankengang mit ab.

Vorgehen je Absatz:
1. Alle Positionen der Quellenklammern markieren.
2. Von jeder Klammer aus rückwärts lesen, bis ein Themenwechsel, eine andere Quellenklammer oder der Absatzanfang erreicht ist. Alle Sätze in dieser Spanne bekommen `Satzgruppe, wahrscheinlich`, der Satz mit der Klammer selbst `Satz`.
3. Steht die einzige Klammer am Absatzende und behandelt der Absatz durchgehend ein Thema, ist `Absatz` zu vergeben.
4. Sätze vor der ersten Klammer eines Absatzes, die thematisch zur ersten Klammer gehören, bekommen `Satzgruppe, wahrscheinlich`.

Vorsicht bei: konkreten Zahlen, Jahresangaben, Ortsnamen und Superlativen, die im belegten Satz nicht vorkommen. Solche Details eher als `keine` führen und in Phase 2 gezielt in der Quelle suchen.

Die Einstufung ist eine Annahme über die Absicht des Autors, keine Tatsache. Deshalb trägt sie das Wort "wahrscheinlich" und wird in Phase 2 gegen die Quelle geprüft.

### A.3 Quellen aufsuchen

Reihenfolge:
1. Referenzverzeichnis des Dokuments nach DOI oder URL durchsuchen.
2. `web_search` mit Autor, Jahr und Titelfragment. Eine DOI-URL kann nicht direkt geladen werden, solange sie nicht in einem Suchergebnis stand.
3. Den besten Treffer per `web_fetch` öffnen. Verlagsseiten liefern meist Abstract und Literaturliste; Autoren-PDFs auf Hochschulservern oft den Volltext.
4. Bei Paywall: Abstract, ADS, Semantic Scholar, Repositorium der Hochschule, oder eine zitierende Arbeit, die die Aussage referiert.
5. Beschaffung durch den Nutzer: direkter Link oder DOI, bei Druckwerken Titel, Reihe, ISBN und Kapitel, eine Quelle je Nachricht; Einzelheiten in Phase 2, Schritt 3.
6. Gedruckte Werke ohne Onlineausgabe (Atlanten, ältere Monografien), die auch der Nutzer nicht beschaffen kann, sind nicht prüfbar. Das ist ein legitimes Ergebnis und wird so vermerkt.

Immer festhalten, welcher Teil der Quelle zugänglich war. Ein "verifiziert" auf Grundlage eines Abstracts ist etwas anderes als eines auf Grundlage des Volltexts.

### A.4 Referenzen prüfen

Für jede im Abschnitt zitierte Referenz drei getrennte Prüfungen, jeweils mit festgehaltenem Ergebnis:

1. **Bibliografisch**: Autoren, Jahr, Titel, Zeitschrift oder Verlag, Band, Heft, Seiten oder Artikelnummer gegen die Verlagsseite oder Crossref. Häufige Fehler: verkürzte Autorenlisten, falsche Zeitschrift bei gleichlautendem Titel, vertauschte Bände, geschätzte Seitenzahlen.
2. **Auflösbarkeit**: Die DOI oder URL im Verzeichnis öffnen und prüfen, ob sie auf genau diese Arbeit führt. Eine DOI, die zu einer anderen Arbeit führt, ist gravierender als eine fehlende DOI.
3. **Inhaltliche Deckung**: Trägt die Arbeit die Aussage? Dazu Abstract, Titel, Abbildungslegenden oder, wenn zugänglich, den Volltext heranziehen und die Fundstelle benennen.

**Der Abstract ist ein vollwertiger Beleg.** Er ist Teil der Publikation, wird mit ihr begutachtet und enthält die zentralen Ergebnisse. Deckt der Abstract die Aussage, gilt sie als verifiziert, nicht als eingeschränkt geprüft. Ein Zusatz wie "nur der Abstract war zugänglich" gehört nur dann in den Prüfreport, wenn die Aussage ein Detail betrifft, das der Abstract erkennbar nicht behandelt, etwa eine Zahl, eine Messreihe oder eine Nebenbeobachtung. Auch Titel, Abbildungslegenden, Schlagwortverzeichnisse und der Verlagsdatensatz sind zulässige Belegstellen. Nur wenn keine dieser Quellen die Aussage trägt, wird der Volltext benötigt; ist er nicht zugänglich, lautet der Status `nicht prüfbar`.

Ergebnis je Referenz: `bibliografisch korrekt`, `Angabe fehlerhaft`, `DOI führt woanders hin`, `inhaltlich gedeckt`, `nur teilweise gedeckt`, `Fehlzuordnung`, `nicht prüfbar`.

Nicht prüfbare Referenzen, etwa gedruckte Werke ohne Onlineausgabe, sind zulässig, müssen aber im Prüfreport als solche stehen. Was nicht bestätigt werden konnte, wird nicht behauptet: Lieber eine Angabe weglassen als sie plausibel ergänzen.

### A.5 Eigennamen prüfen

Für jeden Eigennamen im geprüften Abschnitt gilt eine eigene kleine Prüfschleife, unabhängig davon, ob der Satz eine Quellenangabe trägt:

1. Vollständigen Namen suchen, nicht nur die Gattung oder nur das Epitheton.
2. Treffer gegen eine belastbare Quelle halten: Originalbeschreibung, Fachdatenbank, amtliches Verzeichnis. Sammlerportale und Tourismusseiten reichen für Namen nicht aus.
3. Prüfen, ob der Name im richtigen Zusammenhang steht: richtige Fundstelle, richtige Formation, richtige Gruppe.
4. Vorbehalte der Quelle übernehmen. Steht dort "cf.", "aff.", "nomen dubium" oder eine offene Revision, gehört das in den Text.
5. Bei Bedarf Autor und Jahr ergänzen; das macht spätere Prüfungen leichter.

Typische Fehlerbilder: Art und Gattung zweier Taxa vertauscht oder neu kombiniert; ein Gattungsname verwendet, der in einer anderen Tiergruppe bereits vergeben ist; eine vorläufige Bestimmung als sichere ausgegeben; ein Formationsname, den es in der zitierten Lithostratigraphie nicht gibt.

### A.6 Statusvergabe

| Status | Kriterium |
|---|---|
| verifiziert | Die Quelle trägt die Aussage im zugänglichen Teil eindeutig. Der Abstract zählt dabei als vollwertiger Teil der Publikation; eine im Abstract gedeckte Aussage ist verifiziert, nicht nur teilweise verifiziert. |
| teilweise verifiziert | Kernaussage gedeckt, ein Detail (Zahl, Zeitraum, Nebenglied der Aufzählung) nicht auffindbar. |
| nicht prüfbar | Quelle nicht zugänglich oder gedruckt ohne Onlineausgabe. |
| Fehlzuordnung | Die Quelle behandelt das Thema des Fakts nicht. Immer als deutlicher Befund melden. |

### A.7 Durchgearbeitetes Beispiel

Absatz im geprüften Bericht:

> "Das Zechsteinsalz stieg später als Diapire und Kissen auf und steuerte die lokale Struktur der nördlichen Becken, die in der Oberkreide während der Konvergenz von Afrika, Iberia und Europa invertiert wurden (Kley and Voigt, 2008)."

Phase 1 ergibt zwei Zeilen:

| No. | Statement | Source | Scope |
|---|---|---|---|
| 10 | Zechsteinsalz stieg als Diapire und Kissen auf und steuerte die Struktur der nördlichen Becken | Kley and Voigt (2008) | Satz |
| 11 | Die nördlichen Becken wurden in der Oberkreide während der Konvergenz Afrika-Iberia-Europa invertiert | Kley and Voigt (2008) | Satz |

Phase 2: Das Abstract von Kley and Voigt (2008) behandelt ausschließlich Intraplatten-Aufschiebung und Plattenkinematik. Fakt 11 ist damit verifiziert, Fakt 10 ist eine Fehlzuordnung: Halokinese kommt in der Arbeit nicht vor.

Phase 3: Recherche nach begutachteter Literatur zur Salztektonik Norddeutschlands liefert Mohr et al. (2005) mit erster Diapirbildung in der Trias und Kissenwachstum durch differenzielle Auflast sowie Scheck-Wenderoth and Lamarche (2005) mit Salzmobilisierung ab der Obertrias.

Phase 4: Der Satz wird geteilt, Fakt 10 erhält die beiden neuen Quellen, Kley and Voigt (2008) bleibt für Fakt 11 stehen. Im Verzeichnis kommen zwei Einträge hinzu, keiner entfällt, weil Kley and Voigt weiterhin zitiert wird.

---

## Anhang B: Einarbeitung und Gegenprüfung

Inhalt: B.1 Text ändern, B.2 Referenzverzeichnis pflegen, B.3 Prüfskript, B.4 Aufbau des Mehrfachaussagen-Registers, B.5 Vorlage des Prüfreports.

### B.1 Text ändern

- Änderungen einzeln und mit eindeutigem Suchtext ausführen, nicht mit unspezifischen Ersetzungen über das ganze Dokument. Jede Ersetzung vorher auf Eindeutigkeit prüfen (genau ein Treffer) und bei Abweichung abbrechen, statt zu raten.
- Mehrere Quellen in einer Klammer mit Semikolon und in chronologischer Reihenfolge: `(Franke, 2000; Kroner and Romer, 2013; Käßner et al., 2024)`.
- Zitierform des Dokuments übernehmen. Hält das Dokument Dreiautorenwerke ausgeschrieben, dann auch für neue Quellen ausschreiben.
- Wird ein Satz geteilt, weil eine Quelle nur einen Teil trägt, den Satzbau des Dokuments beibehalten und keine Bedeutung hinzufügen.
- Keine typografischen Sonderzeichen einführen, die das Dokument sonst nicht verwendet.

### B.2 Referenzverzeichnis pflegen

- Neue Einträge im Format des Dokuments anlegen, mit DOI als Link, falls das Dokument DOIs verlinkt.
- Beim Einsortieren die Umlaute normalisieren, damit Käßner zwischen Kaplan und Kley landet und nicht am Listenende.
- Ist das Verzeichnis in Abschnitte gegliedert (etwa wissenschaftliche Literatur, Museen, Betreiber, sonstige Webquellen), gehört ein neuer Eintrag in den passenden Abschnitt, und der Abschnitt bleibt für sich alphabetisch.
- **Löschregel**: Ein Eintrag wird nur entfernt, wenn im gesamten Fließtext vor dem Referenzkapitel keine Nennung mehr vorkommt. Vor dem Löschen maschinell zählen. Im Zweifel stehen lassen und im Report als offenen Punkt vermerken.
- Entfällt ein Eintrag einer Reihe mit Buchstabenkennungen (2026 a, 2026 b, 2026 c), die verbleibenden neu durchbuchstabieren und alle Nennungen im Text mitziehen.

### B.3 Prüfskript

Nach dem Einarbeiten ausführen. Prüft Zitate ohne Eintrag, Einträge ohne Zitat, Dubletten und die alphabetische Ordnung.

```python
import re, unicodedata, sys

path = sys.argv[1]
refs_heading = "## References"      # anpassen
after_refs   = "## About the Author" # anpassen, sonst None

s = open(path, encoding="utf-8").read()
ri = s.index(refs_heading)
ai = s.index(after_refs) if after_refs else len(s)
body, refs = s[:ri], s[ri:ai]

entries = [(m.group(1), m.group(2) + (m.group(3) or ""))
           for m in re.finditer(r"(?m)^([A-ZÄÖÜa-z][^\n]*?) \((\d{4}|n\.d\.)( [a-h])?\) ", refs)]
print("Einträge:", len(entries))

# Einträge ohne Nennung im Text
for author, year in entries:
    surname = author.split(",")[0].split(" and ")[0].split(" et al")[0]
    if not re.search(re.escape(surname) + r"[^()\n]{0,90}" + re.escape(year) + r"[);,]", body):
        print("NICHT ZITIERT:", author, year)

# Zitate ohne Eintrag
cites = set(re.findall(r"\(([^()]{3,120}?), ((?:\d{4}|n\.d\.)(?: [a-h])?)\)", body))
for c in cites:
    if not any(c[1] == y and a.startswith(c[0].split(" et al")[0].split(",")[0]) for a, y in entries):
        print("KEIN EINTRAG:", c)

# Dubletten
from collections import Counter
for k, v in Counter(entries).items():
    if v > 1:
        print("DUBLETTE:", k)

# alphabetische Ordnung
key = lambda x: unicodedata.normalize("NFD", x).encode("ascii", "ignore").decode().lower()
names = [a for a, _ in entries]
for i in range(len(names) - 1):
    if key(names[i]) > key(names[i + 1]):
        print("REIHENFOLGE:", names[i], "vor", names[i + 1])
```

Die Treffer "KEIN EINTRAG" enthalten falsch positive Fälle bei Zweiautorennennungen; jeden Treffer einzeln ansehen. Zitate, die innerhalb des Referenzkapitels stehen (etwa in einem Anhang), erkennt das Skript nicht als Nennung.

### B.4 Aufbau des Mehrfachaussagen-Registers

Sechs Abschnitte, jeder als Tabelle mit den Spalten Aussage, verbindliche Fassung, Fundstellen, zuletzt geändert, Hinweis:

1. Zahlenangaben: Zeitspannen, Entfernungen, Datierungen, Stückzahlen, Artenzahlen, Maße.
2. Stratigraphische Einheiten und Stufenangaben.
3. Eigennamen und Schreibweisen: Taxa mit Autorschaft, Orts- und Strukturnamen, obsolete Namen.
4. Quellenzuordnungen, die mehrfach vorkommen, samt der Warnung vor der jeweils falschen Alternative.
5. Konventionen, die an mehreren Stellen erklärt werden.
6. Offene Punkte, die bei jeder Prüfung mitzuführen sind.

Fundstellen werden mit Abschnittsnummer, Tabelle oder Bildunterschrift benannt, nicht mit Seitenzahlen. In der Spalte "zuletzt geändert" stehen Datum und Uhrzeit des Laufs, damit sich die Änderung dem zugehörigen Prüfreport zuordnen lässt. Aussagen, die nur an einer Stelle stehen, gehören nicht ins Register, mit einer Ausnahme: zuvor falsche Angaben, bei denen ein Rückfall droht, werden mit dem Vermerk "nur eine Fundstelle" aufgenommen.

Kandidaten für das Register findet man maschinell, indem man auffällige Zahlen und Eigennamen im Fließtext zählt:

```bash
grep -o -E "[0-9]+(\.[0-9]+)? (Ma|million years|km|percent)" dokument.md | sort | uniq -c | sort -rn
```

### B.5 Vorlage des Prüfreports

```markdown
# Prüfreport: <Dokumentname>

**Geprüfter Abschnitt:** <x.y Titel>
**Datum und Uhrzeit der Prüfung:** <JJJJ-MM-TT HH:MM>
**Frühere Reports zu diesem Dokument:** <Dateinamen oder "keine">
**Erfasste Fakten:** <n>  **Geänderte Stellen:** <n>  **Neue Quellen:** <n>  **Entfernte Quellen:** <n>

## 1. Zusammenfassung

<Drei bis fünf Sätze: Was geprüft wurde, wie viele Fakten belegt waren, welche Befunde die Korrekturen ausgelöst haben, was offen bleibt.>

## 2. Faktentabelle mit Prüfergebnis

| No. | Statement | Quelle vorher | Scope | Status | Quelle nachher |
|---|---|---|---|---|---|

## 3. Einzelne Änderungen

### Änderung 1: <Fundstelle>
**Vorher:** <Wortlaut>
**Nachher:** <Wortlaut>
**Begründung:** <Befund aus Phase 2>
**Beleg:** <Harvard-Angabe mit DOI, Fundstelle in der Quelle>

## 4. Referenzverzeichnis

**Hinzugefügt:** <Liste mit DOI>
**Entfernt:** <Eintrag, mit dem Nachweis, dass keine Nennung mehr vorliegt>
**Geändert:** <Umbenennungen, neue Buchstabenkennungen>

## 5. Offene Punkte

<Nicht prüfbare Fakten mit Grund, gesperrte Quellen, bewusst unverändert Gelassenes.>
```
