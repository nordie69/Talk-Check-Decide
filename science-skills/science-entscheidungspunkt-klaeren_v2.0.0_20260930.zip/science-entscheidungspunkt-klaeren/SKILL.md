---
name: science-entscheidungspunkt-klaeren
description: Führt einen einzelnen Entscheidungspunkt zu einer anwendbaren Regel, also einen Befund, der kein Schreibproblem ist, sondern ein Urteil verlangt, welche von mehreren zulässigen Fassungen künftig gilt. Zählt vor der Frage die Folgen jeder Option im Dokument aus, legt Kosten und Nacharbeit offen, stellt genau eine Frage, und gibt eine Regel aus, die ein späterer Schritt ohne weiteres Urteil ausführen kann, samt Ausnahmen und Prüfausdruck. Immer verwenden bei, Entscheidungspunkt klären, welche Konvention gilt, wie sollen wir es halten, Regel festlegen, Schreibweise entscheiden, vor dem Ändern entscheiden, Entscheidung dokumentieren, was kostet welche Variante. Auch triggern wenn ein Arbeitsplan oder Prüfbericht einen Schritt als Entscheidungspunkt markiert. NICHT für Sachfragen mit einer richtigen Antwort, dafür geo-frage-belegbasiert-klaeren oder science-faktenbeleg-pruefung.
metadata:
  version: "2.0.0"
---

# Entscheidungspunkt klären

Manche Befunde sind keine Fehler, sondern Gabelungen. Zwei Schreibweisen sind beide vertretbar, zwei Zählweisen beide richtig, zwei Darstellungen einer strittigen Angabe beide zulässig. Falsch ist nur, dass das Dokument sich nicht festgelegt hat.

Solche Befunde haben eine eigene Gefahr: Wer sie zusammen mit der Textänderung bearbeitet, trifft die Entscheidung stillschweigend selbst. Sie sieht dann nicht wie eine Entscheidung aus, sondern wie eine Formulierung, und niemand kann sie später nachvollziehen oder zurücknehmen.

Dieser Skill trennt die Entscheidung vom Schreiben und macht sie zu einem eigenen, überprüfbaren Ergebnis. Er ergänzt `science-interne-konsistenz-pruefung`, die Entscheidungspunkte findet, und läuft vor `science-aenderungsfortpflanzung`, die das Ergebnis ausführt.

## Wann dieser Skill nicht zuständig ist

Ein Entscheidungspunkt liegt nur vor, wenn mehr als eine Antwort vertretbar ist. Hat die Frage eine richtige Antwort, ist sie eine Sachfrage und gehört zu `geo-frage-belegbasiert-klaeren` oder `science-faktenbeleg-pruefung`.

Der Test dafür ist kurz: Könnte eine Quelle die Frage entscheiden? Dann ist es keine Entscheidung. Ob die Grube Clara 400 oder 470 Arten führt, entscheidet die Literatur. Ob das Dokument den Stand von 2019 oder den heutigen Stand nennt, entscheidet der Autor.

Häufig hängen beide zusammen: Erst klärt eine Quelle den Sachverhalt, dann entscheidet der Autor die Darstellung. In dem Fall läuft die Sachfrage zuerst und ihr Ergebnis wird hier als Eingabe geführt.

## Grundregeln

- **Sprache**: Die Entscheidungsdokumentation steht in der Sprache des Dokuments. Wird sie in einen englischsprachigen Arbeitsplan eingehängt, steht sie englisch. Zitate aus dem Dokument bleiben im Wortlaut.
- **Erst zählen, dann fragen**: Keine Option wird zur Wahl gestellt, bevor ihre Folgen im Dokument ausgezählt sind. Eine Frage ohne Mengenangabe zwingt den Autor zu raten, wie teuer seine Antwort wird.
- **Eine Frage**: Pro Lauf genau ein Entscheidungspunkt und genau eine Frage. Mehrere Gabelungen in einer Nachricht führen zu einer Sammelantwort, die keine der Fragen wirklich beantwortet.
- **Keine Empfehlung ohne Gegenrede**: Eine Empfehlung ist erlaubt und meist nützlich. Sie steht aber nach den Optionen, nicht davor, und nennt, was gegen sie spricht.
- **Nichts vorwegnehmen**: Solange die Entscheidung offen ist, wird kein Text geändert, auch nicht probeweise.
- **Das Ergebnis ist eine Regel, keine Meinung**: Ausgegeben wird ein Satz, den ein späterer Schritt anwenden kann, ohne erneut zu urteilen. Woran das zu erkennen ist, steht in Phase 4.

## Phase 1: Die Gabelung benennen

Zuerst wird ausgesprochen, worüber überhaupt entschieden wird. Drei Angaben:

1. **Der Befund**, der die Entscheidung nötig macht, mit seiner Kennung aus dem Prüfbericht.
2. **Die Gabelung in einem Satz**, in der Form "Es ist zu entscheiden, ob X oder Y gilt".
3. **Warum das Dokument sich festlegen muss.** Wenn darauf keine Antwort möglich ist, ist es kein Entscheidungspunkt, sondern eine Geschmacksfrage, und der Lauf endet hier.

Zu Punkt 3 ein Hinweis: Der übliche Grund ist nicht, dass eine Variante besser wäre, sondern dass der Leser die Abweichung sonst für bedeutungstragend hält. Ein Dokument, das denselben Begriff einmal groß und einmal klein schreibt, behauptet für den aufmerksamen Leser einen Unterschied, den es nicht gibt.

## Phase 2: Optionen mit ihren Folgen auszählen

Für jede Option wird erhoben, was sie im Dokument auslöst. Das ist der Kern des Skills und der Teil, den kein anderer Skill leistet.

Je Option:

| Angabe | Bedeutung |
|---|---|
| Fassung | Der Wortlaut der Regel, wie sie später angewandt würde |
| Betroffene Fundstellen | Anzahl, maschinell gezählt, nicht geschätzt |
| Davon zu ändern | Wie viele Stellen tatsächlich angefasst werden müssen |
| Abhängige Artefakte | Tabellen, Abbildungen, Begleitdokumente, die mitgezogen werden |
| Folgeentscheidungen | Was diese Option später zusätzlich zu entscheiden zwingt |
| Was sie kostet | Nacharbeit, Verlust an Genauigkeit, Bruch mit einer anderen Konvention |

Gezählt wird mit einer Suche über das Dokument, nicht aus dem Gedächtnis:

```bash
# Fundstellen beider Varianten, getrennt gezählt
grep -o "Variante A" dok.md | wc -l
grep -o "Variante B" dok.md | wc -l

# Fundstellen mit Kontext, um zu sehen, ob die Varianten dieselbe Sache meinen
grep -no "[A-Za-z ]\{0,30\}Variante A[a-z]*[ A-Za-z]\{0,20\}" dok.md | head -30

# Abhängige Artefakte: dieselbe Aussage in Begleitdateien
grep -rn "Variante A" *.md
```

Eine Option, deren Folgen nicht ausgezählt werden konnten, wird als solche gekennzeichnet. Eine geschätzte Zahl ist keine.

**Die Nulloption gehört dazu.** "Es bleibt wie es ist und die Mischung wird erklärt" ist bei fehlender Ansage fast immer zulässig und oft die billigste Lösung. Sie wird mitgeführt, auch wenn sie unattraktiv wirkt.

## Phase 3: Die Frage stellen

Eine Nachricht, in dieser Reihenfolge:

1. Die Gabelung in einem Satz.
2. Die Optionen mit ihren ausgezählten Folgen.
3. Die Empfehlung, mit dem, was gegen sie spricht.
4. Die Frage selbst, als Frage formuliert und nicht als Vorschlag zum Abnicken.

Dann endet der Lauf. Es wird nicht weitergearbeitet, solange die Antwort aussteht.

Antwortet der Autor unbestimmt ("mach es sinnvoll", "wie du meinst"), wird nicht selbst entschieden. Stattdessen wird die Empfehlung als Vorschlag ausformuliert und zur Bestätigung gestellt. Der Unterschied ist nicht Förmlichkeit: eine bestätigte Empfehlung ist eine Entscheidung des Autors, eine stillschweigend angewandte ist keine.

## Phase 4: Die Regel ausformulieren

Die Antwort wird in eine anwendbare Regel überführt. Eine Regel ist anwendbar, wenn sie diesen Test besteht:

**Könnte ein späterer Schritt sie ausführen, ohne dieselbe Frage erneut zu stellen?**

Zwei Beispiele für denselben Fall:

| Untauglich | Warum | Brauchbar |
|---|---|---|
| "Plattenkalk wird einheitlich geschrieben" | Sagt nicht wie | "Groß, wo das Wort die benannte lithostratigraphische Einheit oder das gewonnene Material meint; klein, wo es die Fazies bezeichnet" |
| "Das strittige Alter wird gekennzeichnet" | Sagt nicht womit | "In Tabelle 2 und Fig. 5 steht der Zusatz 'inferred, see 2.13.1' unmittelbar hinter dem Wert" |

Die Regel bekommt vier Bestandteile:

- **Wortlaut** der Regel.
- **Geltungsbereich**: für welche Abschnitte, Tabellen und Abbildungen sie gilt und für welche nicht.
- **Ausnahmen**, jede einzeln begründet. Eine Ausnahme ohne Begründung ist eine Lücke.
- **Prüfausdruck**: ein Suchbefehl oder eine Zählung, mit der sich später feststellen lässt, ob die Regel eingehalten ist. Ohne ihn ist die Regel nicht nachprüfbar und der nächste Prüflauf rollt die Frage neu auf.

## Phase 5: Ablegen und übergeben

Die Entscheidung wird an drei Stellen festgehalten, weil sie sonst verloren geht:

1. **Im Dokument**, wenn es eine Konvention ist, die der Leser kennen muss. Konventionen gehören an die Stelle, an der das Dokument seine übrigen Konventionen erklärt, meist die Einleitung.
2. **Im Mehrfachaussagen-Register** von `science-aenderungsfortpflanzung`, im Abschnitt Konventionen, mit Fundstellen und Datum. Von dort wird sie bei jeder späteren Änderung wieder befragt.
3. **Im Arbeitsplan**, in der Fortschrittstabelle, mit dem Zustand entschieden und dem Datum.

Danach übergibt der Lauf an den Schreibschritt. Die Regel ist dessen Eingabe.

## Ausgabe

Kein eigenes Dateiformat. Der Skill schreibt in vorhandene Artefakte:

| Ergebnis | Wohin |
|---|---|
| Die Frage mit Optionen und Auszählung | Antwort im Gespräch |
| Die ausformulierte Regel | Registerabschnitt Konventionen, und falls leserrelevant ins Dokument |
| Zustand und Datum | Fortschrittstabelle des Arbeitsplans |
| Verworfene Optionen mit dem Grund | Registerhinweis, einzeilig |

Der letzte Punkt wird leicht übersehen und ist der wertvollste. Wer nur die getroffene Entscheidung festhält, hat beim nächsten Lauf keinen Schutz davor, dieselbe Gabelung erneut aufzumachen und anders zu entscheiden.

## Typische Fehler

- Eine Sachfrage als Entscheidungspunkt behandeln und den Autor über etwas abstimmen lassen, das eine Quelle klärt.
- Die Optionen ohne Auszählung zur Wahl stellen und den Autor raten lassen, was seine Antwort kostet.
- Mehrere Gabelungen in einer Nachricht stellen.
- Die Empfehlung vor die Optionen setzen und damit die Wahl vorwegnehmen.
- Eine unbestimmte Antwort als Freibrief lesen und selbst entscheiden.
- Eine Regel ausgeben, die nicht anwendbar ist, weil sie das Wie nicht nennt.
- Ausnahmen ohne Begründung zulassen.
- Keinen Prüfausdruck angeben, sodass beim nächsten Lauf niemand feststellen kann, ob die Regel gilt.
- Die verworfenen Optionen nicht festhalten und die Gabelung später erneut aufmachen.
- Die Nulloption unterschlagen, obwohl "Mischung beibehalten und erklären" bei fehlender Ansage meist zulässig und am billigsten ist.
- Text schon einmal probeweise ändern, während die Entscheidung noch aussteht.

---

## Anhang A: Warum die Entscheidung ein eigener Schritt ist

Eine Entscheidung, die im Schreibschritt mitläuft, hinterlässt keine Spur. Sie ist im fertigen Text nicht von einer Formulierung zu unterscheiden, und genau deshalb ist sie später weder prüfbar noch rücknehmbar. Beim nächsten Durchgang fällt die Abweichung wieder auf, wird wieder als Befund gemeldet und womöglich anders entschieden. Die Arbeit wiederholt sich, und das Dokument schwankt.

Der zweite Grund ist die Zuständigkeit. Bei einer Gabelung mit mehreren zulässigen Antworten gibt es keinen fachlichen Maßstab, der die Wahl erzwingt. Wer sie trotzdem trifft, weil er gerade den Absatz offen hat, nimmt dem Autor eine Entscheidung ab, die ihm gehört. Das ist kein Formfehler, sondern ein Eingriff in das Dokument.

## Anhang B: Die drei Familien von Entscheidungspunkten

Sie tauchen in Prüfberichten immer wieder in denselben drei Formen auf.

**Benennung und Schreibweise.** Groß oder klein, formaler Name oder umgangssprachlicher, regionale oder überregionale Bezeichnung. Merkmal: viele Fundstellen, geringe Einzelkosten, hohe Gesamtkosten. Hier lohnt die Auszählung am meisten, weil die Zahl der Fundstellen die Wahl oft allein entscheidet.

**Darstellung strittiger Angaben.** Eine Angabe ist in der Literatur umstritten, das Dokument muss sie trotzdem in eine Tabellenzelle schreiben. Zu entscheiden ist nicht, was stimmt, sondern wie viel Vorbehalt mitgeführt wird und wo. Merkmal: wenige Fundstellen, hohe inhaltliche Wirkung.

**Zuschnitt und Abgrenzung.** Zählt ein Grenzfall zur einen oder zur anderen Menge, gehört ein offener Punkt in diesen Durchgang oder in den nächsten. Merkmal: berührt Zählungen an vielen Stellen und damit fast immer Selbstbeschreibungen. Hier ist die Folgeentscheidungsspalte aus Phase 2 wichtiger als die Fundstellenzahl.
