---
name: science-aenderungsfortpflanzung
description: Führt zu einem Dokument ein Register der Aussagen, die an mehreren Stellen vorkommen (Zahlen, Namen, Zuordnungen, Konventionen), befragt es vor jeder Änderung und zieht jede Korrektur über alle Fundstellen und abhängigen Artefakte nach. Immer verwenden bei, Änderung nachziehen, wo steht das noch, Register anlegen, Mehrfachaussagen, Korrektur überall, hängt das woanders dran, Konsistenz nach Änderung.
metadata:
  version: "2.0.0"
---

# Änderungsfortpflanzung

Verfahren gegen eine Fehlerklasse, die in gewachsenen Dokumenten regelmäßig auftritt: Eine Aussage wird an einer Stelle korrigiert und bleibt an drei anderen unverändert stehen. An keiner einzelnen Stelle ist etwas falsch, das Dokument als Ganzes widerspricht sich.

Das Verfahren löst das nicht durch mehr Sorgfalt, sondern durch ein eigenes Artefakt: das Register der Mehrfachaussagen. Es wird vor der Änderung befragt, nicht danach.

## Grundregeln

- **Sprache**: Alle Ausgaben stehen in der Sprache des bearbeiteten Dokuments, unabhängig von der Sprache des Nutzers. Ein einordnender Satz darf vorangestellt werden, das Register und die Meldungen nicht.

  | Feld | Deutsch | Englisch |
  |---|---|---|
  | Registerspalten | Aussage, verbindliche Fassung, Fundstellen, zuletzt geändert, Hinweis | Statement, authoritative wording, occurrences, last changed, note |
  | Dateiname | `<Dokument>_Mehrfachaussagen-Register.md` | `<document>_cross-reference-register.md` |
  | Abschnitte | Zahlenangaben, Einheiten und Stufen, Eigennamen, Quellenzuordnungen, Konventionen, Abhängigkeiten, offene Punkte | Numbers, units and stages, proper names, source attributions, conventions, dependencies, open points |

- **Register vor Änderung**: Vor der ersten Textänderung eines Laufs wird das Register gelesen und geprüft, ob die betroffene Aussage darin steht. Das ist Schritt 0, nicht Schritt 4. Wer erst ändert und dann nachschlägt, hat den Fehler bereits gemacht.
- **Kandidaten maschinell suchen**: Was mehrfach vorkommt, wird gezählt, nicht erinnert. Eine Suche über das Dokument ist billiger und vollständiger als jede Einschätzung.
- **Nichts stillschweigend ändern**: Wird eine Fundstelle außerhalb des beauftragten Abschnitts angepasst, steht das im Bericht des Laufs. Der Nutzer soll wissen, wo überall etwas angefasst wurde.
- **Abhängige Artefakte gehören dazu**: Nicht nur Textstellen. Tabellen, Bildunterschriften, Grafiken, CSV-Dateien, Karten und Begleitdokumente tragen dieselben Werte und laufen sonst auseinander.
- **Vorbeugende Einträge sind erlaubt**: Ein Registereintrag darf für einen Fehler angelegt werden, der noch nicht gemacht wurde, aber naheliegt. Verwechselbare Namen und ähnlich lautende Orte sind die häufigsten Fälle.
- **Ein Register je Dokument**: Es liegt als eigene Markdown-Datei neben dem Dokument, nicht darin. Es ist ein Arbeitsmittel und wird nirgends im Dokument verlinkt.

## Phase 1: Register anlegen oder laden

Existiert noch kein Register, wird es erzeugt. Existiert eines, wird es gelesen.

Kandidaten werden maschinell gesucht. Drei Suchen genügen in den meisten Fällen:

```bash
# Zahlen mit Einheit, nach Häufigkeit
grep -o -E "[0-9]+([.,][0-9]+)? ?(Ma|km|m|cm|mm|%|Prozent|Jahre|years)" dok.md | sort | uniq -c | sort -rn | head -40

# Großgeschriebene Mehrwortnamen
grep -o -E "([A-ZÄÖÜ][a-zäöüß]+ ){1,3}(Formation|Gruppe|Schichten|Museum|Grube|Bruch)" dok.md | sort | uniq -c | sort -rn

# Zitate im Text, nach Häufigkeit
grep -o -E "\([A-ZÄÖÜ][a-zäöüß]+( et al\.)?,? [12][0-9]{3}[a-z]?\)" dok.md | sort | uniq -c | sort -rn | head -30
```

Alles, was mehr als einmal auftritt, ist Kandidat. Der Mensch entscheidet, was aufgenommen wird; die Maschine liefert die Liste.

Ergebnis der Phase ist das befüllte Register, nicht eine Änderung.

## Phase 2: Register befragen (Schritt 0 jeder Änderung)

Vor jeder Textänderung:

1. Steht die betroffene Aussage im Register? Wenn ja, sind alle dort genannten Fundstellen betroffen.
2. Steht sie nicht darin, obwohl sie mehrfach vorkommt? Dann wird sie jetzt aufgenommen.
3. Gibt es im Abschnitt Abhängigkeiten (Grafik, Tabelle, Begleitdatei), die denselben Wert tragen?

Wenn das Register die Aussage nicht kennt und eine Suche im Dokument sie nur einmal findet, ist die Änderung lokal und der Lauf geht normal weiter.

## Phase 3: Ändern und nachziehen

Alle Fundstellen in einem Zug, nicht nacheinander über mehrere Läufe. Reihenfolge:

1. Fließtext im beauftragten Abschnitt.
2. Fließtext an allen weiteren Fundstellen.
3. Tabellen. Dort steht oft eine Kurzfassung, die eigens zu formulieren ist, weil nur eine Zelle zur Verfügung steht.
4. Bildunterschriften und Grafiken.
5. Begleitdateien: CSV, Karten, Datenblätter, Anhänge.
6. Querverweise, die durch die Änderung sinnlos werden. Formulierungen wie "ebenso hier" oder "wie oben" verweisen auf einen Befund, den es nach der Korrektur möglicherweise nicht mehr gibt.

Nach dem Nachziehen wird gegengeprüft, dass der alte Wert nirgends mehr steht:

```bash
grep -n "alter Wert" dok.md tabellen.csv anhang.md
```

## Phase 4: Register fortschreiben

Jede geänderte Zeile bekommt die neue verbindliche Fassung, die vollständige Fundstellenliste und Datum sowie Uhrzeit des Laufs. Neue Mehrfachaussagen, die durch die Änderung entstanden sind, werden ergänzt.

Entsteht ein neuer Abschnitt im Dokument, wird unaufgefordert gemeldet, welche Aussagen dadurch zu Mehrfachaussagen geworden sind.

## Aufbau des Registers

Sieben Abschnitte, jeder als Tabelle mit den Spalten Aussage, verbindliche Fassung, Fundstellen, zuletzt geändert, Hinweis.

1. **Zahlenangaben**: Zeitspannen, Entfernungen, Datierungen, Stückzahlen, Maße, Mengen.
2. **Einheiten und Stufen**: fachliche Zuordnungen, die mehrfach genannt werden, samt der konkurrierenden Alternative.
3. **Eigennamen und Schreibweisen**: Namen mit Autorschaft, Orts- und Strukturnamen, obsolete Bezeichnungen, verwechselbare Paare.
4. **Quellenzuordnungen**, die mehrfach vorkommen, jeweils mit der Warnung vor der falschen Alternative.
5. **Konventionen**, die an mehreren Stellen erklärt werden.
6. **Abhängigkeiten zwischen Artefakten**: Welche Grafik, Tabelle oder Begleitdatei trägt Werte aus welchem Abschnitt. Als Pflegehinweis formuliert, nicht als Beschreibung.
7. **Offene Punkte**, die bei jedem Lauf mitzuführen sind.

Fundstellen werden mit Abschnittsnummer, Tabellen- oder Abbildungsnummer benannt, nicht mit Seitenzahlen, weil Seitenzahlen sich beim Umbruch verschieben.

Aussagen mit nur einer Fundstelle gehören nicht hinein. Eine Ausnahme: zuvor falsche Angaben, bei denen ein Rückfall droht, werden mit dem Vermerk "nur eine Fundstelle" aufgenommen.

## Typische Fehler

- Das Register erst nach der Änderung befragen.
- Kandidaten aus dem Gedächtnis zusammenstellen statt zu zählen.
- Nur den Fließtext nachziehen und Tabellen, Bildunterschriften oder Begleitdateien vergessen.
- Einen Querverweis stehen lassen, der nach der Korrektur auf nichts mehr verweist.
- Die Tabellenfassung wörtlich aus dem Fließtext übernehmen, obwohl dort nur eine Zelle Platz ist.
- Das Register nach einem Lauf nicht fortschreiben.
- Abhängigkeiten zwischen Dokument und Grafik dem Gedächtnis überlassen, statt sie als Pflegehinweis einzutragen.
- Eine Aussage aufnehmen, die nur an einer Stelle steht und kein Rückfallrisiko trägt. Das Register wird sonst unlesbar.
- Nach dem Nachziehen nicht gegenprüfen, ob der alte Wert wirklich verschwunden ist.

---

## Anhang A: Wann eine Änderung sich fortpflanzt

Nicht jede Korrektur betrifft mehrere Stellen. Die folgenden Typen tun es fast immer:

| Typ | Warum |
|---|---|
| Zahl mit Einheit | steht meist zusätzlich in Tabelle, Abbildung und Zusammenfassung |
| Fachliche Zuordnung | wird im Detailkapitel und in der Übersicht genannt |
| Eigenname mit Autorschaft | erscheint in Text, Bildunterschrift und Verzeichnis |
| Quellenzuordnung | mehrere Aussagen hängen an derselben Quelle |
| Konvention | wird einmal erklärt und mehrfach vorausgesetzt |
| Koordinate oder Kennung | steht in Tabelle, Kopfzeile, Karte und Begleitdatei |

Diese Typen betreffen selten mehrere Stellen und brauchen kein Register: einmalige Formulierungen, Beispiele, persönliche Beobachtungen, Abschnittseinleitungen.

## Anhang B: Wirkungsnachweis führen

Beim ersten Einsatz des Registers wird der Anteil der Nachzüge gezählt und mit den Läufen davor verglichen. Ein Nachzug ist eine Änderung, die nur deshalb nötig wurde, weil eine frühere Korrektur unvollständig blieb.

Steigt der Anteil wieder, fehlt dem Register eine Kategorie. Das ist ein Hinweis auf eine Lücke im Verfahren, nicht auf Unaufmerksamkeit.

## Anhang C: Vorlage

```markdown
# Mehrfachaussagen-Register: <Dokumentname>

Arbeitsmittel der Prüfung. Wird im Dokument nicht verlinkt.
Angelegt: <JJJJ-MM-TT>. Letzte Fortschreibung: <JJJJ-MM-TT HH:MM>.

## 1. Zahlenangaben

| Aussage | Verbindliche Fassung | Fundstellen | Zuletzt geändert | Hinweis |
|---|---|---|---|---|
| <Kurzbezeichnung> | <Wert und Wortlaut> | 1.2, 2.4, Tab. 1, Abb. 3 | JJJJ-MM-TT HH:MM | <Warnung vor der falschen Alternative> |

## 2. Einheiten und Stufen
## 3. Eigennamen und Schreibweisen
## 4. Quellenzuordnungen
## 5. Konventionen

## 6. Abhängigkeiten zwischen Artefakten

| Artefakt | Trägt Werte aus | Pflegehinweis |
|---|---|---|
| Abb. 5 | 2.1 bis 2.12 | Bei jeder neuen Feldnotiz den Platzhalter ersetzen |

## 7. Offene Punkte
```
