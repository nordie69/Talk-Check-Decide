---
name: "science-uebergabeprotokoll-erstellen"
description: "Erzeugt im laufenden Chat ein Übergabeprotokoll für den Wechsel in einen neuen Chat. Schließt vorher Log und Chatprotokoll ab, gleicht die Arbeitsdokumente untereinander ab, zählt Stand und nächste Kennungen aus den gespeicherten Dateien und legt das Protokoll als Projektdatei und als Einfügetext ab. Immer verwenden bei: Übergabe formulieren, Übergabeprotokoll erstellen, an einen neuen Chat übergeben, neuen Chat vorbereiten, Chatwechsel. Auch triggern, wenn eine neue Skill-Fassung erst in einer neuen Sitzung eingebunden wird. NICHT für die Übernahme im neuen Chat."
metadata:
  version: "2.0.0"
---

# Übergabeprotokoll erstellen

Ein neuer Chat hat nur, was ihm mitgegeben wird. Der alte Verlauf ist kein Nachweis: Er wird lang, wird beim Überlaufen zusammengefasst und lässt sich nicht zitieren. Neu installierte Skills werden außerdem erst beim Start einer Sitzung eingebunden, sodass ein Wechsel oft zwingend ist.

Dieser Skill erzeugt das Übergabeprotokoll im Quellchat. Er schließt die Projektdateien ab, zählt den Stand aus ihnen und schreibt ein Protokoll, das ohne den alten Verlauf verständlich ist.

Die Übernahme im neuen Chat ist nicht Gegenstand. Was dort geschieht, legt der Auftraggeber selbst fest. Das Protokoll beschreibt deshalb Stand und Soll-Werte, gibt aber keine Übernahmeschritte vor.

## 1. Geltungsbereich

Zuerst wird die Form bestimmt.

**Vollform:** Das Vorhaben hat Projektdateien nach `template-dokumentprojekt` oder `template-skill-projekt`, mindestens Organisation und Log. Es gilt der ganze Ablauf in Abschnitt 3.

**Kurzform:** Es gibt keine Projektdateien, etwa bei einer Einzelaufgabe. Es entfallen Schritt 2 (Abschließen) und Schritt 3 (Abgleich). Die Zahlen stammen aus Dateien, soweit welche vorliegen, sonst aus dem Verlauf und sind dann als "aus dem Verlauf, nicht aus Dateien" gekennzeichnet. Das Protokoll wird trotzdem als Datei abgelegt und zusätzlich als Einfügetext ausgegeben (Schritt 7). Offene Punkte werden fortlaufend nummeriert, weil es keine Kennungen gibt, und der Abschnitt Nächste Kennungen entfällt.

Anlässe für einen Wechsel, die im Protokoll genannt werden:

| Anlass | Folge für das Protokoll |
|---|---|
| Neue Skill-Fassung gebaut oder installiert | Abschnitt Skills führt die erwartete Fassung je Skill; eine Prüfung ist erst im neuen Chat möglich |
| Verlauf lang, Zusammenfassung angekündigt oder erfolgt | Ist schon zusammengefasst, nennt der Kopf, welche Eingaben nur noch als Zusammenfassung vorliegen |
| Etappe oder Plan abgeschlossen | Abschnitt Offen trennt Reste von vertagten Punkten |

Zusammenspiel: Dateisatz, Namensregeln, Kennungsregister und Chatprotokoll regeln `template-dokumentprojekt` und `template-skill-projekt`. Einträge im Workplan folgen `science-arbeitsplan-erstellen`. Eine volle Konsistenzprüfung leistet `science-interne-konsistenz-pruefung`; Schritt 3 ersetzt sie nicht.

## 2. Grundregeln

- **Dateien statt Gedächtnis.** Jede Zahl im Protokoll wird aus einer gespeicherten Datei gezählt, nicht aus dem Verlauf abgeschrieben. Die Übergabe beschreibt den Stand der Dateien, nicht den Stand des Chats.
- **Erst abschließen, dann zählen.** Log und Chatprotokoll werden bis zur letzten Eingabe und Aktion fortgeschrieben, bevor irgendetwas gezählt wird.
- **Selbsttragend.** Das Protokoll verweist nie auf Text im alten Verlauf, also nicht auf "meine letzte Antwort", "wie oben besprochen" oder "der Satz von vorhin". Was gilt, steht im Protokoll oder in einer genannten Datei.
- **Keine Übernahmeschritte.** Das Protokoll sagt, was ist und welche Werte der neue Chat vorfinden muss. Wie er prüft und womit er beginnt, entscheidet der Auftraggeber.
- **Ungeprüftes kennzeichnen.** Eine Installation, die nur der Auftraggeber gemeldet hat, steht als "laut Auftraggeber installiert, nicht geprüft".
- **Befunde vor der Übergabe erfassen.** Was der Abgleich in Schritt 3 findet, steht im Workplan, bevor das Protokoll geschrieben wird. Ein Befund, der nur im Protokoll steht, gilt als nicht erfasst.
- **Sprache.** Das Protokoll steht in der Sprache der Arbeitsdokumente des Projekts. Keine Gedankenstriche und kein `--` außerhalb von Code.

## 3. Ablauf

1. **Anlass bestimmen.** Einer der Anlässe aus Abschnitt 1, in einem Satz. Er steht im Kopf des Protokolls.

2. **Abschließen.** Das Chatprotokoll wird bis zur letzten Eingabe fortgeschrieben, einschließlich der Bitte um die Übergabe. Das Log wird bis zur letzten Aktion fortgeschrieben. Beide Dateien werden gespeichert. Danach wird geprüft:
   - Die Kennungen in Log und Chatprotokoll sind lückenlos.
   - Jede Eingabe seit dem letzten Eintrag des Chatprotokolls ist erfasst.
   - Jede Aktion an einer Projektdatei in diesem Chat hat einen Log-Eintrag.

   Fehlt etwas, wird es jetzt nachgetragen. Entscheidungen, die nur im Chat fielen, werden jetzt in Entscheidungslog oder Organisation eingetragen, damit sie im Protokoll nicht als Chatwissen stehen. Ist der Verlauf schon zusammengefasst, wird nach `template-dokumentprojekt` 11.3, Regel 6, benannt, was nur noch als Zusammenfassung vorliegt.

3. **Arbeitsdokumente abgleichen.** Kein voller Prüflauf, sondern die Stellen, die bei Übergaben veralten:
   - Dateitabelle der Organisation gegen die tatsächlich vorhandenen Dateien, mit Fassung und Datum im Namen.
   - Kopfangaben und Zahlen der Organisation gegen Workplan, Log und Entscheidungen, etwa Versionen, Werkzahlen, Umfang, Zahl der Skills.
   - Änderungsprotokoll oder Entscheidungsabschnitt der Organisation gegen das Entscheidungslog.
   - Workplan-Schritte und Abnahmekriterien gegen abgelöste Entscheidungen.
   - Fortschrittstabelle des Workplans gegen die tatsächlich erledigten Schritte.

   Mechanische Abweichungen werden berichtigt und geloggt. Alle anderen gehen als Befund in den Workplan, mit Schritt, Abdeckungszeile und nachgezogenem Fortschritt, und erscheinen im Protokoll unter Bekannte Abweichungen.

4. **Stand zählen.** Aus den gespeicherten Dateien, mit einem Skript, nicht von Hand. Gezählt werden die Werte, die ein neuer Chat nachprüfen kann: Datensätze, Einträge je Datei, Schritte erledigt von gesamt, offene Schritte, Revision einer externen Leitdarstellung, Wortzahlen, soweit das Projekt sie führt. Jeder Wert erhält die Datei, aus der er gezählt ist.

5. **Skills erfassen.** Für jeden Skill, den das Projekt nutzt oder baut: Name, erwartete Fassung (`metadata.version`), Zustand. Zustände sind "eingebunden, geprüft in dieser Sitzung", "laut Auftraggeber installiert, nicht geprüft" und "gebaut, nicht installiert" mit der DAT-Kennung des Pakets. Ein Skill ohne Versionsangabe wird als solcher genannt, weil seine Fassung im neuen Chat nicht belegbar ist.

6. **Protokoll schreiben.** Nach der Vorlage in `references/vorlage-uebergabeprotokoll.md`, die vorher gelesen wird. Pflicht- und Kannabschnitte stehen in Abschnitt 4.

7. **Ablegen.** Das Protokoll wird als Projektdatei gespeichert, Name nach dem Schema des Projekts mit der Art `Uebergabeprotokoll`, etwa `<projekt>_Uebergabeprotokoll_v<F>_<JJJJMMTT>.md`. Die Datei erhält eine DAT-Kennung in der Dateitabelle der Organisation, und ihre Anlage wird geloggt. Umlaute stehen nicht im Dateinamen.

   In der Kurzform heißt die Datei `<gegenstand>_Uebergabeprotokoll_<JJJJMMTT>.md`. `<gegenstand>` ist der Name des Skills oder Themas, um das es geht, ohne Leerzeichen; eine zweite Datei am selben Tag erhält den Zusatz `_HHMM`. DAT-Kennung und Log-Eintrag entfallen, weil es weder Organisation noch Log gibt.

8. **Nächste Kennungen zählen.** Erst jetzt, nach dem Log-Eintrag aus Schritt 7. Je Präfix die höchste vergebene Kennung in der Datei, die das Präfix führt, und die nächste. Das Ergebnis wird in den Abschnitt Nächste Kennungen des Protokolls eingetragen. Ein Skript für die Zählung steht in Abschnitt 6.

9. **Abnahme prüfen** nach Abschnitt 5. Erst danach wird Erfolg gemeldet, mit Messwerten.

10. **Präsentieren.** Protokoll und alle in diesem Chat geänderten Projektdateien werden direkt präsentiert. Im Chat stehen die Dateitabelle mit Dateiname, DAT-Kennung und fünf Wörtern zum Zweck, und der Einfügetext als Codeblock. So kann der Auftraggeber Text und Dateien im neuen Chat in derselben Nachricht senden.

## 4. Abschnitte des Protokolls

| Nr. | Abschnitt | Inhalt | Pflicht |
|---|---|---|---|
| 1 | Kopf | Projekt, geltendes Template mit Fassung, Datum und Uhrzeit, Anlass, Titel des Quellchats; ist der Titel in der Sitzung nicht sichtbar, stehen dort "Titel nicht sichtbar", das Datum und der Gegenstand des Chats in wenigen Wörtern | ja |
| 2 | Einstieg | Einfügesatz: Projekt fortsetzen, geltendes Template, erster offener Schritt; ohne Übernahmeschritte | ja |
| 3 | Dateien | Tabelle: Dateiname mit Fassung, DAT-Kennung, Pflicht oder bei Bedarf, fünf Wörter zum Zweck | ja |
| 4 | Stand | Tabelle: Größe, Wert, gezählt aus | ja |
| 5 | Skills | Tabelle: Skill, erwartete Fassung, Zustand, Paket | ja |
| 6 | Offen | Reihenfolge der offenen Schritte mit Kennung, in der Kurzform fortlaufend nummeriert; erster Schritt, Folgearbeit; vertagte Punkte getrennt, mit Grund und Entscheidung | ja |
| 7 | Nächste Kennungen | Tabelle: Präfix, letzte vergebene, nächste, führende Datei | ja, außer Kurzform |
| 8 | Nur im Chat | Was nur im Verlauf fiel oder in den Dateien missverständlich ist; in der Kurzform auch Entscheidungen, die nur im Chat getroffen wurden, je mit Datum, Entscheider und dem Vermerk "bestätigt" oder "nicht bestätigt"; "keine", wenn es nichts gibt | ja |
| 9 | Bekannte Abweichungen | Offene Befunde aus Schritt 3 mit ihrer Workplan-Kennung | wenn vorhanden |
| 10 | Arbeitsregeln | Im Chat entstandene Regeln, die noch in keinem Skill stehen, mit dem Skill, in den sie gehören | wenn vorhanden |
| 11 | Lehren | Fehlerbilder dieser Etappe, die noch nicht als Regel verankert sind | wenn vorhanden |
| 12 | Externe Leitdarstellungen | Dokumente außerhalb der Dateien, etwa ein Claude Doc: Titel, Kennung oder Link, Revision | wenn vorhanden |
| 13 | Außerhalb des Projekts | Offene Punkte, die ein anderes Projekt oder einen anderen Skill betreffen | wenn vorhanden |

Abschnitt 8 ist Pflicht, auch wenn er "keine" enthält. Er ist der einzige Teil, den die Dateien nicht enthalten können, und ein leerer Abschnitt zeigt, dass danach gesucht wurde.

Nicht ins Protokoll gehören: Anweisungen, wie die Übernahme abzulaufen hat; Verweise auf den alten Verlauf; Zahlen, die nicht aus einer Datei gezählt sind, außer in der Kurzform mit Kennzeichnung.

Der Einfügetext ist das Protokoll selbst, als Markdown. Ist es für eine Nachricht zu lang, besteht der Einfügetext aus Kopf, Einstieg, Dateien und Nur im Chat, mit dem Hinweis, dass das vollständige Protokoll als Datei beiliegt.

## 5. Abnahme

| Prüfung | Erwartung |
|---|---|
| Pflichtabschnitte | 1 bis 8 vorhanden, in der Kurzform ohne 7 |
| Kopf | Quellchat mit Titel, oder mit "Titel nicht sichtbar", Datum und Gegenstand |
| Ablage | Protokoll als Datei gespeichert und präsentiert, auch in der Kurzform |
| Offen | in der Vollform jeder Punkt mit Kennung, in der Kurzform fortlaufend nummeriert |
| Entscheidungen aus dem Chat | in der Vollform in Entscheidungslog oder Organisation eingetragen; in der Kurzform unter Nur im Chat mit Datum, Entscheider und Bestätigungsvermerk |
| Log und Chatprotokoll | enden mit der letzten Aktion und der letzten Eingabe des Quellchats; Kennungen lückenlos |
| Zahlen | jede Zahl im Protokoll ist mit ihrer Quelldatei genannt und stimmt mit einer erneuten Zählung überein |
| Nächste Kennungen | je Präfix höchste Kennung der führenden Datei plus eins; der Log-Eintrag zur Anlage des Protokolls ist eingerechnet |
| Dateiliste | jede genannte Datei existiert unter genau diesem Namen; jede Pflichtdatei der Organisation ist genannt |
| Abgleich | jeder offene Befund aus Schritt 3 steht im Workplan und im Abschnitt Bekannte Abweichungen |
| Verweise auf den Verlauf | 0, gesucht nach "letzte Antwort", "oben", "vorhin", "wie besprochen" |
| Übernahmeschritte | keine Anweisung, wie der neue Chat prüfen oder vorgehen soll |
| Organisation | in der Vollform Protokoll mit DAT-Kennung in der Dateitabelle |
| Gedankenstriche und `--` außerhalb von Code | 0 |

## 6. Zählhilfe

Höchste Kennung je Präfix, gezählt nur in Tabellenzeilen, die mit der Kennung beginnen. Das vermeidet, dass eine bloße Erwähnung in einer anderen Datei als vergeben zählt. Aufgerufen wird es je führender Datei, also Log für L, Chatprotokoll für C, Organisation für M, E und DAT, Workplan für SB, EP und AK.

```python
import re, sys
from collections import defaultdict

def kennungen(pfad):
    s = open(pfad, encoding="utf-8").read()
    je = defaultdict(list)
    for p, n in re.findall(r"^\| *([A-Z]{1,3})-(\d{2,3}) *\|", s, re.M):
        je[p].append(int(n))
    for p, ns in sorted(je.items()):
        luecken = sorted(set(range(min(ns), max(ns) + 1)) - set(ns))
        doppelt = sorted({n for n in ns if ns.count(n) > 1})
        print(f"{pfad}: {p} letzte {p}-{max(ns):02d}, nächste {p}-{max(ns)+1:02d}, "
              f"Lücken {luecken or 'keine'}, doppelt {doppelt or 'keine'}")

for pfad in sys.argv[1:]:
    kennungen(pfad)
```

Führt ein Projekt Kennungen in anderer Form, etwa "Entscheidung 33" im Entscheidungslog, wird das Muster für diese Datei angepasst und im Protokoll die Form des Projekts verwendet.

## 7. Regeln mit Anlass

| Regel | Anlass |
|---|---|
| Vor dem Zählen werden Log und Chatprotokoll abgeschlossen und gespeichert | In einem Dokumentprojekt endeten Log und Chatprotokoll einen und zwei Einträge vor dem Chat, während die Übergabe die nächsten Kennungen nach dem Chat nannte; die Regel zum Fortschreiben galt schon und griff beim Wechsel trotzdem nicht |
| Jede Zahl wird aus einer gespeicherten Datei gezählt | Eine Übergabe nannte 9 Versionszellen, die Datei hatte 7; eine andere nannte 3 Textstellen mit einer Regelzahl, es waren 4 |
| Vor der Übergabe werden die Arbeitsdokumente untereinander abgeglichen | Nach einer Übergabe fand der neue Chat 9 Abweichungen, davon 6 in einer veralteten Organisation und eine in einem Workplan, der sich auf eine abgelöste Entscheidung berief |
| Das Protokoll verweist nie auf den alten Verlauf | Eine erste Übergabe nannte als Einstieg "den Satz aus meiner letzten Antwort", der im neuen Chat nicht vorhanden war |
| Installationen, die nur gemeldet sind, werden als ungeprüft gekennzeichnet | Mehrere Übergaben führten Skills als installiert, die erst im neuen Chat prüfbar waren; drei Pakete trugen keine Versionsangabe, ihre Fassung war dort nicht belegbar |
| Der Abschnitt Nur im Chat ist Pflicht | Ein vertagter Fotoschritt stand als Entscheidung im Log und wäre im neuen Chat als offene Aufgabe gelesen worden; nur ein Hinweis in der Übergabe verhinderte das |
| Die Dateiliste steht als Tabelle, und die Dateien werden direkt präsentiert | In drei von vier Übergaben kam der Text ohne Dateien im neuen Chat an, und in einem Fall musste der Auftraggeber zurückfragen, welche Dateien erwartet werden |
| Das Protokoll gibt keine Übernahmeschritte vor | Festlegung des Auftraggebers: Was im neuen Chat geschieht, bestimmt er dort selbst |
| Auch die Kurzform legt das Protokoll als Datei ab | Beim ersten Einsatz lag das Protokoll der Kurzform nur als Einfügetext vor; nach der Regel des Auftraggebers muss alles in exportierbaren Dokumenten liegen |
| Ein nicht sichtbarer Chattitel wird durch Datum und Gegenstand ersetzt | Beim ersten Einsatz war der Titel des Quellchats in der Sitzung nicht sichtbar, und der Skill sagte nicht, was dann im Kopf steht |
| In der Kurzform werden offene Punkte nummeriert | Beim ersten Einsatz verlangte der Abschnitt Offen Kennungen, die es ohne Projektdateien nicht gibt |
| Nur im Chat getroffene Entscheidungen stehen mit Bestätigungsvermerk im Protokoll | Beim ersten Einsatz waren vier Festlegungen im Chat getroffen, aber vom Auftraggeber noch nicht bestätigt; der Skill hatte dafür keinen Platz |
