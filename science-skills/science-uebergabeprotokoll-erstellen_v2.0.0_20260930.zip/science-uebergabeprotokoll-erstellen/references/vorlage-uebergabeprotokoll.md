# Vorlage Übergabeprotokoll

Platzhalter stehen in spitzen Klammern. Kannabschnitte entfallen ganz, wenn sie nichts enthalten; Abschnitt "Nur im Chat" bleibt mit "keine" stehen. In der Kurzform entfällt "Nächste Kennungen", offene Punkte werden ohne Kennung nummeriert, und Werte aus dem Verlauf tragen in der Spalte "gezählt aus" den Vermerk "Verlauf, nicht aus Dateien".

```markdown
# <projekt>: Übergabeprotokoll

| | |
|---|---|
| Projekt | <projekt> |
| Template | <template-dokumentprojekt oder template-skill-projekt> <Fassung> |
| Erstellt | <JJJJ-MM-TT> <HH:MM> |
| Anlass | <ein Satz> |
| Quellchat | <Titel des Chats, oder: Titel nicht sichtbar; Datum; Gegenstand in wenigen Wörtern> |
| Zusammengefasst | <nein, oder: welche Eingaben nur noch als Zusammenfassung vorliegen> |

## Einstieg

<Projekt> fortsetzen, geführt nach <Template>. Erster offener Schritt: <Kennung und Bezeichnung>.

## Dateien

| Datei | DAT | Bedarf | Zweck |
|---|---|---|---|
| `<Dateiname mit Fassung und Datum>` | DAT-<nn> | Pflicht | <fünf Wörter zum Zweck> |
| `<Dateiname>` | DAT-<nn> | bei Bedarf | <fünf Wörter zum Zweck> |

## Stand

| Größe | Wert | gezählt aus |
|---|---|---|
| Workplan-Schritte erledigt von gesamt | <n> von <m> | Workplan |
| Log-Einträge | <n> | Log |
| <weitere Größe> | <Wert> | <Datei> |

## Skills

| Skill | Erwartete Fassung | Zustand | Paket |
|---|---|---|---|
| `<skill>` | <x.y.z oder ohne Versionsangabe> | <eingebunden, geprüft in dieser Sitzung / laut Auftraggeber installiert, nicht geprüft / gebaut, nicht installiert> | <DAT-nn oder leer> |

## Offen

1. <Kennung, in der Kurzform entfällt sie>: <Schritt>. <Folgearbeit danach, falls vorhanden>
2. <Kennung>: <Schritt>

Vertagt: <Kennung>, <Grund>, <Entscheidung>.

## Nächste Kennungen

| Präfix | Letzte vergebene | Nächste | Führende Datei |
|---|---|---|---|
| L | L-<nn> | L-<nn> | Log |
| C | C-<nn> | C-<nn> | Chatprotokoll |
| <Präfix> | <Kennung> | <Kennung> | <Datei> |

## Nur im Chat

- <Punkt, der nur im Verlauf fiel oder in den Dateien missverständlich ist, mit Kennung, falls vorhanden>
- Entscheidung vom <JJJJ-MM-TT>, <Entscheider>: <Inhalt>; <bestätigt oder nicht bestätigt> (nur Kurzform)

## Bekannte Abweichungen

- <Workplan-Kennung>: <Abweichung>

## Arbeitsregeln

- <Regel>; gehört später in `<skill>`

## Lehren

- <Fehlerbild und Regel, die daraus folgt>

## Externe Leitdarstellungen

| Titel | Kennung oder Link | Revision |
|---|---|---|
| <Titel> | <Kennung oder Link> | <Revision> |

## Außerhalb des Projekts

- <Kennung>: <Punkt>, betrifft `<Projekt oder Skill>`
```
