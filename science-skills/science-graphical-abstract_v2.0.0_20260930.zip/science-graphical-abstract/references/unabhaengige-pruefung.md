# Unabhängige Prüfung

Die unabhängige Prüfung soll das Bild so sehen, wie es ein Leser sieht: ohne das Konzept, ohne die Begründungen, ohne die Absicht dahinter. Wer gezeichnet hat, liest das Konzept in das Bild hinein und übersieht deshalb, was nur mit Vorwissen verständlich ist. Die fünf Fragen sind aus solchen Fehlern abgeleitet: eine Zahl ohne Bezug, ein Ergebniswort, das mehr verspricht als die Quelle, ein weggelassener Pflichtschritt der Quelle. Die Rangstufen zu F4 entstanden, nachdem drei Prüfinstanzen jede Grundregel der Quelle als Bildinhalt forderten, was jedes Bild überladen hätte. F5 kam aus der Auswertung von 25 veröffentlichten Beispielen hinzu: Tippfehler in der Kernaussage, kopfstehender Text und Anbieterlogos standen dort unbemerkt im fertigen Bild.

## Was die Prüfinstanz erhält und was nicht

| Erhält | Erhält nicht |
|---|---|
| Pfad zum gerenderten PNG in Zielmaßen | das Konzept und seine Varianten |
| Pfad zum Quelldokument (Manuskript, Abstract) | Begründungen, Layoutwahl, Überarbeitungsgeschichte |
| Name des Zielprofils und Anzeigegröße | die Eigenbewertung und Messwerte |
| Pfad zum Prüfbogen (nur Bilder: Vorschau, Farbfehlsichtigkeit, Graustufen) | den Bericht `bericht.json` |
| den Prüfauftrag unten und das Raster aus `bewertungsraster.md` | Hinweise, worauf sie besonders achten soll |

## Prüfauftrag (wörtlich an die Prüfinstanz übergeben)

```
Du prüfst ein Graphical Abstract, das du nicht gestaltet hast. Du kennst weder das
Konzept noch die Absicht dahinter, und das ist gewollt.

Bild: <PFAD_PNG>   Anzeigegröße in Trefferlisten: <B> x <H> px
Zielprofil: <PROFIL> (<Zeitschrift oder "keine Zeitschrift">). Verlagsregeln gelten nur,
wenn eine Zeitschrift genannt ist; gleiche Pixelmaße allein machen keine Zeitschrift.
Prüfbogen: <PFAD_PRUEFBOGEN> (Simulationen für Kriterium 7)
Quelle: <PFAD_QUELLE>
Raster: <PFAD_BEWERTUNGSRASTER>

Vorgehen:
1. Sieh dir das Bild an, zuerst verkleinert auf die Anzeigegröße, dann in voller Größe.
   Lies die Quelle erst danach.
2. Beantworte vor jeder Punktvergabe diese fünf Fragen, je mit Fundstelle im Bild
   (Position, Wortlaut) und, wo nötig, in der Quelle:
   F1 Was versteht eine fachfremde Person in fünf Sekunden, nur aus dem Bild?
      Gib ihre vermutliche Zusammenfassung in einem Satz wieder.
   F2 Welche Zahl, welches Symbol, welche Abkürzung, welche Farbe oder Strichart
      oder welcher Begriff ist ohne Wissen aus der Quelle nicht verständlich, weil
      Einheit, Bezug, Legende oder Beschriftung fehlen? Ist ein Maßstabssprung
      zwischen Bildteilen unmarkiert?
   F3 Was verspricht das Bild, das die Quelle nicht oder nur eingeschränkt trägt?
      Achte auf Ergebniswörter, auf Bewertungen, die als Freigabe erscheinen, und
      auf Hypothesen der Quelle (möglich, vermutet), die im Bild als Tatsache stehen.
   F4 Welches Merkmal der Quelle fehlt im Bild? Ordne jeden Befund einer Stufe zu:
      Stufe 1: Ohne dieses Merkmal ist die Kernaussage des Bildes falsch oder
      irreführend.
      Stufe 2: Ein Pflichtschritt der Quelle, der den dargestellten Ablauf oder
      das Ergebnis ändert, fehlt.
      Stufe 3: Randbedingung, Belegpflicht, Verfahrensregel oder Ausnahmefall;
      gehört in den Prüfbericht, nicht ins Bild.
      Nenne Stufe-3-Befunde getrennt und ohne Änderungsvorschlag für das Bild.
   F5 Welche formalen Mängel zeigt das Bild? Rechtschreib- oder Trennfehler,
      Text auf dem Kopf oder senkrecht, Logos oder Marken (auch von KI-Modellen
      und Software), Titel oder Bildunterschrift im Bild, Ordnungsmarken, die
      nicht zur Zahl der Bildteile passen.
3. Vergib danach Punkte nach dem Raster, je Kriterium mit einem Satz Begründung.
   Eine Zahl oder ein Symbol ohne Bezug begrenzt Kriterium 1 auf höchstens 1 Punkt,
   ein Überversprechen oder ein fehlender Pflichtschritt Kriterium 9, ein
   Rechtschreib- oder Trennfehler Kriterium 10, ein Logo setzt Kriterium 10 auf 0.
4. Nenne am Ende höchstens drei Änderungen, geordnet nach Wirkung.

Antworte nur im Format unten. Keine Einleitung.
```

## Antwortformat

```
F1: <ein Satz>
F2: <Befunde mit Fundstelle, oder "keine">
F3: <Befunde mit Fundstelle, oder "keine">
F4: <Befunde mit Fundstelle und Stufe 1, 2 oder 3, oder "keine">
F5: <Befunde mit Fundstelle, oder "keine">
Raster: K1 <0-2> <Begründung> | K2 ... | K10 ... | Summe <n>/20
Änderungen: 1. ... 2. ... 3. ...
```

## Zusammenführung

Je Kriterium zählt der niedrigere Wert aus Eigenbewertung und unabhängiger Prüfung. Jede Abweichung wird im Prüfbericht mit beiden Begründungen benannt. Ein Befund zu F2, F3, F5 oder zu F4 der Stufe 1 oder 2 führt zur Überarbeitung, auch wenn die Summe 17 Punkte erreicht. Befunde zu F4 der Stufe 3 werden im Prüfbericht festgehalten und ändern das Bild nicht; das verhindert, dass jede Verfahrensregel der Quelle ins Bild wandert und es überlädt. Ist F1 deutlich anders als der Kernsatz, trägt das Bild die Kernbotschaft nicht, und es geht zurück zu Schritt 5.
