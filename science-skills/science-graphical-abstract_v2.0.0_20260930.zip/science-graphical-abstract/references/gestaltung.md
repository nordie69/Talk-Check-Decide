# Gestaltungsregeln

## Inhalt

**Hinein gehört:** eine Kernbotschaft; Kontext (Problem oder Frage, bei Geothemen Ort, Zeitraum, Skala); Ansatz als ein bis zwei Symbole; das Hauptergebnis als dominantes Element; optional die Implikation als kurze Aussage oder Pfeil in ein größeres System.

**Nicht hinein gehören:** Titel, Autoren, Zitate, die Überschrift "Graphical Abstract"; statistische Details, Tabellen, Fehlerbalken (Cell Press schließt Datenelemente aus, ACS spezifische Ergebnisse); Nebenbefunde und Literaturwissen ohne neuen Bezug; nicht markierte Spekulation; Logos, Markenprodukte, Personenfotos; ganze Sätze und Textblöcke; leere Flächen.

## Layoutmuster

| Muster | Passt zu | Seitenverhältnis | Geo-Beispiel |
|---|---|---|---|
| Linearer Prozess, links nach rechts | Methodenpapiere, Kausalketten | quer | Probe, Analyse, Modell |
| Oben nach unten | Hierarchien, Ursache zu Wirkung | Quadrat, hoch | Bohrkern, Prozesskette |
| Vorher-Nachher, Zeitsequenz | Veränderungen, Rekonstruktionen | quer | Profile t1, t2, t3 mit gleichem Maßstab |
| Vergleich in zwei Spalten | altes gegen neues Modell, Region A gegen B | quer, Quadrat | bisheriges gegen neues Modell |
| Kreislauf | Zyklen, Rückkopplungen | Quadrat | Kohlenstoff- oder Gesteinskreislauf |
| Zentrales Motiv mit Satelliten | Reviews, Synthesen | Quadrat | Blockdiagramm, umgeben von Prozesssymbolen |
| Gedrehte Karte als Band mit Datenstreifen (Vorbild B1) | langgestreckte Gebiete, Profile entlang einer Route | quer | Küste oder Gebirgszug um 90 Grad gedreht, darüber wenige Werte je Ort, Nordpfeil Pflicht |
| Hauptbild mit Methodenband als Fußzeile (B1) | Studien mit mehrstufiger Auswertung | quer | Karte oder Modell oben, Auswertungsschritte klein und grau darunter |
| Blockdiagramm mit Lupen (B3) | regionale Prozessstudien | quer, Quadrat | Becken oder Gebirge, drei bis vier Lupen mit Verbindungslinie zum Ort |
| Makro-Mikro-Sequenz (B4) | Petrographie, Mineralogie, Paläontologie | quer | Gelände, Handstück, Dünnschliff; Zoomrahmen und Maßstab je Stufe |
| Konzeptquerschnitt mit Flusspfeilen (B5) | Fluid-, Stoff-, Wärmetransport | quer | Land-Meer-Profil mit Quellen und Wegen; Pfeilarten in der Legende |
| Ein Datenbild als Blickfang (B2) | Analytik, bildgebende Verfahren | quer, Quadrat | eine Elementkarte oder ein Mikroskopbild, groß, mit Maßstab und Skala mit Einheit |
| Symbollegende statt Beschriftung (B4) | viele wiederkehrende Objekte | alle | Minerale, Organismen, Phasen als Symbole; Legende höchstens ein Fünftel der Fläche |

Die Kennungen B1 bis B25 verweisen auf die ausgewerteten Beispiele in `beispiele.md`.

### Musterfamilien aus B6 bis B25

| Kennung | Muster | Aufbau | Passt zu | Falle |
|---|---|---|---|---|
| I8 | Review-Rad mit Sektoren (B17, B14, B20) | Kreis mit drei bis fünf Sektoren, je Sektor Symbol und höchstens drei Wörter, im Zentrum das gemeinsame Objekt | Reviews, Übersichten | mehr als fünf Sektoren oder zusätzliche Ringe (R13) |
| I9 | Lappen um ein Zentrum (B18) | vier abgerundete Lappen A bis D um ein Zentrum, verbunden durch Ringpfeile | Reviews mit Ablauf: Entstehung, Messung, Verarbeitung, Anwendung | Beschriftung in Lappenfarbe verliert Kontrast |
| I10 | Kernübergang als Zentrum (B18) | das Zentrum zeigt die Kernaussage als kleines Vorher-Nachher | jedes Radiallayout; macht das Zentrum zur Botschaft | keine |
| I11 | Yin-Yang-Kern für zwei Partner (B14) | zwei ineinandergreifende Hälften, je ein Partner, die Wechselwirkung in der Mitte | Zusammenspiel zweier Systeme (Mikrobe und Mineral, Modell und Messung) | Hälften brauchen direkte Beschriftung |
| I12 | Eigenschaftsring (B17, B19) | drei bis fünf Eigenschaftswörter als Bogen oder umlaufende Pfeile um das Kernsymbol | Material- und Verfahrensarbeiten, deren Beitrag Eigenschaften sind | Bogentext unten steht kopf (R14); nur oberer Halbbogen |
| I13 | Anwendungsperlen auf Außenring (B17) | kleine runde Symbole auf gepunktetem Außenring | Anwendungsbezug ohne eigene Bildeinheit | zählt als Ebene; höchstens vier Perlen |
| I14 | Objekt im Zentrum mit Kreislaufring und Eckfeldern (B16, B12) | reales Objekt (Körper, Reaktor, Bohrloch, Gerät) groß in der Mitte, Kreislaufpfeil mit vier Stationen, je Ecke ein Feld | Regelkreise, Überwachung, Betriebskonzepte | Eckfelder mit mehr als drei Symbolen |
| I15 | Nummerierte Spalten mit Farbverlauf (B11) | drei bis vier Spalten, Kopfleiste mit Nummer und höchstens vier Wörtern, Kopffarbe verläuft als Fortschritt | Methoden, Rahmenwerke, Arbeitsabläufe | Spalten werden zu Text; je Spalte ein Leitsymbol |
| I16 | Rückführband als Fußzeile (B11) | unter einer Kette ein schmales Band mit drei Begriffen, gestrichelter Rückpfeil vom Ende zum Anfang | lernende, iterative Verfahren; verbindet Kette und Kreislauf | muss grau und klein bleiben (R10) |
| I17 | Eingaben als Kachelraster (B15) | vier bis sechs gleich große Kacheln für Datenquellen, alle mit Pfeil in ein Modellsymbol | Datenfusion, Multisensorik, Fernerkundung | echte Karten in Kacheln sind unlesbar |
| I18 | Problem als Mini-Diagramm (B13) | im ersten Feld ein kleines Diagramm der Lücke, die die Arbeit schließt | Arbeiten, deren Anlass eine Diskrepanz ist | Kurven nur mit Strichart unterscheiden, nicht Rot gegen Grün |
| I19 | Weggabelung (B23, B21) | gemeinsame Eingabe, dann Gabel; bisheriger Weg karg und grau, neuer Weg reich in der Akzentfarbe | Methoden, die ein Verfahren erweitern; beste Vergleichsform der Stichprobe | keine |
| I20 | Symmetrisches Triptychon (B20) | zwei gespiegelte Wege um ein zentrales Element, Hintergrund links und rechts in zwei Tonwelten | zwei Mechanismen, Regime oder Szenarien mit gemeinsamer Ursache | Hintergrundtöne müssen die Simulationen bestehen |
| I21 | Symbolpaar für eine Eigenschaft (B23, B22) | dasselbe Symbol zweimal, negiert oder fragend, dann bejahend (Auge durchgestrichen und offen, "?" und "!") | Interpretierbarkeit, Zuverlässigkeit, Eignung; ersetzt einen Satz | Symbol muss ohne Erklärung verständlich sein |
| I22 | Vorher-Nachher desselben Datenbilds (B24, B21) | dasselbe schematische Datenbild vor und nach der Methode (ungeordnet und geordnet, verstreut und gebündelt) | Ordnung, Rekonstruktion, Konsens, Entrauschung; zeigt Leistung ohne Zahl (R8) | Schema, keine echten Daten |
| I23 | Balken gegen Soll-Linie (B25) | Balkenpaare vorher und nachher, korrigiert schraffiert, gestrichelte beschriftete Soll-Linie | Korrektur, Kalibrierung, Bias | höchstens drei Paare |
| I24 | Trichter von Bestand zu Befund (B22) | breiter Balken für den Bestand, Trichter, schmaler Befund, je eine Zahl | Screening, Metaanalyse, Kohorten, Exploration | Bestand nicht als Diagramm mit Kategorien |
| I25 | Schwellenskala mit Folgen (B22) | Balken 0 bis 1 mit markierter Schwelle, beide Zonen mit ihrer Folge beschriftet | Eignungs-, Risiko-, Grenzwertaussagen | nicht Rot gegen Grün; Zinnober gegen Blau mit Beschriftung |
| I26 | Geltungsbereich-Kacheln (B25) | zwei kleine Kacheln mit je zwei Symbolen: wofür das Ergebnis gilt | Methoden mit breiter Anwendbarkeit | höchstens zwei Kacheln |
| I27a | Gestapelte Stadien mit Kraftpfeilen (B7) | derselbe Block mehrfach, außen große Kraftpfeile, Farbe für das Regime; im Querprofil nebeneinander (R19) | Deformationsgeschichte, Beckenentwicklung | Kraftpfeilfarben in die Legende (R2) |
| I27b | Leithorizont über Säulen (B8) | drei bis vier vereinfachte Säulen, eine Linie in der Akzentfarbe verbindet den gleichwertigen Horizont | Stratigraphie, Lagerstätten; die Linie ist der Befund | keine Zitate, keine Formationskürzel |
| I27c | Bildpunkte im Diagramm (B9) | Mikro- oder Mineralbilder stehen an ihrem Datenpunkt, Endglieder als Sterne | Geochronologie, Isotopengeochemie | höchstens vier Bilder, Diagramm qualitativ (R18) |
| I27d | Schichtband als Zeitleiste (B6) | waagerechtes Band aus Schichten als Zeitachse, Diskordanz als Zackenlinie, je Schicht ein Bild | Sedimentabfolgen, Anreicherungsphasen | Altersangaben zählen als Zahlen (R8) |

### Musterwahl nach Artikeltyp

Hilfe für Schritt 4: erste Wahl für Konzept A, Gegenrichtung für Konzept B. Beschrieben ist, was in der Stichprobe B1 bis B25 funktionierte; die Quelle kann eine andere Wahl begründen.

| Artikeltyp | Erste Wahl | Gegenrichtung |
|---|---|---|
| Review, Übersicht | I8 Review-Rad mit I10 Kernübergang | I14 Objekt im Zentrum oder I20 Triptychon |
| Methode, die ein Verfahren erweitert | I19 Weggabelung | I15 Spalten mit Farbverlauf |
| Lernendes oder iteratives Verfahren | I15 Spalten mit I16 Rückführband | I14 Kreislaufring |
| Rekonstruktion, Ordnung, Konsens | I22 Vorher-Nachher | I19 Weggabelung |
| Korrektur, Kalibrierung | I23 Soll-Linie | I22 Vorher-Nachher |
| Screening, Kohorten, Exploration | I24 Trichter | I25 Schwellenskala |
| Datenfusion, Multisensorik | I17 Kachelraster | I15 Spalten |
| Zwei Mechanismen, zwei Regime | I20 Triptychon | I11 Yin-Yang-Kern |
| Regionale Tektonik | I27a Stadien | Blockdiagramm mit Lupen (B3) |
| Stratigraphie, Lagerstätte | I27b Leithorizont | I27d Schichtband |
| Petrographie, Geochronologie | Makro-Mikro-Sequenz (B4) | I27c Bildpunkte im Diagramm |

Beobachtung aus der Stichprobe: Reviews sind überwiegend radial (6 von 20 in B6 bis B25), KI- und Methodenarbeiten durchweg Spalten oder Pipelines, geologische Forschungsartikel übernehmen am häufigsten eine Artikelabbildung (4 von 10 Geo-Beispielen). Das Seitenverhältnis des Profils bleibt vorrangig: Radiallayouts brauchen Quadrat oder quer mit seitlichen Feldern (I20).

Drei bis fünf Bildeinheiten, höchstens sechs Kästen. Beziehungen immer durch Pfeile eindeutig machen. Ein Pfeil bedeutet in einem Bild immer dasselbe (Zeitfolge oder Ursache oder Datenfluss, nicht gemischt).

## Geo-Musterlösungen

1. **Regionale Feldstudie:** links Übersichtskarte mit Lokalitätsstern, Maßstabsbalken, Nordpfeil; Mitte vereinfachte Säule mit Faziesfarben und Altern; rechts Blockdiagramm des Ablagerungsraums; Pfeil von Säule zu Modell; eine Zeile Kernaussage.
2. **Paläoklima-Zeitreihe:** Zeitachse als Rückgrat, Einheit und Richtung klar; zwei bis drei stark geglättete Proxykurven; darunter Symbole für den rekonstruierten Umweltzustand.
3. **Tektonisches Prozessmodell:** drei Profilschnitte t1, t2, t3, gleiche Überhöhung und gleicher Maßstab, Fortschritt der Deformation in der Akzentfarbe.
4. **Methodenpapier:** Eingabe links (Probe, Szene, Seismikwürfel), Methode als Symbol in der Mitte, Ergebnis rechts, das Neue farbig.

## Text und Schrift

- Serifenlos, eine Schriftfamilie, höchstens zwei Größen plus eine für die Kernaussage.
- Mindestgrößen je Profil in `verlagsvorgaben.md`. Faustregel für 1328 px Breite: Beschriftung 28 bis 36 px, Kernaussage 44 bis 56 px.
- Richtwert Textmenge: höchstens 40 Wörter im ganzen Bild, Beschriftungen höchstens vier Wörter.
- Nur Beschriftungen, Schlagworte, eine Kernaussage. Keine Abkürzungen, die erst im Artikel erklärt werden.
- Einheiten und Begriffe wie im Artikel.
- Eine Zeile Kernaussage ist kein Titel, solange sie den Artikeltitel nicht wiederholt. Elsevier schließt zusätzlichen Text und Synopsen aus; ob eine Kernaussage-Zeile darunter fällt, ist in den Richtlinien nicht eindeutig geregelt. Bei Elsevier-Zeitschriften die Kernaussage deshalb bevorzugt als Beschriftung des Ergebnisses ins Bild legen oder die Frage im Konzept als Entscheidungspunkt vorlegen.

## Farbe

Palette Okabe-Ito für Kategorien, farbfehlsichtigkeitstauglich:

| Rolle | Hex |
|---|---|
| Blau | `#0072B2` |
| Zinnober | `#D55E00` |
| Blaugrün | `#009E73` |
| Orange | `#E69F00` |
| Himmelblau | `#56B4E9` |
| Rötliches Violett | `#CC79A7` |
| Gelb (nur Fläche, nie Text) | `#F0E442` |
| Schwarz | `#000000` |

Neutrale Töne für Kontext: `#333333` Text, `#666666` Nebentext, `#999999` Linien, `#D9D9D9` Flächen, `#F2F2F2` Hintergrundflächen. Hintergrund weiß.

Regeln: eine Akzentfarbe trägt das Neue, alles andere gedämpft; keine stark gesättigten Primärfarben (Cell Press); kontinuierliche Größen (Höhe, Temperatur, Alter) nur mit wahrnehmungsgleichmäßigen Skalen nach Crameri (batlow, roma, vik) oder viridis, nie Regenbogen; Rot-Grün nie als einziges Unterscheidungsmerkmal; Linien- und Flächenkategorien immer zusätzlich durch Strichart, Muster oder direkte Beschriftung unterscheiden, denn auch Okabe-Ito-Paare wie Blau und Blaugrün rücken bei Tritanopie zusammen und in Graustufen fallen alle Farben gleicher Helligkeit zusammen (die Messung in `ga_check.py` erkennt das nicht immer, der Blick auf den Prüfbogen schon); Kontrast Text zu Hintergrund mindestens 4,5:1. Geologische Konventionsfarben (ICS-Chronostratigraphie) sind erlaubt, wenn sie Fachlesern Orientierung geben, müssen aber die Simulationen im Prüfbogen bestehen.

## Symbole und Stil

- Einheitliche Linienstärke (Richtwert 4 px bei 1328 px Breite), einheitliche Detailtiefe, eine Stilquelle.
- Symbole bevorzugt selbst aus einfachen Formen. Fremdsymbole nur mit Lizenz CC0 oder CC BY und Namensnennung im Begleitmaterial.
- Fotos nur, wenn sie Information tragen, dann mit Maßstab und Interpretationslinien.

## Geo-Pflichtelemente

- **Karte:** Maßstabsbalken (keine Maßstabszahl), Nordpfeil, wenige Koordinaten, Lage im größeren Raum als Einsatzkarte, Lokalität als Stern. Grenzen neutral.
- **Profil, Querschnitt:** Himmelsrichtungen an den Enden, Überhöhung angeben, vereinfachte Lithologiefarben; in Sequenzen identische Skalen.
- **Säule:** stark vereinfacht, Alter am Rand.
- **Zeitachse:** Einheit (a, ka, Ma, Ga) und Richtung eindeutig; Achsenbrüche deutlich markieren.
- **Blockdiagramm:** Prozesspfeile in Akzentfarbe, Schichten gedämpft.
- **Farbskala:** immer mit Einheit.

## Regeln aus veröffentlichten Beispielen

Abgeleitet aus 25 Graphical Abstracts aus fünf Zeitschriften 2026 (`beispiele.md`): R1 bis R10 aus B1 bis B5, R11 bis R20 aus B6 bis B25. Die mit (M) markierten misst `ga_check.py`.

| Nr. | Regel | Anlass |
|---|---|---|
| R1 | Jede Abkürzung im Bild ist ausgeschrieben oder erklärt, entweder im Bild als "Kürzel: Bedeutung" oder "Bedeutung (Kürzel)" oder in der Legende. Fachkürzel, die die gesamte Zielleserschaft kennt, nur mit Begründung im Konzept und dann in `--kuerzel-ok` (M) | B1 mit neun, B5 mit sieben unerklärten Kürzeln |
| R2 | Jede Farbe und jede Strichart, die eine Bedeutung trägt, steht in der Legende oder ist direkt beschriftet | B5: vier Pfeilfarben und drei Punktfarben ohne Erklärung |
| R3 | Wechselt der Maßstab zwischen Bildeinheiten, wird der Sprung markiert (Zoomrahmen oder Lupe mit Verbindungslinie), und jede Einheit trägt ihren Maßstab oder eine Größenangabe | B4 springt unmarkiert vom Stromatolithen zum Dünnschliff; B3 hat Lupen ohne Maßstab |
| R4 | Langgestreckte Gebiete dürfen gedreht werden, um das Querformat zu füllen; dann ist ein auffälliger Nordpfeil Pflicht | B1 dreht Chile um 90 Grad, mit Nordpfeil |
| R5 | Höchstens drei bis vier Lupen oder Satelliten um ein zentrales Motiv, jede mit sichtbarer Verbindungslinie zu ihrem Ort | B3 mit sechs Lupen, in Vorschaugröße unlesbar |
| R6 | Datenbilder nur mit wahrnehmungsgleichmäßiger Skala, Farbskala mit Einheit, Maßstab in jedem Bild; eine übernommene Artikelabbildung wird auf die eine Aussage zugeschnitten | B2: Regenbogenskalen, Skalen ohne Einheit, Maßstab nur in einem von acht Bildern |
| R7 | Legende höchstens ein Fünftel der Bildfläche; direkte Beschriftung vorziehen, wenn sie in Vorschaugröße lesbar bleibt. Die Legende im SVG als Gruppe mit `id="legende"` anlegen, damit ihre Fläche messbar ist (M) | B4: Legende etwa ein Drittel der Fläche |
| R8 | Höchstens fünf Zahlen im Bild, jede mit Einheit oder Bezugswort; Tabellen gehören in den Artikel (M) | B1: 18 Zahlen in Tabelle und Karte |
| R9 | Was die Quelle als möglich, wahrscheinlich oder vermutet bezeichnet, ist im Bild als Hypothese markiert (Fragezeichen, gestrichelt, "möglich") | B4: "possible UV shielding" erscheint als Tatsache |
| R10 | Eine Leserichtung. Ein Methodenband als Fußzeile ist zulässig, wenn es erkennbar untergeordnet ist (kleiner, grau, keine eigene Akzentfarbe) | B1: drei gleichrangige Leseebenen |
| R11 | Jeder Bildtext ist rechtschreibgeprüft; keine Worttrennung innerhalb eines Wortes, lange Wörter kürzen oder die Box verbreitern. Fachwörter, die das Wörterbuch nicht kennt, in `--woerter-ok`; bei deutschem Bildtext `--sprache de_DE` (M) | B14 "Flus" in der Kernaussage, B25 "continous", B20 "Heterog-eneous" |
| R12 | Ordnungsmarken (1 bis n, A bis n, I bis n) nur in einem System, lückenlos, in Leserichtung, so viele Marken wie Einheiten. Marken im SVG als Gruppe `id="marken"`; sie zählen nicht als Zahlen nach R8 (M) | B11, B18 positiv; B12 drei Marken für vier Felder |
| R13 | Radiallayouts: höchstens fünf Sektoren oder Lappen und ein Ring; das Zentrum zeigt die Kernaussage als Bild (I10), nicht nur als Wort; Startpunkt und Umlaufrichtung sind markiert | B18, B16 positiv; B17 drei Ringe, B14 Zentrum nur als Wort |
| R14 | Kein Text auf dem Kopf, kein senkrechter Text; Bogentext höchstens drei Wörter und höchstens 60 Grad aus der Waagerechten (M) | B12 Ringsegment kopfstehend, B19 senkrechte Ringtexte |
| R15 | Keine Firmen-, Produkt- oder Modelllogos, auch nicht für KI-Modelle und Software; Werkzeuge als neutrales Symbol mit Gattungswort und Anzahl ("34 Sprachmodelle") | B21 sechs Anbieterlogos |
| R16 | Aufzählungslisten sind Textblöcke: höchstens drei Punkte je Gruppe, je höchstens vier Wörter; besser eine Symbolreihe (M) | B19 drei Listen mit zwölf Punkten |
| R17 | Farbe nur mit benannter Rolle (Kategorie, Fortschritt, das Neue); farbige Rahmen und Kopfzeilen ohne Rolle werden neutral; eine Rolle behält ihre Farbe im ganzen Bild | B19, B15 Farbe ohne Bedeutung; B11 Verlauf als Fortschritt und B20 Hintergrund als zwei Welten positiv |
| R18 | Diagramme im Bild sind qualitativ: Achsen beschriftet oder bewusst weggelassen, dann die Richtung als ↑ oder ↓ im Etikett; Referenzlinien beschriftet; Torten nur mit direkt beschrifteten Segmenten | B21 Balkenpaare mit Richtungspfeil, B25 Soll-Linie positiv; B21 unbeschriftete Torte |
| R19 | Die Anordnung folgt dem Zielformat, nicht der Vorlage im Artikel: eine senkrechte Sequenz wird für ein Querprofil waagerecht gelegt, eine lange Kette für ein Quadrat umgebrochen (M, Seitenverhältnis) | B7 Hochformat 0,70 in einer Elsevier-Zeitschrift |
| R20 | Ergänzung zu R6: Eine übernommene Artikelabbildung erscheint als ein zugeschnittenes Feld mit einem nummerierten Befundsatz von höchstens zwölf Wörtern darunter | B6 Befundsätze positiv; B8, B9, B10 unverändert übernommen |

Die Beispiele bestätigen die übrigen Regeln dieses Dokuments: kein Titel im Bild (B3), Lesbarkeit in Vorschaugröße (B2, B3, B5), keine Regenbogenskalen (B2), kein Rot neben Grün (B1), drei bis fünf Einheiten, Geo-Pflichtelemente. Letztere erfüllt keines der fünf Beispiele vollständig; die Regel ist damit strenger als die veröffentlichte Praxis, und das ist gewollt. B6 bis B25 bestätigen R1 (13 von 20 mit unerklärten Kürzeln), R2, R6, R8 und R10 sowie die Grundregeln kein Titel im Bild (B8, B16, B19), Rot-Grün nie allein (B10, B13, B21, B22), kein Regenbogen (B13, B15) und keine Logos (B21). Die Schrift ist in keinem der 25 Beispiele bei 500 px Breite größer als etwa 11 px (Texterkennung, Median).

## Typische Fehler

Artikelabbildung eins zu eins übernommen; Mehrpanel-Collage ohne Leserichtung; Text-Abstract als Bild; Schrift im Vorschaubild unlesbar; gemischte Symbolstile; falsches Seitenverhältnis; Titel oder Überschrift im Bild; Überzeichnung über den Artikel hinaus; Karte ohne Maßstab und Nordpfeil; Profil ohne Überhöhung; Zeitachse ohne Einheit; Regenbogenskala; Zahl ohne Einheit oder Bezugswort ("17 von 20" statt "17 von 20 Punkten"); Ergebniswort, das mehr verspricht als die Quelle ("einreichungsreif" bei einem Konzeptentwurf); Pflichtschritt der Quelle weggelassen (etwa die Freigabe durch den Nutzer); unerklärte Abkürzungen (B1, B5); Pfeil- oder Punktfarben ohne Legende (B5); unmarkierter Maßstabssprung (B4); zu viele Lupen (B3); Artikelabbildung als Collage (B2); Legende größer als ein Fünftel der Fläche (B4); Tabelle mit vielen Zahlen (B1); Hypothese als Tatsache gezeichnet (B4); Tippfehler oder Worttrennung im Bildtext (B14, B20, B25); Ordnungsmarken passen nicht zu den Einheiten (B12); Radialbild mit mehreren Ringen (B17); Text auf dem Kopf oder senkrecht (B12, B19); Anbieterlogos (B21); Aufzählungslisten (B19); Rahmenfarben ohne Bedeutung (B19); unbeschriftete Torte (B21); Hochformat für ein Querprofil (B7).
