# Verlagsvorgaben und Zielprofile

Stand der Recherche: September 2026. Verlagsvorgaben ändern sich häufig, besonders die KI-Regeln. Vor jeder Einreichung den aktuellen Guide for Authors der Zielzeitschrift öffnen. Einträge mit "ungeprüft" wurden nicht im Original gelesen.

Die Pixelwerte für Schrift sind aus den Verlagsangaben umgerechnet (Punkt mal Auflösung durch 72). Wo der Verlag keine Schriftgröße nennt, gilt als Ersatz: im Vorschaubild mindestens 9 Pixel Versalhöhe, praktisch also Schriftgröße im Original mal Anzeigefaktor mindestens 9 Pixel.

## Profile für `ga_check.py`

| Profil | Verlag / Zeitschrift | Maße (B × H in px) | Regel | Vorschau in px | Schrift min. in px | Begleittext | KI-Regel |
|---|---|---|---|---|---|---|---|
| `elsevier` | Elsevier (Standard) | mind. 1328 × 531 | Verhältnis 2,5 (5:2), Querformat | 500 × 200 | 24 (empfohlen ab 28, Kernaussage 44 bis 56) | keiner; Highlights separat | allgemeine generative KI-Bildwerkzeuge verboten; einzelne Titel (Earth-Science Reviews, J. Structural Geology) verbieten jede KI-gestützte Erstellung |
| `cell` | Cell Press | genau 1200 × 1200 | Quadrat, ein Panel | 400 × 400 (Schätzung) | 50 (12 pt bei 1200 px = 4 Zoll), empfohlen 50 bis 67 | keiner | Elsevier-Regel |
| `acs` | ACS (TOC Graphic) | höchstens 975 × 525 bei 300 dpi | 3,25 × 1,75 Zoll, Originalgröße | 312 × 168 | 25 (6 pt), empfohlen 33 (8 pt) | keiner | KI-generierte Bilder in TOC-Grafiken nicht erlaubt |
| `rsc` | RSC (Chemical Science, RSC Advances) | höchstens 1890 × 945 bei 600 dpi | 8 × 4 cm | 302 × 151 | 50 (6 pt, abgeleitet) | 1 bis 2 Sätze, max. 250 Zeichen, nicht Titel oder Abstract wiederholen | ungeprüft |
| `wiley-toc` | Wiley Angewandte Chemie, Chemistry Europe | 650 × 591 bei 300 dpi | 5,5 × 5,0 cm | 260 × 236 | 25 (6 pt), empfohlen 29 (7 pt) | max. 450 Zeichen | ungeprüft |
| `wiley-toc-quer` | wie oben, Querformat | 1300 × 295 bis 1358 × 295 | 11,0 bis 11,5 × 2,5 cm | 520 × 118 | 25 | max. 450 Zeichen | ungeprüft |
| `geojournal` | Wiley Geological Journal | passt in 591 × 709 bei 300 dpi | 50 × 60 mm | 236 × 284 | 25 (abgeleitet) | 2 bis 3 Sätze | ungeprüft |
| `mdpi` | MDPI | mind. 1100 × 560, höchstens 5500 × 2800 | Verhältnis etwa 2:1 | 500 × 255 | 24 (abgeleitet) | keiner | Urheberrechtsschutz verlangt; keine Artikelabbildung, keine Collage, kein Text-Abstract als Bild |
| `peps` | Progress in Earth and Planetary Science (SpringerOpen) | etwa 920 × 300 | Verhältnis etwa 3:1 | 460 × 150 | 24 (abgeleitet) | Bildunterschrift bis 30 Wörter | Springer Nature: KI-Bilder grundsätzlich nicht erlaubt (Sekundärquelle) |
| `frei` | Copernicus/EGU Key Figure, Int. J. Earth Sciences, sonstige | keine Vorgabe | Empfehlung: 1328 × 531 wiederverwenden | 500 × 200 | 24 | Copernicus: keiner | Copernicus ungeprüft |
| `social` | eigene Posts (X, LinkedIn, Bluesky) | 1200 × 675 | 16:9, Empfehlung, keine Verlagsvorgabe | 500 × 281 | 28 | Post-Text mit DOI | eigene Offenlegung empfohlen |

## Weitere Pflichtregeln je Verlag

**Elsevier.** Praxis 2026: In 20 veröffentlichten Beispielen aus vier Elsevier-Zeitschriften reicht das Seitenverhältnis von 0,70 bis 2,61, fünf sind nahezu quadratisch oder hoch (`beispiele.md`). Das Profil `elsevier` bleibt beim Soll 5:2; ein anderes Format nur, wenn der Guide for Authors der Zielzeitschrift es ausdrücklich zulässt. Klare Leserichtung von oben nach unten oder links nach rechts. Schriften Times, Arial, Courier oder Symbol. Kein zusätzlicher Text, keine Überschrift "Graphical Abstract". Keine unnötige Weißfläche. Rechte an Fremdmaterial klären. Dateien TIFF, EPS, PDF oder MS-Office, mindestens 300 dpi. Erscheint in ScienceDirect, nicht im PDF.

**Cell Press.** Stichprobe Patterns 2026: 5 von 5 Graphical Abstracts quadratisch; vier davon zeigen trotz der Vorgabe unten Diagramme (`beispiele.md`, B21 bis B25). Der Skill hält sich an die Vorgabe und zeigt Daten nur schematisch (I22, I23). Ein Panel, keine Datenelemente jeder Art, Kontext sichtbar, neue Befunde betont, Vorarbeiten nur soweit nötig, Spekulatives als solches erkennbar, keine stark gesättigten Primärfarben. Arial. TIFF, PDF oder JPG, 300 dpi.

**ACS.** Vollständig original, von einem Koautor erstellt. Keine Personenfotos, Karikaturen, Briefmarken, Währungen, Marken. Möglichst nicht identisch mit einer Manuskriptabbildung. Keine spezifischen Ergebnisse, Text auf Beschriftungen beschränkt. Serifenlos, bevorzugt Helvetica 8 pt. TIF 300 dpi farbig, EPS mit eingebetteten oder in Pfade umgewandelten Schriften.

**RSC.** TIFF, mindestens 600 dpi, Fläche ausnutzen. Keine Logos, Marken, Markennamen. Wenig Text im Bild.

**MDPI.** PNG, JPEG oder TIFF. Schriften Times, Arial, Courier, Helvetica, Ubuntu oder Calibri. Keine großen Textblöcke, keine Überschrift "Graphical Abstract".

## Geowissenschaftliche Zeitschriften

| Zeitschrift | Status | Profil | Hinweis |
|---|---|---|---|
| Geoscience Frontiers | verpflichtend; Stichprobe 2026: 5 von 5 Artikeln zeigen eines | `elsevier` | Artikelabbildung oder Mosaik weniger Panels erlaubt, Breite etwa das Dreifache der Höhe; veröffentlichte Beispiele mit Verhältnis 2,0 bis 2,9 (`beispiele.md`) |
| Earth-Science Reviews | ungeprüft | `elsevier` | jede KI-gestützte Erstellung von GA-Artwork untersagt |
| Journal of Structural Geology | optional, ausdrücklich erwünscht | `elsevier` | KI-gestützte GA-Grafik untersagt |
| Quaternary Science Reviews | empfohlen | `elsevier` | Highlights Pflicht |
| Earth and Planetary Science Letters | empfohlen; Stichprobe Band 692 (2026): 0 von 6 Artikeln zeigen eines | `elsevier` | als Fundort für Beispiele ungeeignet |
| Chemical Geology | separate Datei | `elsevier` | Pflichtstatus ungeprüft |
| Sedimentary Geology, Palaeo3 | ungeprüft | `elsevier` | Guide for Authors prüfen |
| International Journal of Earth Sciences | verpflichtend | `frei` | darf Artikelabbildung sein |
| Progress in Earth and Planetary Science | laut Richtlinie verpflichtend, in der Praxis nicht sichtbar: Stichprobe 2026, 0 von 5 Artikeln zeigen eines | `peps` | Komposit erlaubt; vor Einreichung beim Journal nachfragen, ob und wo es erscheint |
| Geological Journal | wird veröffentlicht | `geojournal` | neues Bild oder bestehende Abbildung |
| Earth Surface Processes and Landforms | bei Revision verpflichtend | ungeprüft | separate Textdatei "Graphical Abstract Text" |
| Solid Earth, HESS, weitere EGU | optional als Key Figure | `frei` | HESS: eigens gestaltet; E&G Quaternary Science Journal verweist auf Coblis und Crameri-Paletten |
| JGR, GRL (AGU) | kein GA | `social` | stattdessen bis zu 3 Key Points (je max. 140 Zeichen) und Plain Language Summary |
| Geology, GSA Bulletin, Geosphere | kein GA | `social` | Alt-Text für Abbildungen verpflichtend |
| Frontiers | kein GA | `social` | |
| Ore Geology Reviews | Pflichtstatus ungeprüft; Stichprobe 2026: 5 von 5 Artikeln zeigen eines | `elsevier` | veröffentlichte Beispiele mit Verhältnis 0,70 bis 2,61, drei von fünf sind Artikelabbildungen (`beispiele.md`, B6 bis B10) |

## Weitere Zeitschriften mit Stichprobe

| Zeitschrift | Stichprobe 2026 | Profil | Hinweis |
|---|---|---|---|
| Water Research | 5 von 5 lesbaren Artikeln mit GA | `elsevier` | Prozesse, Modelle, KI in der Wasserwirtschaft; Verhältnis 1,0 bis 2,0 (B11 bis B15) |
| Chemical Engineering Journal | 5 von 5 | `elsevier` | Stichprobe nur Reviews, vier davon radial; Verhältnis 1,0 bis 1,85 (B16 bis B20) |
| Patterns | 5 von 11 lesbaren Artikeln | `cell` | Cell Press, Open Access; Reviews ohne GA (B21 bis B25) |
| Engineering Applications of Artificial Intelligence | 0 von 4 lesbaren | `elsevier` | als Fundort für Beispiele ungeeignet |
| Applied Energy | 2 von 7 | `elsevier` | selten |
| Environmental Modelling & Software | 1 von 3 | `elsevier` | selten |

## Quellen

- Elsevier, Graphical abstract: https://www.elsevier.com/researcher/author/tools-and-resources/graphical-abstract
- Elsevier, Generative AI policies for journals: https://www.elsevier.com/about/policies-and-standards/generative-ai-policies-for-journals
- Cell Press, Graphical Abstract Guidelines: https://www.cell.com/pb/assets/raw/shared/figureguidelines/GA_guide.pdf
- ACS, TOC/Abstract Graphics Guidelines: https://pubsapp.acs.org/paragonplus/submission/toc_abstract_graphics_guidelines.pdf
- RSC, Author guidelines RSC Advances: https://www.rsc.org/publishing/publish-with-us/publish-a-journal-article/rsc-advances
- Wiley, Graphics Guidelines Angewandte Chemie: https://onlinelibrary.wiley.com/page/journal/15213773/homepage/graphics-guidelines
- Wiley, Geological Journal Author Guidelines: https://onlinelibrary.wiley.com/page/journal/10991034/homepage/forauthors.html
- MDPI, Layout Style Guide: https://www.mdpi.com/authors/layout
- Copernicus, Manuscript preparation: https://publications.copernicus.org/for_authors/manuscript_preparation.html
- Geoscience Frontiers, Guide for authors: https://www.sciencedirect.com/journal/geoscience-frontiers/publish/guide-for-authors
- Earth-Science Reviews, Guide for authors: https://www.sciencedirect.com/journal/earth-science-reviews/publish/guide-for-authors
- Journal of Structural Geology, Guide for authors: https://www.sciencedirect.com/journal/journal-of-structural-geology/publish/guide-for-authors
- International Journal of Earth Sciences, Submission guidelines: https://link.springer.com/journal/531/submission-guidelines
- Progress in Earth and Planetary Science: https://progearthplanetsci.springeropen.com/submission-guidelines/preparing-your-manuscript/review
- AGU, Plain Language Summary: https://www.agu.org/Publish-with-AGU/Publish/Author-Resources/Plain-Language-Summary
- GSA, Preparing your manuscript: https://www.geosociety.org/publications/author-information/preparing-your-manuscript
