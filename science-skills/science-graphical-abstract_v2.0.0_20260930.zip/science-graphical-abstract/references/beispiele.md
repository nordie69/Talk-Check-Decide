# Ausgewertete Beispiele

25 Graphical Abstracts aus fünf Zeitschriften, veröffentlicht 2026: B1 bis B5 Geoscience Frontiers (August und September, alle Open Access), B6 bis B10 Ore Geology Reviews, B11 bis B15 Water Research, B16 bis B20 Chemical Engineering Journal (alle Reviews), B21 bis B25 Patterns (Cell Press). Ausgewertet am 2026-09-29 und 2026-09-30 nur anhand der Bilder; die fachliche Treue gegenüber den Artikeln ist nicht geprüft. Die Bilder selbst liegen nicht im Skill. B1 bis B5 und B21 bis B25 sind über die DOI abrufbar, B6 bis B20 über Zeitschrift, Jahr und Erstautor.

## Geoscience Frontiers

| Kennung | Artikel | DOI | Muster | Stärke | Hauptmangel |
|---|---|---|---|---|---|
| B1 | Bustos et al., Rare earth element geochemical exploration, southern Andes | 10.1016/j.gsf.2026.102464 | gedrehte Karte als Band, Datentabelle darüber, Methodenband als Fußzeile | Chile um 90 Grad gedreht mit Nordpfeil; Karte, Daten, Methode vertikal zugeordnet | überladen (etwa 90 Wörter, 18 Zahlen), drei Leseebenen, neun unerklärte Kürzel, Rot neben Grün, kein Maßstab |
| B2 | Peng et al., Infrared texture of hydrothermal pyrite | 10.1016/j.gsf.2026.102463 | Artikelabbildung, acht Einzelbilder | eindrucksvolle Zonierung, echte Daten | Collage ohne Leserichtung, Regenbogenskalen ohne Einheit, Maßstab nur in einem Bild, keine Kernaussage |
| B3 | Kashyap et al., Seismogenic sensitivity of buried basement faults, Ganga foreland basin | 10.1016/j.gsf.2026.102461 | Blockdiagramm mit sechs Lupen | zentrales Motiv verbindet Raum und Prozess, Lupen verbinden Detail und Ort | Titel im Bild, sechs Lupen, Text in Vorschaugröße unlesbar, kein Maßstab, Nordpfeil, Überhöhung |
| B4 | Kiran et al., Localized TiO₂ accumulation in Archean stromatolites | 10.1016/j.gsf.2026.102453 | Makro-Mikro-Sequenz in drei Szenen mit Symbollegende | klare Leserichtung, wenig Text, ruhige Palette; bestes der fünf | Maßstabssprung unmarkiert, Übergänge unbeschriftet, Legende etwa ein Drittel der Fläche, Hypothese als Tatsache |
| B5 | Kim et al., Cryosphere-driven freshening and methane source shift, Beaufort Sea mud volcanoes | 10.1016/j.gsf.2026.102451 | Konzeptquerschnitt mit Flusspfeilen | ein Querschnitt trägt die Geschichte, Räume farblich klar getrennt | sieben Kürzel und sieben Farbcodes ohne Legende, kleine Isotopenschrift, kein Maßstab |

### Vergleich an Kernkriterien (B1 bis B5)

| Kriterium | B1 | B2 | B3 | B4 | B5 |
|---|---|---|---|---|---|
| eine erkennbare Kernbotschaft | nein | nein | ja | ja | teilweise |
| eindeutige Leserichtung | nein | nein | ja | ja | ja |
| drei bis fünf Einheiten | nein | nein | nein | ja | ja |
| lesbar in 500 px Breite | teilweise | nein | nein | ja | nein |
| Abkürzungen erklärt | nein | teilweise | ja | ja | nein |
| Farbcodes erklärt | ja | nein | teilweise | ja | nein |
| farbfehlsichtigkeitstauglich | nein | nein | offen | ja | offen |
| Geo-Pflichtelemente vollständig | nein | nein | nein | nein | nein |
| eigens gestaltet | ja | nein | ja | ja | ja |

Die daraus abgeleiteten Regeln R1 bis R10 und die Muster stehen in `gestaltung.md`.

## Ore Geology Reviews, Water Research, Chemical Engineering Journal, Patterns

| Kennung | Artikel | Kennung oder DOI | Muster | Stärke | Hauptmangel |
|---|---|---|---|---|---|
| B6 | Zhang et al., REE-reiche Tiefseesedimente, Pazifik | Ore Geol. Rev. 2026 | drei Felder mit nummerierten Befundsätzen, Schichtband darunter | Befundsätze fassen den Artikel zusammen; Schichtband als Zeitleiste | Felder sind unlesbare Artikelabbildungen, sechs unerklärte Kürzel |
| B7 | Betancur et al., Küstenkordillere Chiles | Ore Geol. Rev. 2026 | drei Stadien eines Blockdiagramms mit Kraftpfeilen | gleiche Geometrie je Stadium, Regime auf einen Blick | Hochformat 0,70 für Querprofil, Farben ohne Legende, kein Maßstab |
| B8 | DeMatties et al., Havallah-Ophiolith | Ore Geol. Rev. 2026 | Säulenkorrelation mit Leithorizont | rot gepunkteter Erzhorizont über mehrere Säulen | mindestens 133 Wörter, Zitate und Bildunterschrift im Bild; schwächstes Beispiel |
| B9 | Shi et al., Zirkone im Trachyt | Ore Geol. Rev. 2026 | zwei Datendiagramme mit Mineralbildern | Bilder an ihren Datenpunkten, Endglieder als Sterne | Artikelabbildung, 18 Altersangaben, keine Kernaussage |
| B10 | Zhao et al., Heqiao | Ore Geol. Rev. 2026 | Datenraster 3 × 3 | konsistentes Raster | Artikelabbildung, Rot gegen Grün allein |
| B11 | Wang et al., agentischer KI-Arbeitsablauf | Water Res. 2026 | vier nummerierte Spalten, Farbverlauf, Rückführband | stärkstes Konzept seiner Gruppe | dicht, etwa 90 Wörter |
| B12 | Hu et al., Membran-Biofilm-Reaktor | Water Res. 2026 | Objekt im Zentrum, Ring I bis III, vier Felder | reales Objekt verankert die Übersicht | drei Marken für vier Felder, Ringtext kopfstehend, sieben Kürzel |
| B13 | Hou et al., Cyanotoxin-Vorhersage | Water Res. 2026 | vier Spalten unter Bannern, Problem als Mini-Diagramm | die Lücke, die die Arbeit schließt, als Diagramm | Regenbogen-Heatmaps, Kürzel XAI, PIML |
| B14 | Wang et al., Elektronenfluss an Grenzflächen | Water Res. 2026 | Review-Rad, Yin-Yang-Kern | zwei Partner als Yin-Yang ohne Text | Tippfehler in der Kernaussage, Inhalte unlesbar |
| B15 | Bu et al., RSNet, Wasserqualitätsprognose | Water Res. 2026 | drei Spalten, Eingaben als Kachelraster | Vielfalt der Eingaben sichtbar | mindestens 75 Wörter, echte Karten mit Regenbogenskala |
| B16 | Li et al., Bioelektronik im Regelkreis | Chem. Eng. J. 2026 | Objekt im Zentrum, Kreislaufring, vier Eckfelder | Regelkreis sofort verständlich | Titel im Bild, 17 Symbole in den Ecken |
| B17 | Wang et al., steuerbare Festtreibstoffe | Chem. Eng. J. 2026 | fünf Sektoren, Eigenschaftsring, Anwendungsperlen | zwei neue Ebenen ohne Kästen | drei Ringe, überladen, Kürzel ECSPs |
| B18 | Lu et al., Molekülorientierung | Chem. Eng. J. 2026 | vier Lappen A bis D, Kernübergang im Zentrum | Zentrum zeigt die Kernaussage als Bild | sehr dicht, fünf Kürzel, Serifenschrift |
| B19 | Chang et al., Mikro- und Nanoblasen | Chem. Eng. J. 2026 | Szene im Eigenschaftsring, drei Listen | größte Schrift der Stichprobe | zwölf Aufzählungspunkte, Rahmenfarben ohne Bedeutung, senkrechter Text |
| B20 | Wu et al., Persulfat-Aktivierung | Chem. Eng. J. 2026 | symmetrisches Triptychon um ein Rad | Spiegelung macht den Vergleich textfrei lesbar | Worttrennung im Zentrum, zehn Kürzel |
| B21 | Farajiamiri et al., gemeinsame Evidenz, Radiologie | 10.1016/j.patter.2026.101639 | drei Felder, Weggabelung, Buchstabenwolken, Balkenpaare | Konsens als gebündelte Buchstaben, Richtung als ↑ oder ↓ | sechs Anbieterlogos, unbeschriftete Rot-Grün-Torte |
| B22 | Shen et al., mBoost | 10.1016/j.patter.2026.101643 | Kreislauf, Trichter, Schwellenskala | "Good Model?" gegen "Good Model!", Trichter 120 zu 20 | Balkendiagramm mit 19 Kürzeln, Rot gegen Grün |
| B23 | Qin et al., CLEAR-HPV | 10.1016/j.patter.2026.101588 | Weggabelung, Symbolpaar Auge | eine Akzentfarbe nur für das Neue; bestes Beispiel der 25 | Kürzel MIL, Leerraum unten links |
| B24 | Xu et al., OscillomeR | 10.1016/j.patter.2026.101612 | Vorher-Nachher derselben Heatmap, Ring als Methode | Leistung der Methode ohne Zahl | sechs Kürzel, zwei Ebenen |
| B25 | Lorenz et al., Stichprobenverzerrung bei PID | 10.1016/j.patter.2026.101619 | Ursache links, Korrektur als Balken gegen Soll-Linie | Soll-Linie und Schraffur | Tippfehler, linke Hälfte ist Artikelabbildung |

Die daraus abgeleiteten Regeln R11 bis R20, die Muster I8 bis I27 und die Musterwahl nach Artikeltyp stehen in `gestaltung.md`.

## Stichprobe zur Verbreitung

| Zeitschrift | Stichprobe 2026 | mit Graphical Abstract auf der Artikelseite |
|---|---|---|
| Geoscience Frontiers | 5 Artikel, August und September | 5 |
| Progress in Earth and Planetary Science | 5 Artikel, August und September | 0 (Sichtprüfung durch den Auftraggeber) |
| Earth and Planetary Science Letters | 6 Artikel aus Band 692 | 0 |
| Ore Geology Reviews | 5 Artikel | 5 |
| Water Research | 6 Artikel, davon 5 lesbar | 5 |
| Chemical Engineering Journal | 5 Artikel | 5 |
| Patterns | 12 Artikel, davon 11 lesbar | 5; ohne GA beide Reviews und 4 von 9 Forschungsartikeln |
| Engineering Applications of Artificial Intelligence | 5 Artikel, davon 4 lesbar | 0 |
| Applied Energy | 7 Artikel | 2 |
| Environmental Modelling & Software | 3 Artikel | 1 |
