# Checkliste und Bewertungsraster

## Checkliste vor dem Einreichen

Die mit (M) markierten Punkte misst `ga_check.py`, die übrigen prüft Claude am Prüfbogen und am Manuskript.

**Formal**
- [ ] Aktueller Guide for Authors geprüft: Pflichtstatus, Maße, Begleittext, KI-Regel
- [ ] Pixelmaße und Seitenverhältnis erfüllen das Profil (M)
- [ ] Mindestauflösung und Dateiformat zulässig, RGB
- [ ] Kein Titel, keine Autoren, keine Zitate, keine Überschrift "Graphical Abstract"
- [ ] Leerer Rand unter 6 Prozent je Seite, kein Inhalt berührt den Bildrand (M)

**Inhalt**
- [ ] Kernbotschaft in einem Satz formulierbar und im Bild erkennbar
- [ ] Kontext, Ansatz, Hauptergebnis vorhanden; Ergebnis dominant
- [ ] Jede Bildaussage hat eine Fundstelle im Manuskript
- [ ] Jede Zahl hat Einheit oder Bezugswort, jedes Symbol eine Beschriftung oder eindeutige Fachkonvention
- [ ] Kein Ergebniswort verspricht mehr, als die Quelle trägt; keine KI-Selbstbewertung als Freigabe
- [ ] Pflichtschritte und Grundregeln der Quelle sind sichtbar oder ihr Fehlen ist im Konzept begründet
- [ ] Spekulation erkennbar markiert, nichts über den Artikel hinaus; was die Quelle als möglich oder vermutet bezeichnet, ist im Bild als Hypothese gekennzeichnet (R9)
- [ ] Kernbotschaft und Bausteine vor der Konzeptwahl gegen die Quelle geprüft; jedes Merkmal der Quelle einer Stufe zugeordnet (Bild oder Prüfbericht)
- [ ] Begriffe, Farben, Einheiten wie in Abstract und Abbildungen

**Gestaltung**
- [ ] Klare Leserichtung mit Anfang und Ende
- [ ] Drei bis fünf Bildeinheiten, Beziehungen durch Pfeile eindeutig
- [ ] Kleinste Schrift nicht unter dem Profilminimum (M)
- [ ] Höchstens 40 Wörter (M)
- [ ] Jede Abkürzung ausgeschrieben oder erklärt (R1) (M)
- [ ] Jede bedeutungstragende Farbe und Strichart in der Legende oder direkt beschriftet (R2)
- [ ] Maßstabssprünge zwischen Bildteilen markiert, jeder Teil mit Maßstab oder Größenangabe (R3)
- [ ] Gedrehte Karte mit auffälligem Nordpfeil (R4)
- [ ] Höchstens drei bis vier Lupen, jede mit Verbindungslinie (R5)
- [ ] Datenbilder mit gleichmäßiger Skala, Einheit und Maßstab (R6)
- [ ] Legende höchstens ein Fünftel der Fläche (R7) (M)
- [ ] Höchstens fünf Zahlen, jede mit Einheit oder Bezugswort (R8) (M)
- [ ] Eine Leserichtung; ein Methodenband als Fußzeile erkennbar untergeordnet (R10)
- [ ] Bildtext rechtschreibgeprüft, keine Worttrennung (R11) (M)
- [ ] Ordnungsmarken in einem System, lückenlos, so viele wie Einheiten (R12) (M)
- [ ] Radiallayout mit höchstens fünf Sektoren und einem Ring, Zentrum zeigt die Kernaussage, Start und Richtung markiert (R13)
- [ ] Kein Text auf dem Kopf oder senkrecht, Bogentext höchstens drei Wörter (R14) (M)
- [ ] Keine Aufzählungsliste mit mehr als drei Punkten (R16) (M)
- [ ] Jede Farbe hat eine benannte Rolle (R17)
- [ ] Diagramme qualitativ, Achsen oder Richtung beschriftet, Referenzlinien beschriftet (R18)
- [ ] Anordnung folgt dem Zielformat, nicht der Artikelabbildung (R19)
- [ ] Übernommene Artikelabbildung zugeschnitten, mit Befundsatz (R20)
- [ ] Einheitlicher Symbolstil
- [ ] Unterscheidungen bleiben in Deuteranopie, Protanopie, Tritanopie und Graustufen erhalten (Prüfbogen)
- [ ] Geo-Pflichtelemente vollständig

**Rechte und Integrität**
- [ ] Fremdelemente lizenziert und belegt
- [ ] KI-Regel der Zeitschrift beachtet; bei Verbot als Konzeptentwurf zur Reinzeichnung gekennzeichnet
- [ ] Keine Personenfotos, Logos, Marken; auch keine Logos von KI-Modellen oder Software (R15)

**Konzeptwahl und unabhängige Prüfung**
- [ ] Zwei Konzepte entlang einer benannten Achse verglichen, Wahl des Nutzers dokumentiert
- [ ] Unabhängige Prüfung durchgeführt (oder als "nicht unabhängig" vermerkt), Fragen F1 bis F3, F5 und F4 der Stufen 1 und 2 ohne offenen Befund; Stufe-3-Befunde im Prüfbericht

**Test**
- [ ] Vorschau in Anzeigegröße: Kernaussage in fünf Sekunden erkennbar (Prüfbogen)
- [ ] Fünf-Sekunden-Test mit fachfremder Person (durch den Nutzer)

## Bewertungsraster

Je Kriterium 0, 1 oder 2 Punkte, höchstens 20. Jede Punktzahl mit einem Satz begründen. Bewertet wird zweimal, von Claude und von der unabhängigen Prüfinstanz; je Kriterium zählt der niedrigere Wert.

| Kriterium | 0 | 1 | 2 |
|---|---|---|---|
| 1. Kernbotschaft | nicht erkennbar oder mehrere konkurrierende | erkennbar, aber erst nach längerem Hinsehen; oder eine Zahl, ein Symbol, eine Abkürzung oder ein Farbcode ohne Bezug | in fünf Sekunden klar, ohne Vorwissen aus der Quelle |
| 2. Leserichtung | keine, Collage | vorhanden, mit Sprüngen; oder Ordnungsmarken passen nicht zu den Einheiten (R12); oder Radiallayout ohne Start und Richtung (R13) | eindeutiger Anfang und Ende |
| 3. Vollständigkeit | nur ein Baustein | zwei Bausteine | Kontext, Ansatz, Ergebnis; Ergebnis dominant |
| 4. Reduktion | überladen, etwa Tabelle mit vielen Zahlen, mehr als vier Lupen oder ein Radialbild mit mehreren Ringen | teilweise überladen; oder Legende größer als ein Fünftel; oder mehr als fünf Sektoren | nur Wesentliches, drei bis fünf Einheiten |
| 5. Lesbarkeit in Anzeigegröße | Text unlesbar | teilweise lesbar; oder Text auf dem Kopf oder senkrecht (R14) | vollständig lesbar |
| 6. Textmenge | Sätze oder Absätze | mehrere Phrasen, über 40 Wörter; oder Aufzählungsliste mit mehr als drei Punkten (R16) | Beschriftungen und eine Kernaussage |
| 7. Farbe und Barrierefreiheit | Regenbogen oder Rot-Grün ohne Redundanz | meist unproblematisch; oder Farbe ohne Rolle (R17) | alle Simulationen bestanden, funktionale Akzentfarbe |
| 8. Stilkonsistenz | gemischte Stile | kleine Brüche | einheitlich |
| 9. Fachliche Treue | Widerspruch oder Überzeichnung | kleine Abweichungen; oder ein Ergebniswort, das mehr verspricht als die Quelle; oder ein fehlender Pflichtschritt der Quelle (F4 Stufe 1 oder 2); oder eine Hypothese als Tatsache | deckungsgleich mit dem Artikel, Unsicherheit sichtbar |
| 10. Formale und rechtliche Konformität | Verstoß, etwa Logos oder Marken (R15) | kleine Mängel; oder ein Rechtschreib- oder Trennfehler (R11); oder die Anordnung passt nicht zum Zielformat (R19) | vollständig konform |

17 bis 20 Punkte: einreichungsreif. 12 bis 16: überarbeiten, meist Reduktion und Lesbarkeit. Unter 12: neu konzipieren, beginnend bei der Kernbotschaft.
