#!/usr/bin/env python3
"""SVG nach PNG in den Pixelmaßen des SVG rendern.

Aufruf:
    python3 render_svg.py eingabe.svg ausgabe.png [--breite PX]

Probiert der Reihe nach cairosvg, rsvg-convert, Inkscape und Chromium (Playwright).
Ohne --breite gilt das width-Attribut des SVG, sonst die viewBox-Breite.
"""
import argparse
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


def svg_masse(pfad):
    wurzel = ET.parse(pfad).getroot()

    def zahl(wert):
        if not wert:
            return None
        treffer = re.match(r"\s*([0-9.]+)\s*(px)?\s*$", wert)
        return float(treffer.group(1)) if treffer else None

    breite, hoehe = zahl(wurzel.get("width")), zahl(wurzel.get("height"))
    if (breite is None or hoehe is None) and wurzel.get("viewBox"):
        _, _, vb_b, vb_h = [float(x) for x in wurzel.get("viewBox").replace(",", " ").split()]
        breite, hoehe = breite or vb_b, hoehe or vb_h
    if breite is None or hoehe is None:
        sys.exit("FEHLER: SVG hat weder width/height in px noch viewBox.")
    return breite, hoehe


def mit_cairosvg(svg, png, b, h):
    import cairosvg  # noqa: F401
    cairosvg.svg2png(url=str(svg), write_to=str(png), output_width=b, output_height=h, background_color="white")


def mit_rsvg(svg, png, b, h):
    if not shutil.which("rsvg-convert"):
        raise RuntimeError("rsvg-convert fehlt")
    subprocess.run(["rsvg-convert", "-w", str(b), "-h", str(h), "-b", "white", "-o", str(png), str(svg)], check=True)


def mit_inkscape(svg, png, b, h):
    if not shutil.which("inkscape"):
        raise RuntimeError("inkscape fehlt")
    subprocess.run(["inkscape", str(svg), "--export-type=png", f"--export-filename={png}",
                    f"--export-width={b}", f"--export-height={h}", "--export-background=white",
                    "--export-background-opacity=1"], check=True, capture_output=True)


def mit_chromium(svg, png, b, h):
    from playwright.sync_api import sync_playwright
    inhalt = Path(svg).read_text(encoding="utf-8")
    inhalt = re.sub(r"<\?xml[^>]*\?>", "", inhalt)
    html = ("<!doctype html><html><head><meta charset='utf-8'><style>"
            "html,body{margin:0;padding:0;background:#fff;overflow:hidden}"
            f"svg{{display:block;width:{b}px;height:{h}px}}</style></head><body>{inhalt}</body></html>")
    with sync_playwright() as p:
        browser = p.chromium.launch()
        seite = browser.new_page(viewport={"width": b, "height": h}, device_scale_factor=1)
        seite.set_content(html)
        seite.wait_for_timeout(200)
        seite.screenshot(path=str(png), clip={"x": 0, "y": 0, "width": b, "height": h})
        browser.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("svg")
    ap.add_argument("png")
    ap.add_argument("--breite", type=int, help="Zielbreite in px, Höhe proportional")
    a = ap.parse_args()

    b, h = svg_masse(a.svg)
    if a.breite:
        h = h * a.breite / b
        b = a.breite
    b, h = int(round(b)), int(round(h))

    fehler = []
    for name, fn in [("cairosvg", mit_cairosvg), ("rsvg-convert", mit_rsvg),
                     ("inkscape", mit_inkscape), ("chromium", mit_chromium)]:
        try:
            fn(a.svg, a.png, b, h)
            print(f"OK: {a.png} ({b} x {h} px) mit {name}")
            return
        except Exception as e:  # nächster Renderer
            fehler.append(f"{name}: {e}")
    sys.exit("FEHLER: kein Renderer verfügbar.\n  " + "\n  ".join(fehler))


if __name__ == "__main__":
    main()
