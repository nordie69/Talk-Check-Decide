#!/usr/bin/env python3
"""Graphical Abstract messen und Prüfbogen erzeugen.

Aufruf:
    python3 ga_check.py ga.png --profil elsevier [--svg ga.svg] [--out pruefung/] [--tiff]
        [--kuerzel-ok REE,GPS] [--woerter-ok geochemical] [--sprache en_US] [--einheiten 4]

Misst: Pixelmaße gegen das Zielprofil, leeren Rand je Seite, Unterscheidbarkeit
der Hauptfarben unter Deuteranopie, Protanopie, Tritanopie und in Graustufen,
mit --svg zusätzlich kleinste Schrift in Ausgabepixeln, Wortzahl, verbotene
Bildtexte und Gedankenstriche, unerklärte Abkürzungen (R1), Legendenfläche
(R7, Gruppe mit id="legende"), Zahl der Zahlen im Bildtext ohne Ordnungsmarken (R8),
Worttrennung und Rechtschreibung (R11), Ordnungsmarken in der Gruppe id="marken" (R12),
kopfstehenden, senkrechten und Bogentext (R14) und Aufzählungen je Gruppe (R16).
Schreibt pruefbogen.png und bericht.json.
Rückgabewert 1, wenn ein FEHLER vorliegt, sonst 0.
"""
import argparse
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

# modus: exakt | min | max | ca | minmax | frei ; vorschau in px ; schrift_min in Ausgabepixeln
PROFILE = {
    "elsevier": dict(modus="min", b=1328, h=531, verhaeltnis=2.5, toleranz=0.03, vorschau=(500, 200), schrift_min=24, dpi=300),
    "cell": dict(modus="exakt", b=1200, h=1200, vorschau=(400, 400), schrift_min=50, dpi=300),
    "acs": dict(modus="max", b=975, h=525, vorschau=(312, 168), schrift_min=25, dpi=300),
    "rsc": dict(modus="max", b=1890, h=945, vorschau=(302, 151), schrift_min=50, dpi=600),
    "wiley-toc": dict(modus="ca", b=650, h=591, toleranz=0.05, vorschau=(260, 236), schrift_min=25, dpi=300),
    "wiley-toc-quer": dict(modus="ca", b=1330, h=295, toleranz=0.03, vorschau=(520, 118), schrift_min=25, dpi=300),
    "geojournal": dict(modus="max", b=591, h=709, vorschau=(236, 284), schrift_min=25, dpi=300),
    "mdpi": dict(modus="minmax", b=1100, h=560, b_max=5500, h_max=2800, vorschau=(500, 255), schrift_min=24, dpi=300),
    "peps": dict(modus="ca", b=920, h=300, toleranz=0.05, vorschau=(460, 150), schrift_min=24, dpi=300),
    "frei": dict(modus="frei", vorschau=(500, None), schrift_min=24, dpi=300),
    "social": dict(modus="exakt", b=1200, h=675, vorschau=(500, 281), schrift_min=28, dpi=150),
}

# Machado, Oliveira, Fernandes (2009), Schweregrad 1,0, lineares RGB
CVD = {
    "Deuteranopie": np.array([[0.367322, 0.860646, -0.227968], [0.280085, 0.672501, 0.047413], [-0.011820, 0.042940, 0.968881]]),
    "Protanopie": np.array([[0.152286, 1.052583, -0.204868], [0.114503, 0.786281, 0.099216], [-0.003882, -0.048116, 1.051998]]),
    "Tritanopie": np.array([[1.255528, -0.076749, -0.178779], [-0.078411, 0.930809, 0.147602], [0.004733, 0.691367, 0.303900]]),
}

WORT_MAX = 40
ZAHLEN_MAX = 5
LEGENDE_MAX = 0.20
RAND_MAX = 0.06
DELTA_E_MIN = 12.0


def lin(srgb):
    s = srgb / 255.0
    return np.where(s <= 0.04045, s / 12.92, ((s + 0.055) / 1.055) ** 2.4)


def delin(l):
    l = np.clip(l, 0, 1)
    s = np.where(l <= 0.0031308, l * 12.92, 1.055 * np.power(l, 1 / 2.4) - 0.055)
    return np.clip(s * 255 + 0.5, 0, 255).astype(np.uint8)


def simuliere(arr, name):
    if name == "Graustufen":
        y = lin(arr.astype(float)) @ np.array([0.2126, 0.7152, 0.0722])
        g = delin(y)
        return np.stack([g, g, g], axis=-1)
    return delin(lin(arr.astype(float)) @ CVD[name].T)


def lab(rgb):
    l = lin(np.asarray(rgb, dtype=float))
    xyz = l @ np.array([[0.4124, 0.3576, 0.1805], [0.2126, 0.7152, 0.0722], [0.0193, 0.1192, 0.9505]]).T
    xyz = xyz / np.array([0.95047, 1.0, 1.08883])
    f = np.where(xyz > 0.008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    return np.stack([116 * f[..., 1] - 16, 500 * (f[..., 0] - f[..., 1]), 200 * (f[..., 1] - f[..., 2])], axis=-1)


def pruefe_masse(b, h, p):
    m = p["modus"]
    if m == "frei":
        return "OK", f"{b} x {h} px, keine Verlagsvorgabe"
    soll = f"{p['b']} x {p['h']}"
    if m == "exakt":
        ok = (b, h) == (p["b"], p["h"])
        return ("OK" if ok else "FEHLER"), f"{b} x {h} px, Soll genau {soll}"
    if m == "min":
        ok = b >= p["b"] and h >= p["h"]
        v = b / h
        v_ok = abs(v - p["verhaeltnis"]) / p["verhaeltnis"] <= p["toleranz"]
        status = "OK" if ok and v_ok else "FEHLER"
        return status, f"{b} x {h} px, Verhältnis {v:.3f}, Soll mind. {soll} und {p['verhaeltnis']}"
    if m == "max":
        ok = b <= p["b"] and h <= p["h"]
        return ("OK" if ok else "FEHLER"), f"{b} x {h} px, Soll höchstens {soll}"
    if m == "minmax":
        ok = p["b"] <= b <= p["b_max"] and p["h"] <= h <= p["h_max"]
        return ("OK" if ok else "FEHLER"), f"{b} x {h} px, Soll {soll} bis {p['b_max']} x {p['h_max']}"
    if m == "ca":
        ok = abs(b - p["b"]) / p["b"] <= p["toleranz"] and abs(h - p["h"]) / p["h"] <= p["toleranz"]
        return ("OK" if ok else "HINWEIS"), f"{b} x {h} px, Soll etwa {soll}"
    return "HINWEIS", "unbekannter Modus"


def pruefe_rand(arr):
    ecken = np.array([arr[0, 0], arr[0, -1], arr[-1, 0], arr[-1, -1]]).astype(int)
    hg = np.median(ecken, axis=0)
    diff = np.abs(arr.astype(int) - hg).max(axis=-1) > 12
    zeilen, spalten = np.where(diff.any(axis=1))[0], np.where(diff.any(axis=0))[0]
    h, b = diff.shape
    if len(zeilen) == 0:
        return "FEHLER", {"hinweis": "Bild ist leer"}
    r = {"oben": zeilen[0] / h, "unten": (h - 1 - zeilen[-1]) / h,
         "links": spalten[0] / b, "rechts": (b - 1 - spalten[-1]) / b}
    befund = {k: round(v * 100, 1) for k, v in r.items()}
    beruehrt = [k for k, v in r.items() if v * min(b, h) < 4]
    status = "OK" if max(r.values()) <= RAND_MAX else "HINWEIS"
    if beruehrt:
        status = "FEHLER"
        befund["beruehrt_bildrand"] = beruehrt
    return status, befund


def hauptfarben(arr, n=16, anteil_min=0.004):
    """Hauptfarben der Nicht-Hintergrund-Pixel; dünne Akzentlinien zählen mit."""
    pix = arr.reshape(-1, 3)
    hg = np.median(np.array([arr[0, 0], arr[0, -1], arr[-1, 0], arr[-1, -1]]), axis=0)
    vorder = pix[np.abs(pix.astype(int) - hg).max(axis=1) > 12]
    if len(vorder) == 0:
        return [(hg, 1.0)]
    # Vektorgrafik: Gestaltungsfarben kommen exakt und häufig vor, Kantenglättung nur vereinzelt
    werte, zaehl = np.unique(vorder, axis=0, return_counts=True)
    anteil = zaehl / len(vorder)
    kand = werte[anteil >= anteil_min][np.argsort(-anteil[anteil >= anteil_min])]
    if len(kand) < 2:  # Rasterbild oder Foto: auf Quantisierung ausweichen
        img = Image.fromarray(vorder.reshape(1, -1, 3).astype(np.uint8)).quantize(colors=n, method=Image.Quantize.MEDIANCUT)
        pal = np.array(img.getpalette()[: n * 3]).reshape(-1, 3)
        z = np.bincount(np.array(img).ravel(), minlength=n)[:n]
        kand = pal[z / z.sum() >= anteil_min]
    farben = [(hg, None)]
    for f in kand[:n]:  # nahezu gleiche Farben zusammenfassen
        if all(np.linalg.norm(lab(f) - lab(g)) >= 3 for g, _ in farben):
            farben.append((f, None))
    return farben


def pruefe_farben(arr):
    farben = hauptfarben(arr)
    rgb = np.array([f[0] for f in farben], dtype=float)
    ergebnis = {"hauptfarben": ["#%02x%02x%02x" % tuple(int(c) for c in f[0]) for f in farben], "verluste": {}}
    orig = lab(rgb)
    status = "OK"
    for name in list(CVD) + ["Graustufen"]:
        sim = lab(simuliere(rgb.reshape(1, -1, 3).astype(np.uint8), name).reshape(-1, 3).astype(float))
        verl = []
        for i in range(len(rgb)):
            for j in range(i + 1, len(rgb)):
                de_o = float(np.linalg.norm(orig[i] - orig[j]))
                de_s = float(np.linalg.norm(sim[i] - sim[j]))
                if de_o >= DELTA_E_MIN and de_s < DELTA_E_MIN:
                    verl.append([ergebnis["hauptfarben"][i], ergebnis["hauptfarben"][j], round(de_o, 1), round(de_s, 1)])
        if verl:
            ergebnis["verluste"][name] = verl
            if name != "Graustufen":
                status = "HINWEIS"
    return status, ergebnis


def pruefe_svg(pfad, png_breite, p):
    baum = ET.parse(pfad)
    wurzel = baum.getroot()
    ns = "{http://www.w3.org/2000/svg}"

    def zahl(w):
        t = re.match(r"\s*([0-9.]+)", w or "")
        return float(t.group(1)) if t else None

    vb = wurzel.get("viewBox")
    vb_b = float(vb.replace(",", " ").split()[2]) if vb else zahl(wurzel.get("width"))
    faktor = png_breite / vb_b if vb_b else 1.0

    groessen, texte, zu_klein = [], [], []

    def groesse(el, erbe):
        g = zahl(el.get("font-size"))
        stil = el.get("style") or ""
        t = re.search(r"font-size\s*:\s*([0-9.]+)", stil)
        if t:
            g = float(t.group(1))
        return g if g is not None else erbe

    def lauf(el, erbe):
        g = groesse(el, erbe)
        if el.tag in (ns + "text", "text"):
            inhalt = " ".join("".join(el.itertext()).split())
            if inhalt:
                # Größen der tspans einzeln erfassen
                eigene = [groesse(k, g) for k in el.iter() if k.tag in (ns + "tspan", "tspan") and (k.text or "").strip()]
                kleinste = min([g] + eigene) if eigene else g
                px = kleinste * faktor
                groessen.append(px)
                texte.append(inhalt)
                if px < p["schrift_min"]:
                    zu_klein.append([inhalt, round(px, 1)])
            return
        for k in el:
            lauf(k, g)

    lauf(wurzel, 16.0)
    woerter = sum(len(t.split()) for t in texte)
    alles = " ".join(texte)
    verboten = []
    if re.search(r"graphical\s+abstract", alles, re.I):
        verboten.append("Bildtext enthält 'Graphical Abstract'")
    if "—" in alles or "--" in alles:
        verboten.append("Gedankenstrich oder doppelter Bindestrich im Bildtext")
    befund = {
        "textelemente": len(texte),
        "woerter": woerter,
        "kleinste_schrift_px": round(min(groessen), 1) if groessen else None,
        "schrift_min_profil_px": p["schrift_min"],
        "zu_klein": zu_klein,
        "verboten": verboten,
        "texte": texte,
    }
    status = "OK"
    if woerter > WORT_MAX:
        status = "HINWEIS"
    if zu_klein or verboten:
        status = "FEHLER"
    return status, befund


def pruefe_regeln(pfad, texte, kuerzel_ok, marken_texte=()):
    """R1 Abkürzungen, R7 Legendenfläche, R8 Zahlen; Näherungen, Befund HINWEIS.
    Ordnungsmarken (Gruppe id="marken", R12) zählen nicht als Zahlen."""
    wurzel = ET.parse(pfad).getroot()
    ns = "{http://www.w3.org/2000/svg}"
    alles = " ".join(texte)
    rest = list(texte)
    for m in marken_texte:
        if m in rest:
            rest.remove(m)
    alles_ohne_marken = " ".join(rest)
    # R1: Wörter mit mindestens zwei Großbuchstaben, ohne Kleinbuchstaben und ohne Ziffern (Formeln wie CO2 zählen nicht)
    kandidaten = sorted({t for t in re.findall(r"(?<![\w])[A-ZÄÖÜ][A-ZÄÖÜ0-9*]+(?![\w])", alles)
                         if len(re.sub(r"[^A-ZÄÖÜ]", "", t)) >= 2 and not re.search(r"\d", t)})
    unerklaert = []
    for k in kandidaten:
        if k in kuerzel_ok:
            continue
        e = re.escape(k)
        if re.search(e + r"\s*[:=]", alles) or re.search(r"\(\s*" + e + r"\s*\)", alles):
            continue
        unerklaert.append(k)
    # R8: Zahlen, die nicht an einem Buchstaben hängen (Formeln wie CO2, δ18O zählen nicht)
    zahlen = re.findall(r"(?<![\w.,])\d+(?:[.,]\d+)?", alles_ohne_marken)
    # R7: Fläche der Rechtecke in der Gruppe id="legende" gegen die Bildfläche
    vb = wurzel.get("viewBox")
    if vb:
        _, _, vb_b, vb_h = [float(x) for x in vb.replace(",", " ").split()]
    else:
        vb_b, vb_h = float(re.match(r"[0-9.]+", wurzel.get("width")).group()), float(re.match(r"[0-9.]+", wurzel.get("height")).group())
    legende = None
    for el in wurzel.iter():
        if re.fullmatch(r"(?i)legende?|legend", el.get("id") or ""):
            legende = el
            break
    anteil, hinweis_leg = None, None
    if legende is not None:
        boxen = []
        for r in legende.iter():
            if r.tag in (ns + "rect", "rect") and r.get("width") and r.get("height"):
                x, y = float(r.get("x", 0)), float(r.get("y", 0))
                boxen.append((x, y, x + float(r.get("width")), y + float(r.get("height"))))
        if boxen:
            x0, y0 = min(b[0] for b in boxen), min(b[1] for b in boxen)
            x1, y1 = max(b[2] for b in boxen), max(b[3] for b in boxen)
            anteil = round((x1 - x0) * (y1 - y0) / (vb_b * vb_h), 3)
        else:
            hinweis_leg = "Gruppe legende ohne Rechteck, Fläche nicht messbar"
        if any(e.get("transform") for e in legende.iter()):
            hinweis_leg = "transform in der Legende, Fläche nur Näherung"
    befund = {
        "kuerzel_gefunden": kandidaten,
        "kuerzel_unerklaert": unerklaert,
        "zahlen": len(zahlen),
        "zahlen_max": ZAHLEN_MAX,
        "legende_anteil": anteil if legende is not None else "keine Legende markiert",
        "legende_max": LEGENDE_MAX,
    }
    if hinweis_leg:
        befund["legende_hinweis"] = hinweis_leg
    status = "OK"
    if unerklaert or len(zahlen) > ZAHLEN_MAX or (anteil is not None and anteil > LEGENDE_MAX):
        status = "HINWEIS"
    return status, befund


RÖMISCH = {"I": 1, "II": 2, "III": 3, "IV": 4, "V": 5, "VI": 6, "VII": 7, "VIII": 8}
AUFZAEHLUNG = "•·▪◦●■‣"


def winkel(transform):
    """Summe der Drehwinkel aus rotate() und matrix() in Grad."""
    w = 0.0
    for art, werte in re.findall(r"(rotate|matrix)\s*\(([^)]*)\)", transform or ""):
        z = [float(x) for x in re.findall(r"-?[0-9.]+(?:e-?\d+)?", werte)]
        if art == "rotate" and z:
            w += z[0]
        elif art == "matrix" and len(z) >= 2:
            w += float(np.degrees(np.arctan2(z[1], z[0])))
    return w


def textelemente(pfad):
    """Alle text-Elemente mit Zeilen, Drehwinkel, Bogentext und Zugehörigkeit zu Gruppen."""
    ns = "{http://www.w3.org/2000/svg}"
    ergebnis = []

    def lauf(el, w, gruppen):
        w = w + winkel(el.get("transform"))
        eid = (el.get("id") or "").lower()
        if eid:
            gruppen = gruppen + [eid]
        if el.tag in (ns + "text", "text"):
            zeilen = [" ".join((k.text or "").split()) for k in el.iter()
                      if k.tag in (ns + "tspan", "tspan", ns + "textPath", "textPath") and (k.text or "").strip()]
            inhalt = " ".join("".join(el.itertext()).split())
            if inhalt:
                modus = (el.get("writing-mode") or "") + (el.get("style") or "")
                ergebnis.append(dict(
                    inhalt=inhalt,
                    zeilen=zeilen or [inhalt],
                    winkel=((w + 180) % 360) - 180,
                    bogen=any(k.tag in (ns + "textPath", "textPath") for k in el.iter()),
                    senkrecht=bool(re.search(r"\btb\b|vertical|tb-rl", modus)),
                    marke=any(re.fullmatch(r"marken?|marks?", g) for g in gruppen),
                    gruppe=gruppen[-1] if gruppen else "",
                ))
            return
        for k in el:
            lauf(k, w, gruppen)

    lauf(ET.parse(pfad).getroot(), 0.0, [])
    return ergebnis


def rechtschreibung(texte, sprache, erlaubt):
    """Unbekannte Wörter über spylls oder hunspell; ohne Wörterbuch None."""
    woerter = sorted({w for t in texte for w in re.findall(r"[A-Za-zÄÖÜäöüß]{3,}", t)
                      if not w.isupper() and w not in erlaubt and w.lower() not in erlaubt})
    for basis in [f"/usr/share/hunspell/{sprache}", f"/usr/share/myspell/{sprache}",
                  f"/usr/share/myspell/dicts/{sprache}", f"/Library/Spelling/{sprache}"]:
        if Path(basis + ".dic").exists():
            try:
                from spylls.hunspell import Dictionary
                d = Dictionary.from_files(basis)
                return [w for w in woerter if not d.lookup(w)], f"spylls, {basis}.dic"
            except ImportError:
                pass
            import shutil
            import subprocess
            if shutil.which("hunspell"):
                aus = subprocess.run(["hunspell", "-d", basis, "-l"], input="\n".join(woerter),
                                     capture_output=True, text=True).stdout.split()
                return sorted(set(aus)), f"hunspell, {basis}.dic"
    return None, f"kein Wörterbuch {sprache} oder weder spylls noch hunspell verfügbar"


def pruefe_textgestalt(elemente, einheiten, sprache, woerter_ok):
    """R11 Trennung und Rechtschreibung, R12 Ordnungsmarken, R14 Textdrehung, R16 Aufzählungen."""
    befund, fehler, hinweis = {}, False, False
    # R11: Trennstrich zwischen Kleinbuchstaben am Zeilenende oder innerhalb einer Zeile vor Leerraum
    trennungen = []
    for e in elemente:
        z = e["zeilen"]
        for i, zeile in enumerate(z):
            if re.search(r"[a-zäöüß]-$", zeile) and (i + 1 == len(z) or re.match(r"[a-zäöüß]", z[i + 1])):
                trennungen.append(e["inhalt"])
        if re.search(r"[a-zäöüß]-\s+[a-zäöüß]", e["inhalt"]):
            trennungen.append(e["inhalt"])
    befund["worttrennung"] = sorted(set(trennungen))
    unbekannt, quelle = rechtschreibung([e["inhalt"] for e in elemente], sprache, woerter_ok)
    befund["rechtschreibung"] = {"unbekannt": unbekannt, "quelle": quelle} if unbekannt is not None else {"nicht_geprueft": quelle}
    if trennungen:
        fehler = True
    if unbekannt:
        hinweis = True
    # R12: Ordnungsmarken
    marken = [e["inhalt"] for e in elemente if e["marke"]]
    if marken:
        roh = [re.sub(r"[.)\s]", "", m) for m in marken]
        if all(r.isdigit() for r in roh):
            system, werte = "Ziffern", sorted(int(r) for r in roh)
        elif all(r in RÖMISCH for r in roh):
            system, werte = "römisch", sorted(RÖMISCH[r] for r in roh)
        elif all(len(r) == 1 and r.isalpha() for r in roh):
            system, werte = "Buchstaben", sorted(ord(r.upper()) - 64 for r in roh)
        else:
            system, werte = "gemischt", []
        luecke = bool(werte) and werte != list(range(werte[0], werte[0] + len(werte)))
        befund["marken"] = {"anzahl": len(marken), "system": system, "lueckenlos": not luecke if werte else None,
                            "einheiten": einheiten}
        if system == "gemischt" or luecke or (einheiten and len(marken) != einheiten):
            hinweis = True
    else:
        befund["marken"] = "keine Gruppe id=marken"
    # R14: Drehung
    kopf = [[e["inhalt"], round(e["winkel"])] for e in elemente if abs(e["winkel"]) > 90]
    steil = [[e["inhalt"], round(e["winkel"])] for e in elemente if 60 < abs(e["winkel"]) <= 90 or e["senkrecht"]]
    bogen = [e["inhalt"] for e in elemente if e["bogen"]]
    bogen_lang = [t for t in bogen if len(t.split()) > 3]
    befund["drehung"] = {"kopfstehend": kopf, "senkrecht_oder_steil": steil, "bogentext": bogen,
                         "bogentext_ueber_3_woerter": bogen_lang}
    if kopf:
        fehler = True
    if steil or bogen_lang:
        hinweis = True
    if bogen:
        befund["drehung"]["hinweis"] = "Winkel auf dem Pfad nicht messbar, im Prüfbogen auf kopfstehenden Bogentext sehen"
    # R16: Aufzählungen je Gruppe
    je_gruppe = {}
    for e in elemente:
        for zeile in e["zeilen"]:
            if zeile[:1] in AUFZAEHLUNG:
                je_gruppe[e["gruppe"] or "(ohne id)"] = je_gruppe.get(e["gruppe"] or "(ohne id)", 0) + 1
    befund["aufzaehlung_je_gruppe"] = je_gruppe
    if any(n > 3 for n in je_gruppe.values()):
        hinweis = True
    status = "FEHLER" if fehler else ("HINWEIS" if hinweis else "OK")
    return status, befund, marken


def schrift(groesse):
    for kandidat in ["DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                     "Arial.ttf", "/Library/Fonts/Arial.ttf", "C:/Windows/Fonts/arial.ttf",
                     "LiberationSans-Regular.ttf"]:
        try:
            return ImageFont.truetype(kandidat, groesse)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size=groesse)
    except TypeError:
        return ImageFont.load_default()


def pruefbogen(arr, p, ziel):
    img = Image.fromarray(arr)
    b, h = img.size
    vb, vh = p["vorschau"]
    if vh is None:
        vh = round(vb * h / b)
    vorschau = img.resize((vb, vh), Image.LANCZOS)
    kachel_b = 760
    kachel = lambda a: Image.fromarray(a).resize((kachel_b, round(kachel_b * h / b)), Image.LANCZOS)
    felder = [("Original", kachel(arr)), (f"Vorschau in Anzeigegroesse {vb} x {vh} px (1:1)", vorschau)]
    for name in list(CVD) + ["Graustufen"]:
        felder.append((name, kachel(simuliere(arr, name))))
    kopf, abstand = 40, 24
    zeile_h = max(f[1].size[1] for f in felder) + kopf
    spalten = 2
    zeilen = (len(felder) + 1) // spalten
    bogen = Image.new("RGB", (spalten * (kachel_b + abstand) + abstand, zeilen * (zeile_h + abstand) + abstand), "#e6e6e6")
    zeichnen = ImageDraw.Draw(bogen)
    for i, (titel, bild) in enumerate(felder):
        x = abstand + (i % spalten) * (kachel_b + abstand)
        y = abstand + (i // spalten) * (zeile_h + abstand)
        zeichnen.text((x, y + 8), titel, fill="#222222", font=schrift(22))
        bogen.paste(bild, (x, y + kopf))
        zeichnen.rectangle([x - 1, y + kopf - 1, x + bild.size[0], y + kopf + bild.size[1]], outline="#999999")
    bogen.save(ziel)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("png")
    ap.add_argument("--profil", required=True, choices=sorted(PROFILE))
    ap.add_argument("--svg")
    ap.add_argument("--out", default="pruefung")
    ap.add_argument("--tiff", action="store_true", help="zusätzlich TIFF mit Profil-dpi schreiben")
    ap.add_argument("--kuerzel-ok", default="", help="kommagetrennte Kürzel, die ohne Erklärung stehen dürfen (Begründung im Konzept)")
    ap.add_argument("--woerter-ok", default="", help="kommagetrennte Fachwörter, die die Rechtschreibprüfung nicht kennt")
    ap.add_argument("--sprache", default="en_US", help="Wörterbuch für die Rechtschreibprüfung, etwa en_US oder de_DE")
    ap.add_argument("--einheiten", type=int, default=0, help="Zahl der Bildeinheiten laut Konzept, Abgleich mit den Ordnungsmarken (R12)")
    a = ap.parse_args()

    p = PROFILE[a.profil]
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    img = Image.open(a.png).convert("RGB")
    arr = np.array(img)
    b, h = img.size

    bericht = {"datei": a.png, "profil": a.profil, "pruefungen": {}}
    s, t = pruefe_masse(b, h, p)
    bericht["pruefungen"]["masse"] = {"status": s, "befund": t}
    s, t = pruefe_rand(arr)
    bericht["pruefungen"]["rand_prozent"] = {"status": s, "befund": t, "grenze": RAND_MAX * 100}
    s, t = pruefe_farben(arr)
    bericht["pruefungen"]["farben"] = {"status": s, "befund": t, "delta_e_min": DELTA_E_MIN}
    if a.svg:
        s, t = pruefe_svg(a.svg, b, p)
        bericht["pruefungen"]["svg_text"] = {"status": s, "befund": t, "wort_max": WORT_MAX}
        ok = {k.strip() for k in a.kuerzel_ok.split(",") if k.strip()}
        wok = {k.strip() for k in a.woerter_ok.split(",") if k.strip()} | ok
        s3, t3, marken = pruefe_textgestalt(textelemente(a.svg), a.einheiten, a.sprache, wok)
        s2, t2 = pruefe_regeln(a.svg, t["texte"], ok, marken)
        bericht["pruefungen"]["svg_regeln"] = {"status": s2, "befund": t2}
        bericht["pruefungen"]["svg_textgestalt"] = {"status": s3, "befund": t3}

    pruefbogen(arr, p, out / "pruefbogen.png")
    bericht["pruefbogen"] = str(out / "pruefbogen.png")
    if a.tiff:
        tif = out / (Path(a.png).stem + ".tif")
        img.save(tif, dpi=(p["dpi"], p["dpi"]), compression="tiff_lzw")
        bericht["tiff"] = str(tif)

    (out / "bericht.json").write_text(json.dumps(bericht, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"Profil {a.profil}")
    for name, e in bericht["pruefungen"].items():
        befund = e["befund"]
        if name == "svg_text":
            befund = {k: v for k, v in befund.items() if k != "texte"}
        print(f"  {e['status']:8s} {name}: {json.dumps(befund, ensure_ascii=False)}")
    print(f"  Prüfbogen: {bericht['pruefbogen']}")
    fehler = any(e["status"] == "FEHLER" for e in bericht["pruefungen"].values())
    sys.exit(1 if fehler else 0)


if __name__ == "__main__":
    main()
