#!/usr/bin/env python3
"""Zwei oder mehr Skizzen oder Entwürfe nebeneinanderstellen.

Aufruf:
    python3 vergleich.py a.png b.png [c.png ...] --profil elsevier [--namen A,B,M] --out vergleich.png

Zeigt jede Datei in Arbeitsgröße untereinander und darunter alle in Anzeigegröße
des Profils 1:1 nebeneinander, beschriftet mit --namen oder sonst A, B, C ...
"""
import argparse
import sys
from pathlib import Path

from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ga_check import PROFILE, schrift  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("bilder", nargs="+")
    ap.add_argument("--profil", required=True, choices=sorted(PROFILE))
    ap.add_argument("--out", default="vergleich.png")
    ap.add_argument("--breite", type=int, default=1100, help="Arbeitsgröße in px")
    ap.add_argument("--namen", help="kommagetrennte Namen je Bild, etwa A,B,M")
    a = ap.parse_args()
    if len(a.bilder) < 2:
        sys.exit("FEHLER: mindestens zwei Bilder angeben.")

    bilder = [Image.open(b).convert("RGB") for b in a.bilder]
    vb, vh = PROFILE[a.profil]["vorschau"]
    marken = [chr(65 + i) for i in range(len(bilder))]
    if a.namen:
        marken = [n.strip() for n in a.namen.split(",")]
        if len(marken) != len(bilder):
            sys.exit(f"FEHLER: {len(bilder)} Bilder, aber {len(marken)} Namen.")
    kopf, abstand = 40, 24
    gross = [im.resize((a.breite, round(a.breite * im.size[1] / im.size[0])), Image.LANCZOS) for im in bilder]
    klein = [im.resize((vb, vh if vh else round(vb * im.size[1] / im.size[0])), Image.LANCZOS) for im in bilder]
    breite = max(a.breite, len(klein) * (vb + abstand) - abstand) + 2 * abstand
    hoehe = sum(g.size[1] + kopf + abstand for g in gross) + kopf + max(k.size[1] for k in klein) + 2 * abstand
    bogen = Image.new("RGB", (breite, hoehe), "#e6e6e6")
    z = ImageDraw.Draw(bogen)
    y = abstand
    for m, g, pfad in zip(marken, gross, a.bilder):
        titel = m if a.namen else f"{m}  {Path(pfad).name}"
        z.text((abstand, y + 6), titel, fill="#222222", font=schrift(24))
        bogen.paste(g, (abstand, y + kopf))
        y += kopf + g.size[1] + abstand
    z.text((abstand, y + 6), f"Anzeigegroesse {vb} px breit (1:1): " + ", ".join(marken) + " von links", fill="#222222", font=schrift(24))
    x = abstand
    for k in klein:
        bogen.paste(k, (x, y + kopf))
        z.rectangle([x - 1, y + kopf - 1, x + k.size[0], y + kopf + k.size[1]], outline="#999999")
        x += k.size[0] + abstand
    bogen.save(a.out)
    print(f"OK: {a.out} ({len(bilder)} Bilder, Vorschau {vb} px)")


if __name__ == "__main__":
    main()
