---
name: "science-graphical-abstract"
description: "Entwirft, zeichnet und prüft ein Graphical Abstract (auch Visual Abstract, TOC-Grafik, Key Figure) für einen wissenschaftlichen Artikel: Kernbotschaft, Layoutmuster, SVG in den Maßen der Zielzeitschrift, zwei Konzepte zur Wahl, Prüfbogen mit Thumbnail- und Farbfehlsichtigkeitstest, unabhängige Prüfung, Bewertungsraster. Immer verwenden bei: Graphical Abstract erstellen, Visual Abstract, TOC Graphic, Key Figure, grafische Zusammenfassung, Abstract als Bild, Graphical Abstract prüfen oder verbessern."
metadata:
  version: "2.0.0"
---

# Graphical Abstract erstellen

Ein Graphical Abstract ist eine eigens gestaltete Einzelgrafik, die im Kleinformat lesbar genau eine Kernbotschaft des Artikels transportiert, mit klarem Anfang und Ende. Es ist keine verkleinerte Artikelabbildung, keine Collage und kein Text-Abstract mit Bild. Der Skill führt vom Manuskript zu einer geprüften SVG- und PNG-Datei in den Maßen der Zielzeitschrift.

Der Leitsatz: Ein gutes Graphical Abstract entsteht durch Weglassen. Jedes Element, das nicht der Kernbotschaft dient, kostet Lesbarkeit im Vorschaubild.

## Grundregeln

- **Nur Artikelinhalt.** Jede Aussage, Zahl, Karte und jedes Ergebnis im Bild muss im Manuskript stehen. Nichts ergänzen, nichts zuspitzen, Spekulatives nur sichtbar als solches markiert. Fehlt eine Angabe (Ort, Alter, Maßstab), wird sie als OFFEN erfragt, nicht erfunden.
- **Vorlegen, dann bestätigen.** Zwei Konzepte (Schritt 5) werden vollständig vorgelegt, einschließlich aller Beschriftungen im Wortlaut, verglichen und mit einer Empfehlung versehen. Der Nutzer wählt eines oder eine Mischung. Gezeichnet wird erst nach dieser Wahl.
- **Jede Zahl, jedes Symbol, jede Abkürzung und jeder Farbcode mit Bezug im Bild.** Eine Zahl braucht Einheit oder Bezugswort ("17 von 20 Punkten", nicht "17 von 20"), ein Symbol eine Beschriftung oder eine eindeutige Fachkonvention, eine Abkürzung ihre Auflösung, eine bedeutungstragende Farbe oder Strichart einen Legendeneintrag. Was nur mit Wissen aus der Quelle verständlich ist, gilt als unverständlich.
- **Nicht mehr versprechen als die Quelle.** Ergebniswörter wie "einreichungsreif", "validiert", "bewiesen" oder "sicher" nur, wenn die Quelle sie ohne Einschränkung trägt. Eine Bewertung durch die KI selbst wird nie als Freigabe dargestellt. Was die Quelle als möglich oder vermutet bezeichnet, erscheint im Bild als Hypothese.
- **Pflichtschritte der Quelle bleiben sichtbar.** Was die Quelle als Grundregel, Freigabe oder Pflichtschritt führt, darf nur mit Begründung im Konzept wegfallen. Weglassen ist das Prinzip, aber nicht beim Kern der Aussage.
- **Rückfragen einzeln.** Immer nur eine Frage stellen, Antwort abwarten, dann die nächste.
- **KI-Regel der Zielzeitschrift zuerst.** Elsevier untersagt allgemeine generative KI-Bildwerkzeuge für Graphical Abstracts, einzelne Elsevier-Titel untersagen jede KI-gestützte Erstellung, ACS schließt KI-Bilder in TOC-Grafiken aus. Ein von Claude gezeichnetes SVG ist KI-gestützt erstellt. Bei diesen Zeitschriften ist das Ergebnis deshalb ein **Konzeptentwurf** (Layout, Inhalt, Maße), den die Autoren selbst in ihrem Grafikprogramm reinzeichnen. Das wird in der Ausgabe ausdrücklich gesagt. Wo KI-Unterstützung erlaubt ist (z. B. AGU), wird die Offenlegung im Methodenteil empfohlen.
- **Geprüft, nicht behauptet.** Nach jedem Schreib- oder Renderschritt läuft `scripts/ga_check.py`. Gemeldet werden Messwerte (Pixelmaße, kleinste Schrift, Wortzahl, Randanteil), keine Zusicherungen. Den Prüfbogen sieht Claude selbst an, bevor etwas als fertig gilt.
- **Nicht die eigene Arbeit allein benoten.** Wer gezeichnet hat, kennt das Konzept und liest es in das Bild hinein. Deshalb prüft vor der Bewertung eine unabhängige Instanz, die nur Bild und Quelle kennt (Schritt 8).
- **Keine Em-Dashes, keine doppelten Bindestriche** im Bildtext und in Begleittexten.
- **Sprache des Bildes** ist die Sprache des Artikels, meist Englisch. Arbeitskommunikation in der Sprache des Nutzers.

## Ablauf

### 1. Eingaben sichten

Manuskript, Abstract, Highlights oder Key Points und die Artikelabbildungen lesen. Fehlt das Manuskript, reicht ein ausführlicher Abstract; dann wird im Konzept vermerkt, dass die Grundlage schmal ist. Die Zielzeitschrift wird erfragt, falls nicht genannt.

### 2. Zielprofil festlegen

In `references/verlagsvorgaben.md` das Profil der Zielzeitschrift nachschlagen: Pflichtstatus, Maße in Pixeln, Anzeigegröße, kleinste zulässige Schrift in Pixeln, Begleittext, KI-Regel. Steht die Zeitschrift nicht in der Tabelle oder ist ihr Eintrag als ungeprüft markiert, wird der aktuelle Guide for Authors aufgerufen und die Angabe mit Link belegt. Verlangt die Zeitschrift kein Graphical Abstract (AGU, GSA, Frontiers), wird das gesagt und als Alternative eine Key Figure für Social Media oder eine Copernicus-Key-Figure angeboten.

### 3. Kernbotschaft bestimmen

Die Kernbotschaft in einem Satz formulieren, der auch ohne Bild stimmt. Dazu vier Bausteine aus dem Text ableiten, jeder mit Fundstelle im Manuskript: **Kontext** (Warum? Bei Geothemen Ort, Zeitraum, Skala), **Ansatz** (Wie? Methode oder Daten, höchstens zwei Symbole), **Hauptergebnis** (Was? Das visuell dominante Element), **Implikation** (Na und? optional). Lässt sich kein einzelner Satz finden, hat der Artikel mehrere Botschaften; dann den Nutzer fragen, welche das Bild tragen soll.

Danach Kernsatz und Bausteine **gegen die Quelle prüfen**, bevor Konzepte entstehen: Stimmt der Kernsatz ohne Einschränkung, die die Quelle macht? Welche Merkmale der Quelle braucht das Bild? Jedes Merkmal wird einer Stufe zugeordnet: **Stufe 1**, ohne es wäre die Kernaussage falsch oder irreführend; **Stufe 2**, ein Pflichtschritt, der den dargestellten Ablauf oder das Ergebnis ändert; **Stufe 3**, Randbedingung, Belegpflicht, Verfahrensregel oder Ausnahmefall. Stufe 1 und 2 gehören in beide Konzepte, Stufe 3 in den Prüfbericht. Anlass: In einem Variantenvergleich stammten alle gemeinsamen Mängel dreier Entwürfe aus einem ungeprüften Kernsatz, nicht aus dem Layout.

### 4. Zwei Konzeptrichtungen bestimmen

Zwei Konzepte festlegen, die sich entlang einer benannten Achse unterscheiden, nicht nur in Farbe oder Anordnung. Typische Achsen: **Ergebnis oder Prozess** (was herauskommt gegen wie es entsteht), **Befund oder Methode**, **Ist oder Soll**, **Überblick oder Detail**. Die Achse ergibt sich aus der Quelle: Welche zwei Lesarten der Kernbotschaft sind beide belegbar? Für jedes Konzept aus dem Musterkatalog in `references/gestaltung.md` das passende Layoutmuster wählen und die Wahl in einem Satz begründen. Der Katalog enthält auch Muster aus 25 veröffentlichten Beispielen (`references/beispiele.md`), gegliedert in Familien: radial (Review-Rad, Kernübergang als Zentrum, Objekt mit Kreislaufring), Spalten und Abläufe (nummerierte Spalten, Rückführband), Vergleich (Weggabelung, Triptychon, Symbolpaar), Daten ohne Zahlen (Vorher-Nachher desselben Datenbilds, Soll-Linie, Trichter, Schwellenskala) und Geo (gedrehte Karte als Band, Blockdiagramm mit Lupen, Makro-Mikro-Sequenz, Stadien mit Kraftpfeilen, Leithorizont). Die Tabelle "Musterwahl nach Artikeltyp" in `references/gestaltung.md` nennt je Artikeltyp eine erste Wahl für Konzept A und eine Gegenrichtung für Konzept B; von ihr ausgehen und begründet abweichen. Das Seitenverhältnis des Profils schränkt die Wahl ein: Querformat 5:2 verlangt Links-rechts-Muster, das Cell-Quadrat eher oben nach unten oder zentrales Motiv. Die Anordnung folgt dem Zielformat, nicht der Vorlage im Artikel (R19). Die Kernbotschaft aus Schritt 3 bleibt in beiden Konzepten dieselbe oder wird je Richtung nur im Schwerpunkt verschoben.

### 5. Zwei Konzepte vorlegen, vergleichen, empfehlen

Je Konzept vollständig vorlegen:

- Kernsatz und die vier Bausteine mit Fundstelle
- Muster und Zielmaße
- drei bis fünf Bildeinheiten, je mit Inhalt, Darstellungsform (Karte, Profil, Säule, Blockdiagramm, Diagramm, Symbol) und Position
- sämtliche Beschriftungen im Wortlaut, mit Wortzahl insgesamt
- Farbrollen: welche Farbe das Neue trägt, welche den Kontext
- bei Geothemen die Pflichtelemente (Maßstab, Nordpfeil, Überhöhung, Zeitachse mit Einheit und Richtung), soweit die Darstellung sie braucht
- welche Merkmale der Stufen 1 und 2 aus Schritt 3 es zeigt; lässt es eines weg, mit Begründung

Dazu je Konzept eine **Skizze**: ein SVG in Zielmaßen aus grauen Platzhalterformen mit den echten Beschriftungen in echter Größe, ohne Symboldetails. Beide Skizzen rendern und nebeneinanderstellen:

```
python3 scripts/render_svg.py skizze_a.svg skizze_a.png
python3 scripts/render_svg.py skizze_b.svg skizze_b.png
python3 scripts/vergleich.py skizze_a.png skizze_b.png --profil elsevier --namen A,B --out vergleich.png
```

`vergleich.png` zeigt beide Skizzen groß und in Anzeigegröße 1:1. Claude sieht es an und vergleicht die Konzepte an den Kriterien 1, 3, 4, 5 und 9 des Rasters, je Kriterium mit "A besser", "gleich" oder "B besser" und einem Satz Begründung. Relatives Urteilen ist hier gewollt: Die Stärke des einen Konzepts zeigt die Lücke des anderen. Am Ende steht eine Empfehlung, gegebenenfalls als Mischung (etwa Aufbau von A mit einem Element aus B), und der Hinweis zur KI-Regel der Zielzeitschrift. Dann wählt der Nutzer.

### 6. SVG zeichnen

Mit der passenden Vorlage aus `assets/` beginnen (`vorlage_quer_5x2.svg` oder `vorlage_quadrat.svg`) oder ein SVG mit exakt den Zielmaßen als `width`, `height` und `viewBox` anlegen. Regeln:

- Schrift `font-family="Arial, Helvetica, 'Liberation Sans', sans-serif"`, jede Textgröße als `font-size` in Pixeln, nie unter dem Mindestwert des Profils.
- Farben aus der Palette in `references/gestaltung.md`; eine Akzentfarbe für das Neue, Kontext in Grautönen. Keine Regenbogenskalen, Rot-Grün-Gegensätze nur mit Form- oder Beschriftungsredundanz.
- Pfeile als ein wiederverwendeter `marker`, gleiche Strichstärke überall.
- Symbole selbst als einfache Formen zeichnen, einheitliche Linienstärke. Keine Logos, Marken, Personenfotos, keine Fremdgrafiken ohne geklärte Lizenz.
- Kein Titel, keine Autoren, keine Zitate, keine Überschrift "Graphical Abstract".
- Ränder knapp halten, keine leeren Flächen.
- Die Regeln R1 bis R20 in `references/gestaltung.md` einhalten: Abkürzungen auflösen, Farbcodes in die Legende, Maßstabssprünge markieren, höchstens drei bis vier Lupen, höchstens fünf Zahlen, Hypothesen kennzeichnen, eine Leserichtung; keine Worttrennung und keine Tippfehler, Ordnungsmarken passend zu den Einheiten, Radiallayouts mit höchstens fünf Sektoren und einem Ring, kein Text auf dem Kopf oder senkrecht, keine Aufzählungslisten, Farbe nur mit Rolle, Diagramme nur qualitativ.
- Messbare Gruppen anlegen: die Legende als Gruppe mit `id="legende"` (Fläche, R7), Ordnungsmarken als Gruppe mit `id="marken"` (R12; zählen nicht als Zahlen).

### 7. Rendern und prüfen

```
python3 scripts/render_svg.py ga.svg ga.png
python3 scripts/ga_check.py ga.png --profil elsevier --svg ga.svg --out pruefung/ --einheiten 4 [--kuerzel-ok REE,GPS] [--woerter-ok geochemical] [--sprache en_US]
```

`render_svg.py` erzeugt ein PNG in den Maßen des SVG (cairosvg, rsvg-convert, Inkscape oder Chromium, je nachdem was vorhanden ist). `ga_check.py` misst Pixelmaße gegen das Profil, kleinste Schrift und Wortzahl im SVG, den Anteil leerer Ränder, Inhalt am Bildrand (Beschnitt), Farbpaare, die unter Farbfehlsichtigkeit verschmelzen, unerklärte Abkürzungen, die Zahl der Zahlen und den Flächenanteil der Legende, Worttrennung und unbekannte Wörter (Wörterbuch über `--sprache`, für deutschen Bildtext `de_DE`; Fachwörter in `--woerter-ok`), Ordnungsmarken gegen `--einheiten`, kopfstehenden, senkrechten und Bogentext sowie Aufzählungen, und schreibt einen Prüfbogen `pruefbogen.png` mit Original, Vorschau in Anzeigegröße, Deuteranopie-, Protanopie-, Tritanopie-Simulation und Graustufen. Claude liest den Prüfbogen mit dem Read-Werkzeug und prüft: Ist die Kernbotschaft in der Anzeigegröße in fünf Sekunden erkennbar? Bleiben die Farbunterscheidungen in allen Simulationen erhalten? Die Messung ist notwendig, aber nicht hinreichend: Farbtöne gleicher Helligkeit fallen im Prüfbogen oft zusammen, obwohl die Messung sie noch trennt. Deshalb Kategorien immer zusätzlich durch Strichart oder Beschriftung unterscheiden. Jeder Fehler führt zurück zu Schritt 6.

### 8. Unabhängig prüfen und bewerten

Zuerst die **unabhängige Prüfung** nach `references/unabhaengige-pruefung.md`: Eine separate Instanz (Subagent über das Agent-Werkzeug) erhält nur das gerenderte PNG, den Prüfbogen, das Quelldokument, den Namen des Zielprofils und den Prüfauftrag aus der Referenzdatei. Sie erhält nicht das Konzept, nicht die Begründungen, nicht die eigene Bewertung. Sie beantwortet fünf feste Fragen und vergibt danach Rasterpunkte. Steht kein Agent-Werkzeug zur Verfügung, führt Claude die Prüfung in einem eigenen Schritt nur anhand von PNG und Quelle durch und vermerkt im Prüfbericht "nicht unabhängig".

Dann die **Eigenbewertung** mit dem Raster in `references/bewertungsraster.md`, je Kriterium mit einem Satz Begründung. Je Kriterium zählt der niedrigere der beiden Werte. Jede Abweichung zwischen beiden wird im Prüfbericht benannt. Befunde der unabhängigen Prüfung zu F1 bis F3, zu F5 und zu F4 der Stufen 1 und 2 führen zurück zu Schritt 6, auch wenn die Punktzahl reicht. Befunde zu F4 der Stufe 3 gehen in den Prüfbericht und ändern das Bild nicht. Unter 17 von 20 Punkten wird überarbeitet, unter 12 zurück zu Schritt 3. Der Nutzer erhält vor der Abgabe einen fünf-Sekunden-Test als Aufgabe: das Vorschaubild einer fachfremden Person zeigen und fragen, was die Arbeit herausgefunden hat.

### 9. Ausgeben

Abgegeben werden:

- `ga.svg`, editierbare Quelle, und `ga.png` in Zielmaßen; auf Wunsch TIFF über `ga_check.py --tiff`
- Begleittext, falls die Zeitschrift einen verlangt (Längen im Profil), und ein Alt-Text von höchstens 250 Zeichen
- der Prüfbogen, das Vergleichsbild der Skizzen und ein kurzer Prüfbericht als Arbeitsdokument: gewähltes Konzept und Vergleichsurteil, Messwerte, Antworten der unabhängigen Prüfung, Rasterpunkte aus Eigen- und unabhängiger Bewertung mit Abweichungen, offene Punkte, bei betroffenen Zeitschriften der Hinweis auf Reinzeichnung durch die Autoren

Im Abgabebild selbst steht nichts über den Bearbeitungsstand.

## Referenzen

| Datei | Inhalt |
|---|---|
| `references/verlagsvorgaben.md` | Profile je Verlag und Geo-Zeitschrift, Pixel- und Schriftminima, KI-Regeln, Quellen |
| `references/gestaltung.md` | Inhalt, Musterkatalog mit Musterfamilien, Musterwahl nach Artikeltyp, Schrift, Palette, Geo-Pflichtelemente, Regeln R1 bis R20, typische Fehler |
| `references/bewertungsraster.md` | Checkliste vor dem Einreichen und Raster mit 20 Punkten |
| `references/unabhaengige-pruefung.md` | Prüfauftrag für die unabhängige Instanz, fünf Fragen, Rangstufen, Antwortformat |
| `references/beispiele.md` | 25 ausgewertete Beispiele aus fünf Zeitschriften 2026, Stichproben zur Verbreitung |
| `scripts/render_svg.py` | SVG nach PNG in Zielmaßen |
| `scripts/ga_check.py` | Messung (auch R1, R7, R8, R11, R12, R14, R16) und Prüfbogen |
| `scripts/vergleich.py` | Skizzen oder Entwürfe nebeneinander, groß und in Anzeigegröße |
| `assets/vorlage_quer_5x2.svg`, `assets/vorlage_quadrat.svg` | Rasterstartpunkte mit Platzhaltern |
