---
name: science-dokumentkritik-drei-sichten
description: Beurteilt ein fertiges Dokument aus drei Nutzungssichten, hält den Befund als eingefrorene Kritik fest und leitet daraus eine mitlaufende Arbeitsliste ab, je Sicht fünfzehn nummerierte Maßnahmen mit Quelle, Abhängigkeit und Stand. Ausgabe ist eine Markdown-Datei, die Kritik und Status in einem trägt und beides ausdrücklich trennt. Immer verwenden bei, kritisiere mein Dokument, was fehlt dem Bericht, Verbesserungsvorschläge, Arbeitsliste aus Kritik, wie gut ist das aus Sicht von, Gesamtbeurteilung.
metadata:
  version: "2.0.0"
---

# Dokumentkritik aus drei Sichten

Dritte Achse neben `science-faktenbeleg-pruefung` und `science-interne-konsistenz-pruefung`. Die beiden prüfen Richtigkeit, diese beurteilt Brauchbarkeit.

Sie fragt nicht, ob eine Aussage belegt ist oder ob das Dokument mit sich übereinstimmt, sondern ob es leistet, wozu es gemacht wurde, und für wen. Ein Dokument kann durchgehend belegt und widerspruchsfrei sein und trotzdem dem Leser, für den es geschrieben wurde, das Entscheidende schuldig bleiben.

Der Ertrag ist deshalb kein Prüfbericht, sondern eine Arbeitsliste, die über Wochen mitläuft.

## Grundregeln

- **Sprache**: Die Ausgabe steht in der Sprache des Nutzers, nicht des Dokuments. Anders als bei den Prüfskills ist das Ergebnis eine Arbeitsanweisung an den Autor.
- **Keine stille Änderung**: Die Beurteilung liefert Befunde und Maßnahmen. Geändert wird erst nach Freigabe, und jede Maßnahme einzeln.
- **Die Kritik wird eingefroren**: Sobald die Datei steht, bleibt der Kritikteil unverändert, auch wenn Mängel behoben werden. Nur die Statustabellen laufen mit. Ohne diese Trennung geht die Ausgangslage verloren, gegen die der Fortschritt gemessen wird, und das Dokument widerspricht sich nach wenigen Maßnahmen selbst.
- **Jede Sicht bekommt auch Lob**: Ein Abschnitt "Was trägt" steht vor jedem "Was fehlt". Eine Liste, die nur Mängel zählt, wird als Urteil über das Ganze gelesen und nicht als Arbeitsliste.
- **Zuerst zählen, dann urteilen**: Ein Mangel wird mit seiner Fundstelle belegt. "Die Quellenarbeit ist dünn" ist kein Befund, "204 Einträge, davon fünf als einzige gefundene Quelle gekennzeichnet" ist einer.
- **Trennen, was der Autor liefern muss**: Jede Maßnahme sagt, ob sie aus dem vorhandenen Material ausführbar ist oder Angaben braucht, die nur der Autor hat. Ohne diese Spalte scheitert die Abarbeitung an der ersten Maßnahme, die eine Erinnerung verlangt.

## Die drei Sichten

Die Sichten sind die Nutzungsarten des Dokuments, nicht seine Kapitel. Sie werden vor der Beurteilung benannt und begründet, und sie hängen vom Dokumenttyp ab:

| Dokumenttyp | Sicht A | Sicht B | Sicht C |
|---|---|---|---|
| Exkursions- oder Feldbericht | praktisch, wer die Route nachvollzieht | fachlich, wer dasselbe sammelt oder misst | wissenschaftlich, wer die Aussagen prüft |
| Technische Dokumentation | Anwender | Betreiber | Prüfer oder Auditor |
| Compliance-Dokument | Fachbereich | Datenschutz oder ISMS | Aufsicht |
| Konzept oder Strategie | Umsetzende | Entscheider | Externe Begutachtung |

Drei Sichten sind das Maß, nicht zwei und nicht fünf. Zwei erzwingen eine falsche Gegenüberstellung, fünf erzeugen Überschneidungen, in denen dieselbe Maßnahme dreimal auftaucht.

Ist der Dokumenttyp nicht in der Tabelle, werden die drei Sichten aus der Frage abgeleitet, wer das Dokument in die Hand nimmt und was er damit tun will. Die Wahl wird im Kopf der Datei begründet.

## Aufbau der Ausgabedatei

Eine einzige Datei, `<Dokument>_Kritik_und_Verbesserungen_<JJJJMMTT>.md`, in dieser Reihenfolge:

1. **Kopf**: geprüftes Dokument, Datum, Annahme über den Bearbeitungsstand.
2. **Lesehinweis**: Die Kritik ist der Befund des Erstellungstags und bleibt unverändert; die Statustabellen tragen den laufenden Stand; bei Widerspruch gilt die Tabelle. Dieser Absatz ist nicht optional.
3. **Urteil in einem Satz**: Stärke, Schwäche und die eine entscheidende Lücke.
4. **Je Sicht**: Was trägt, Was fehlt, Statustabelle, Maßnahmen im Wortlaut.
5. **Was als Nächstes ansteht**: welche Maßnahmen ohne weitere Angaben ausführbar sind und welche einzelne den Stau auflöst.
6. **Zurückgestellte Punkte**: je ein eigener Abschnitt mit dem Stand des Nachdenkens, damit eine spätere Erörterung nicht bei null beginnt.
7. **Stand der Abarbeitung**: Blocktabelle mit erledigt, offen, davon nur mit Angaben des Autors.
8. **Wirkungstabelle**: die sechs Maßnahmen mit der größten Wirkung, mit Rang, Grund und Stand.

## Statustabelle je Sicht

Steht vor den Maßnahmen im Wortlaut, nicht dahinter. Wer die Datei zum Arbeiten öffnet, will die Tabelle sehen; wer sie zum Verstehen öffnet, liest weiter.

| Spalte | Inhalt |
|---|---|
| Nr | A.1 bis A.15, B.1 bis B.15, C.1 bis C.15 |
| Maßnahme | ein Satz im Imperativ, mit dem Ort im Dokument |
| Quelle | woher der Inhalt kommt: ein Abschnitt, eine Datei, ein Skill, oder AUTOR |
| Hängt ab von | die Maßnahme, die zuerst fertig sein muss, sonst ein Strich |
| Stand | offen, ERLEDIGT mit Datum, TEILWEISE, ZURÜCKGESTELLT, GESTRICHEN |

Fünfzehn Maßnahmen je Sicht ist das Maß. Weniger heißt, dass die Sicht nicht durchdrungen wurde; mehr heißt, dass Maßnahmen zerlegt wurden, die zusammengehören.

## Formulierung der Maßnahmen

Jede Maßnahme sagt, was zu tun ist, wo es hingehört und woher der Inhalt kommt. Sie ist so geschrieben, dass sie ohne Rückfrage ausführbar ist oder ausdrücklich sagt, welche Angabe fehlt.

Gut: "In 1.3 hinter Tabelle 1 eine Tabelle Daily stages einfügen, acht Zeilen, Spalten Tag, Start, Ziel, Lokalitäten, Kilometer, Fahrzeit. Quelle ist die Routendatei."

Schlecht: "Die Etappen sollten besser dokumentiert werden."

Der Unterschied ist nicht Höflichkeit, sondern Ausführbarkeit. Eine Maßnahme ohne Ort und ohne Quelle wird beim nächsten Öffnen der Datei neu durchdacht statt abgearbeitet.

## Zustände und ihre Bedeutung

- **offen**: noch nicht bearbeitet.
- **ERLEDIGT mit Datum**: ausgeführt, mit einem Halbsatz, was getan wurde. Nicht nur "erledigt", sonst ist in zwei Wochen unklar, was.
- **TEILWEISE**: ausgeführt, soweit möglich, mit der Angabe, was fehlt und warum.
- **ZURÜCKGESTELLT**: bewusst vertagt, nicht liegengeblieben. Verlangt einen eigenen Abschnitt mit dem Stand des Nachdenkens, damit eine spätere Erörterung nicht bei null beginnt. Wo der Punkt wichtig bleibt, wird das ausdrücklich vermerkt, sonst liest sich Zurückstellung wie Abwertung. **Dieser Abschnitt wird entfernt, sobald der Punkt erledigt ist**; sonst beschreibt er einen Zustand, den die Statustabelle desselben Dokuments widerlegt.
- **GESTRICHEN**: vom Autor verworfen, mit Begründung. Wird nicht gelöscht, sonst taucht der Punkt beim nächsten Durchgang wieder auf.
- **NICHT RELEVANT**: trifft auf dieses Dokument nicht zu. Anders als GESTRICHEN kein Urteil über die Maßnahme, sondern über ihre Anwendbarkeit.
- **GESCHLOSSEN**: entfällt, weil eine Voraussetzung weggefallen ist oder die Sache anderswo bearbeitet wird. Der Eintrag nennt, wodurch.

Die drei letzten sehen gleich aus und sind es nicht. Wer sie zusammenwirft, kann später nicht mehr sagen, ob ein Punkt verworfen, unanwendbar oder bloß hinfällig war, und die drei führen zu verschiedenen Folgen, wenn sich die Lage ändert.

## Häufige Fehler

- **Die Kritik fortschreiben.** Der häufigste und der schädlichste. Nach wenigen Maßnahmen beschreibt die Prosa einen Zustand, den die Tabelle als erledigt führt, und das Dokument widerspricht sich selbst. Der Lesehinweis aus Punkt 2 verhindert das; er wird beim Erstellen gesetzt und nicht später.
- **Maßnahmen ohne Abhängigkeitsspalte.** Hängen sieben Maßnahmen an einer einzigen, ist das die wichtigste Information der ganzen Liste, und ohne Spalte sieht man sie nicht.
- **Die eine Lücke nicht benennen.** Fast jedes Dokument hat eine Lücke, die mehrere Sichten zugleich betrifft. Sie gehört ins Urteil in einem Satz und an Rang 1 der Wirkungstabelle.
- **Lob weglassen.** Ohne "Was trägt" liest der Autor die Liste als Verriss und arbeitet sie nicht ab.
- **Sichten nach Kapiteln bilden.** Dann entsteht eine Gliederungskritik und keine Nutzungskritik.
- **Abgeleitete Zahlen nicht nachzählen.** Wo eine Maßnahme eine Liste erzeugt und das Ergebnis deren Umfang nennt, steht dieselbe Zahl an mehreren Stellen. Ändert sich die Liste, sind alle nachzuzählen, und zwar durch Auszählen der Quelle, nicht aus dem Gedächtnis. Diese Zahlen gehören mit ihren Fundstellen in das Register des Projekts.
- **Vorarbeiten stehenlassen.** Zurückgestellte Punkte, ausgearbeitete Muster und Zwischenerhebungen gehören entfernt, sobald der Punkt erledigt ist. Sie sind der häufigste Grund dafür, dass ein Dokument seiner eigenen Statustabelle widerspricht.

## Verhältnis zu den anderen Skills

Diese Beurteilung setzt voraus, dass Richtigkeit geklärt ist, und ersetzt sie nicht. Sinnvolle Reihenfolge: erst `science-faktenbeleg-pruefung` und `science-interne-konsistenz-pruefung`, dann diese Beurteilung, dann die Abarbeitung nach Arbeitsplan.

Befunde, die in die anderen Achsen gehören, werden hier nicht behandelt, sondern benannt und weitergegeben. Umgekehrt erzeugt die Abarbeitung der Maßnahmen neue Inkonsistenzen, weshalb nach einer Reihe von Maßnahmen ein Konsistenzlauf folgt.
