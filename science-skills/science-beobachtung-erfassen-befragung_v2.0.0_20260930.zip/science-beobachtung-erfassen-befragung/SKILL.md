---
name: science-beobachtung-erfassen-befragung
description: Holt eigene Beobachtungen und Erfahrungswissen durch einzeln gestellte, an konkrete Dokumentstellen gebundene Fragen aus einer Person heraus und trägt die Antworten mit sauber getrennten Beleggraden ein, also Beobachtung, Schätzung, Deutung und Fremdaussage je eigens gekennzeichnet. Immer verwenden bei, Beobachtungen erfassen, Feldnotizen ausarbeiten, was habe ich gesehen, Erfahrungswissen dokumentieren, Diktat einarbeiten, frag mich dazu, Beobachtung und Deutung trennen.
metadata:
  version: "2.0.0"
---

# Beobachtung erfassen durch Befragung

Verfahren für den Fall, dass die entscheidende Information nirgends nachschlagbar ist, weil sie nur eine Person hat. Nicht Recherche, sondern Extraktion.

Es besteht aus zwei Teilen, die zusammengehören. Die Befragung holt heraus, was da ist. Die Beleggradführung sorgt dafür, dass beim Aufschreiben nicht mehr behauptet wird, als die Person tatsächlich gesagt hat.

## Grundregeln

- **Sprache**: Der Eintrag steht in der Sprache des Zieldokuments, die Fragen in der Sprache des Nutzers. Das ist der einzige Skill der Familie, bei dem beide Sprachen nebeneinander vorkommen dürfen, weil Fragen an den Menschen gehen und Einträge ins Dokument.

  | Feld | Deutsch | Englisch |
  |---|---|---|
  | Beleggrade | beobachtet, geschätzt, gedeutet, fremd berichtet, Fehlanzeige | observed, estimated, inferred, reported by others, absent |
  | Rahmenangaben | Datum, Uhrzeit, Wetter, Licht | date, time of day, weather, lighting |

- **Eine Frage je Nachricht**: Fragen werden einzeln gestellt, nie als Liste. Eine Liste wird überflogen, eine Einzelfrage beantwortet.
- **Jede Frage nennt ihren Zweck**: Was sie unterscheiden will, an welche Stelle des Dokuments die Antwort geht, und welchen häufigen Fehlschluss sie ausschließt. Eine Frage ohne diese Begründung ist eine Verlegenheitsfrage.
- **Nichts einfügen, was nicht gesagt wurde**: Eine naheliegende Deutung wird angeboten, nicht eingetragen. Die Entscheidung liegt bei der Person.
- **Die Sicherheit der Formulierung folgt der Sicherheit der Person**: Sagt sie "sieht aus wie", steht im Text "which looks like", keine feste Bestimmung.
- **Lücken bleiben Lücken**: Erkennbare Selbstkorrekturen im Diktat werden bereinigt, aber keine fehlende Angabe stillschweigend ergänzt.
- **Der Rahmen kommt vor dem Inhalt**: Bevor die Person zur Sache kommt, werden Datum, Uhrzeit und Bedingungen erfragt. Sie erklären später, warum manches sichtbar war und manches nicht.
- **Eine abgelehnte Frage wird ohne Nachfrage akzeptiert.** Kein Nachhaken, keine Bitte um Begründung.

## Phase 1: Rahmen erfragen

Vor dem inhaltlichen Diktat vier Angaben, in einer Nachricht, weil sie zusammengehören und keine Denkarbeit verlangen:

Datum, Uhrzeit oder Tageszeit, äußere Bedingungen, Wahrnehmungsbedingungen.

Was davon relevant ist, hängt vom Gegenstand ab, und die Auswahl wird begründet. Entfällt eine Angabe sachlich, wird das gesagt, statt sie mechanisch abzufragen.

Der Rahmen ist keine Formalie. Er entscheidet später darüber, ob eine Fehlanzeige ein Befund oder ein Wahrnehmungsproblem war.

## Phase 2: Diktat aufnehmen und einarbeiten

Die Person schildert frei. Beim Einarbeiten:

1. **Reihenfolge der Schilderung beibehalten.** Sie bildet oft den tatsächlichen Ablauf ab.
2. **Erkennbare Selbstkorrekturen bereinigen**, ohne den Sinn zu verändern.
3. **Vermutete Verhörungen korrigiert eintragen, aber melden** und zur Rückänderung stellen.
4. **Jeden Beleggrad sprachlich kennzeichnen** (siehe Anhang A).
5. **Was fachlich nicht trägt, zurückmelden**, statt es einzutragen. Widerspricht eine Beschreibung einer bekannten Eigenschaft des benannten Gegenstands, ist das eine Rückmeldung wert, samt Prüfvorschlag.
6. **Unsichere Bestimmungen markieren, bevor die Fragerunde beginnt**, mit fachlicher Begründung, warum sie unsicher sind.

Nach der Einarbeitung wird genannt, welche Aussagen bewusst allgemein gehalten wurden und warum.

## Phase 3: Fünf Fragen, einzeln

Fünf ist die erprobte Zahl: genug für Substanz, wenig genug, um nicht abzuschrecken.

Jede Frage wird nach diesem Muster gebaut:

> **Was sie unterscheiden will.** Die Alternative A gegen B.
> **Warum das zählt.** Welche Aussage des Dokuments dadurch belastbar wird oder welcher häufige Fehlschluss ausgeschlossen wird.
> **Die Frage selbst.**

Vier Zusatzregeln:

- **Negative Antworten vorab aufwerten**: Ist auch ein "nein" informativ, wird das gesagt. Sonst neigen Menschen dazu, etwas zu konstruieren.
- **Nach Kritik ausdrücklich fragen**: Ist ein Abschnitt durchweg positiv, wird eigens gefragt, ob etwas enttäuscht hat, mit der Begründung der Glaubwürdigkeit. Fällt die Antwort erneut positiv aus, wird auch das festgehalten.
- **Nach dem konkreten Anlass fragen**: Steht eine verallgemeinernde Aussage im Raum, wird der Einzelfall erfragt, der sie ausgelöst hat. Erst dadurch wird sie überprüfbar statt behauptet.
- **Nicht neu recherchieren, was schon im Dokument steht.** Eine Fachfrage der Person wird aus dem bereits geprüften Text beantwortet.

## Phase 4: Antworten einordnen, nicht nur eintragen

Jede Antwort wird auf vier Dinge geprüft, bevor sie in den Text geht:

1. **Konsequenz für andere Aussagen.** Macht sie eine frühere Formulierung im selben Abschnitt unrichtig? Stützt oder widerlegt sie eine Deutung an anderer Stelle?
2. **Querverbindung.** Berührt sie dieselbe Frage wie eine andere Einheit im Dokument? Dann wird der Bezug hergestellt.
3. **Muster.** Tritt dieselbe Beobachtung zum wiederholten Mal auf? Ab der dritten Wiederholung ist das eine eigene Aussage wert.
4. **Statusänderung.** Hebt sie eine bisher fremd berichtete Angabe zur eigenen Erfahrung? Dann wird die Kennzeichnung angepasst.

Eine Fehlanzeige wird eingeordnet, nicht nur notiert: Warum war nichts zu sehen, und ist das erwartbar oder auffällig? Die praktische Konsequenz gehört dazu.

## Typische Fehler

- Alle fünf Fragen auf einmal stellen.
- Eine Frage stellen, ohne zu sagen, was sie unterscheiden soll.
- Eine naheliegende Deutung ungefragt in den Text schreiben.
- Eine Schätzung als Messwert formulieren.
- Eine Angabe übernehmen, die die Person nicht selbst erhoben hat, ohne die Quelle zu nennen.
- Eine unentscheidbare Frage entscheiden, statt die Unentscheidbarkeit zu notieren.
- Nach einer abgelehnten Frage nachhaken.
- Eine Antwort eintragen, ohne zu prüfen, ob sie eine frühere Aussage unrichtig macht.
- Eine Fehlanzeige notieren, ohne sie einzuordnen.
- Den Rahmen erst nach dem Diktat erfragen. Dann fehlt er für die Deutung.
- Eine fachlich nicht tragfähige Deutung der Person übernehmen, statt sie zurückzumelden.
- Eine Bestimmung genauer eintragen, als die Umstände hergeben.

---

## Anhang A: Die fünf Beleggrade

| Grad | Woran erkennbar | Sprachliche Kennzeichnung |
|---|---|---|
| **beobachtet** | Die Person hat es gesehen | direkte Aussage, keine Einschränkung nötig |
| **geschätzt** | Zahl ohne Messung | "roughly", "on my own reckoning", mit Angabe der erschwerenden Umstände |
| **gedeutet** | Schluss aus dem Gesehenen | getrennter Satz, der die Ableitung kenntlich macht |
| **fremd berichtet** | Guide, Betreiber, andere Anwesende | Urheber nennen, dazu was die Person selbst gesehen hat |
| **Fehlanzeige** | nichts zu sehen | ausdrücklich als Befund formuliert, mit Einordnung |

Zwei Zusatzregeln:

**Die Einschränkung trägt die Überschrift, nicht jeder Satz.** Ist ein Abschnitt als Beobachtungsteil überschrieben, brauchen die einzelnen Geländemaße keinen Zusatz. Nur dort, wo eine Angabe im Nachhinein revidiert oder aus zweiter Hand übernommen wurde, wird eigens gekennzeichnet.

**Nach einer Revision bleibt die Spur erkennbar.** "So on reflection it is more likely to be X" ist ehrlicher als eine glatte Behauptung und für Nachnutzer informativer.

## Anhang B: Beleggrad und Ort im Dokument

Eine Aussage ist nicht absolut belegt oder unbelegt. Sie ist belegt genug für die Stelle, an der sie steht. Der Übergang zwischen Beobachtungs- und Diskussionsteil ist die Stelle, an der eine unbelegte Angabe unbemerkt Gewicht gewinnt.

| Ort | Zulässig | Pflicht |
|---|---|---|
| Beobachtungsteil | Erinnerung, Schätzung, Eindruck | sprachliche Kennzeichnung |
| Ergebnisteil, Tabellen | Schätzung nur, wenn kein publizierter Wert existiert | Kennzeichnung, publizierter Wert hat Vorrang |
| Diskussion, Synthese | nur mit externer Quelle oder als Zitat aus dem Beobachtungsteil | Beleg oder Binnenverweis |
| Abstract, Einleitung | nichts, was nicht weiter hinten belegt ist | Rückbindung |

Daraus folgen zwei Prüfschritte beim Übertragen einer Aussage von einem Kapitel ins andere: Hat sie die Kapitelgrenze überschritten, ohne eine Quelle zu erwerben? Und ist die sprachliche Kennzeichnung dabei verlorengegangen?

## Anhang C: Fragemuster nach Gegenstand

Die konkreten Fragen hängen vom Fach ab, ihre Bauart nicht. Vier wiederkehrende Typen:

| Typ | Was er leistet | Beispielform |
|---|---|---|
| **Alternativfrage** | schließt einen Fehlschluss aus | War es A oder B? A spräche für X, B für Y. |
| **Größenfrage** | macht eine Aussage überprüfbar | Wie groß etwa, und woran gemessen? |
| **Bedingungsfrage** | trennt Befund von Wahrnehmungsproblem | War es sichtbar, oder waren die Bedingungen ungünstig? |
| **Kritikfrage** | sichert Glaubwürdigkeit | Gab es etwas, das enttäuscht hat? |

## Anhang D: Nach der Fragerunde

Vor dem Abschluss einer Einheit wird geprüft:

- Sind alle Fragen beantwortet oder ausdrücklich abgelehnt? Übersehene werden nachgeholt.
- Hat eine Antwort eine bestehende Deutung an anderer Stelle umgekehrt? Dann wird sie dort angeglichen.
- Ist eine verallgemeinerte Lektion an die neue Beobachtung anzupassen?
- Sind abhängige Artefakte betroffen (Übersichten, Grafiken, Listen)? Dann in einem Zug nachziehen.
- Ist bei angekündigtem Fremdmaterial die Herkunft geklärt? Rechte und Quelle gehören in die Beschriftung, bevor es eingebunden wird.

Bei dokumentweiten Abhängigkeiten arbeitet dieser Skill mit `science-aenderungsfortpflanzung` zusammen.
