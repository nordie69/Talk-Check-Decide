---
name: "template-skill-projekt"
description: "Legt Skill-Projekte nach festem Schema an oder ergänzt sie: Dateisatz aus Paket, Organisation, Log, Konsistenzbericht, Workplan und Chatprotokoll, Namens-, Versions- und Kennungsregeln, Pflegeregeln und Prüfung nach jedem Schreibvorgang. Immer verwenden bei: Skill-Projekt anlegen, Skill übernehmen oder umbenennen, Organisation oder Log zu einem Skill anlegen, Skill-Projekt ergänzen, Projektdateien eines Skills prüfen oder nachziehen, Betriebsdateien eines Skills sichten, Chatprotokoll anlegen oder fortschreiben. Auch triggern, wenn ein Skill weiterentwickelt wird und seine Arbeitsdokumente fehlen oder veraltet sind."
metadata:
  version: "2.0.0"
---

# Skill-Projekt anlegen und ergänzen

## 1. Geltungsbereich

Der Skill gilt für Vorhaben, die aus einem Skill, seinen Arbeitsdokumenten und gegebenenfalls seinen Betriebsdateien bestehen. Es deckt zwei Fälle ab.

**Anlegen:** Ein neuer Skill entsteht, oder ein bestehender wird übernommen, umbenannt oder grundlegend geändert, und es gibt noch keine Projektdateien. Einstieg bei Abschnitt 6.

**Ergänzen:** Ein Projekt besteht bereits, und neue Anforderungen, Befunde oder Dateien kommen hinzu, oder dem Projekt fehlen Dateien, Namensregeln oder Pflegeregeln. Einstieg bei Abschnitt 7, danach an der Stelle des Ablaufs weiter, zu der die Ergänzung gehört.

Zuerst wird der Fall bestimmt. Liegt im Ausgabeordner oder in den Uploads eine Organisation zum Skill, ist es Ergänzen, sonst Anlegen. Rückfragen werden einzeln gestellt und nur, wenn die Antwort den Zuschnitt ändert.

Zusammenspiel: Konsistenzberichte erstellt `science-interne-konsistenz-pruefung`, Workplans `science-arbeitsplan-erstellen` ab Version 2.0.0, Validator und Paketbau stammen aus `skill-creator`. Die Vorlagen für Organisation, Log, Workplan und Konsistenzbericht stehen in `references/vorlagen.md` und werden vor dem Anlegen der jeweiligen Datei gelesen.

Platzhalter stehen in spitzen Klammern. `<projekt>` ist der Skillname mit Familienpräfix, etwa `sammlung-strunz-map`. `<H>` ist die Hauptversion. `<JJJJMMTT>` ist das Datum der Datei.

## 2. Dateisatz

| Datei | Name | Art | Zweck | Pflicht ab |
|---|---|---|---|---|
| Paket | `<projekt>_v<H>_<JJJJMMTT>.skill` | Abgabe | Installierbarer Skill | Anlage |
| Organisation | `<projekt>_Organisation_v<H>_<JJJJMMTT>.md` | Arbeitsdokument, fortlaufend | Ist, Soll, Maßnahmen, Entscheidungen, beteiligte Dateien | Anlage |
| Log | `<projekt>_Log_v<H>_<JJJJMMTT>.md` | Arbeitsdokument, fortlaufend | Protokoll der wichtigsten Aktionen | Anlage, erster Eintrag ist die Anlage selbst |
| Konsistenzbericht | `<projekt>_Konsistenzbericht_v<H>_<JJJJMMTT>.md` | Arbeitsdokument, eingefroren | Befunde eines Prüflaufs; wird nach Abgabe nicht nachgeführt | erster Prüflauf |
| Workplan | `<projekt>_Workplan_v<H>_<JJJJMMTT>.md` | Arbeitsdokument, fortlaufend, genau einer je Projekt | Steuert die Ausführung aller offenen Punkte aller Vorhaben | erster Befund oder erste offene Maßnahme |
| Betriebsdateien | Name, den der Skill erwartet | extern | Daten, die der Skill liest und schreibt | sobald vorhanden |
| Chatprotokoll | `<projekt>_Chatprotokoll_v<H>_<JJJJMMTT>.md` | Arbeitsdokument, fortlaufend, nur angehängt | jede Eingabe des Auftraggebers im Arbeitschat, mit Ergebnis und Nachweis | erste Arbeitssitzung |

Abgabedateien sind das Paket und alles darin. Sie beschreiben nur den Ist-Zustand. Entstehungsvermerke, Statusangaben und Hinweise auf frühere Fassungen gehören ausschließlich in die Arbeitsdokumente.

Arbeitsdokumente liegen nie im Paket.

Übergeben wird nur das vollständige Paket, nie eine einzelne `SKILL.md` daneben. Wird die einzelne Datei installiert, fehlen dem Skill seine Regel- und Referenzdateien. Auch das Speichern über eine Vorschlagskarte übernimmt nur die `SKILL.md` und verliert alles andere, auch `metadata.version`. Ein Skill mit Regeldateien oder Versionsangabe wird deshalb immer als Paket übergeben.

Der Arbeitschat ist der Ort der Arbeit, aber kein Nachweis: Er wird lang, wird beim Überlaufen zusammengefasst und lässt sich nicht zitieren. Alles, was zählt, verlässt deshalb den Chat und liegt in einer Projektdatei: Ergebnisse, Prüfberichte, Entscheidungen, Zahlen. Ein Wert, der nur im Chat genannt wurde, gilt als nicht belegt.

Log und Chatprotokoll teilen sich die Arbeit ohne Doppelung. Das Log führt, was an den Dateien getan wurde, mit Messwert. Das Chatprotokoll führt, was der Auftraggeber gesagt hat, im Wortlaut, sagt in einem kurzen Satz ohne Messwerte, was daraus wurde, und verweist für alles Weitere auf die Log-Einträge. Das Log nennt die C-Kennung als Anlass, nicht den Wortlaut.

## 3. Namensregeln

1. Schema `<projekt>_<Art>_v<H>_<JJJJMMTT>.<Endung>`. Das Paket trägt keine Art.
2. Zwischen den Namensteilen steht `_`. Innerhalb von `<projekt>` bleiben die Bindestriche des Skillnamens. Leerzeichen gibt es nicht.
3. Das Datum steht in umgekehrter Form. Versionsträger ist die Hauptversion, sofern die Organisation in der Kopfzeile "Versionsträger im Dateinamen" nichts anderes festlegt.
4. Prüft ein Konsistenzbericht einen anderen Umfang als den ganzen Dateisatz, steht der Umfang als Zusatz nach der Art, etwa `_Konsistenzbericht_SKILL`. Entsteht am selben Tag eine zweite Datei mit gleichem Namen, erhält sie den Zusatz `_HHMM` nach dem Datum. Vorhandene Dateien werden dafür nicht umbenannt.
5. Betriebsdateien behalten den Namen, den der Skill erwartet. Ein Projektschema auf sie anzuwenden bricht den Skill.
6. Dateien im Paket tragen keine Version im Namen, weil `metadata` sie versioniert. Der Ordner im Paket heißt wie der Skill, ohne Version und Datum.
7. Beim Umbenennen werden alle Verweise in allen Arbeitsdokumenten nachgezogen, die alten Dateien aus dem Ausgabeordner entfernt, und die Umbenennung wird geloggt. Danach muss die Suche nach jedem alten Namen 0 Treffer ergeben. Ein durch Umbenennen frei gewordener Name gilt bis zum Ende des Tages als belegt und wird nicht neu vergeben; eine Datei, die ihn nach Regel 3.4 erhalten würde, bekommt den Zusatz `_HHMM`.
8. Das Familienpräfix des Skills folgt der Familie, etwa `geo-`, `science-` oder `sammlung-`. Soll eine neue Familie entstehen, wird zuerst das Präfix gewählt, dann der Rest des Namens. Das Präfix wird in der Organisation als Entscheidung festgehalten.

## 4. Versionen

Die maßgebliche Versionsangabe ist `metadata.version` in der `SKILL.md`. Sie steht unter `metadata`, weil der Validator `version` und `language` auf oberster Ebene ablehnt.

Bei jeder Versionsänderung werden alle Fundstellen gezählt und nachgezogen:

| Fundstelle | Form |
|---|---|
| `SKILL.md`, `metadata.version` | volle Version, etwa `5.0.0` |
| Organisation, Kopfzeile Skill-Version | volle Version |
| Workplan, Kopfzeile Gegenstand | volle Version |
| Dateinamen außerhalb des Pakets | nach der Festlegung "Versionsträger im Dateinamen" |
| Betriebsdateien, Felder für den aktuellen Stand | Form, die der Skill vorschreibt |

In Betriebsdateien sind Felder, die eine Version als Geltungsbeginn einer Regel tragen, von Feldern zu unterscheiden, die den aktuellen Stand tragen. Nur die zweiten werden gezogen.

Weichen die Fundstellen nach dem Sprung voneinander ab, kommt die Angleichung als Schritt in den Workplan.

Konsistenzberichte halten den geprüften Stand fest und werden bei einer Versionsänderung nicht angepasst.

## 5. Kennungen

Jedes Präfix hat genau eine Bedeutung, über alle Projektdateien hinweg. Jede Kennung wird vor der Vergabe gegen dieses Register und gegen die vorhandenen Projektdateien geprüft. Nummern werden mindestens zweistellig geführt; ab 100 ist die Kennung dreistellig.

| Kennung | Datei | Bedeutung | Nummerierung |
|---|---|---|---|
| I-nn | Organisation | Fähigkeit, Ist | fortlaufend |
| S-nn | Organisation | Kandidat, Soll | fortlaufend |
| M-nn | Organisation | Maßnahme | fortlaufend |
| E-nn | Organisation | Entscheidung des Auftraggebers | fortlaufend, abgelöste bleiben mit Verweis stehen |
| DAT-nn | Organisation | Datei außerhalb des Pakets | fortlaufend, abgelöste bleiben mit Verweis stehen |
| L-nn | Log | Eintrag | fortlaufend |
| C-nn | Chatprotokoll | Eingabe des Auftraggebers | fortlaufend über alle Sitzungen und Chats des Projekts |
| WV-nn | Chat, Log, Workplan | Wortlautvorlage | fortlaufend über das Projekt |
| K-nn, N-nn, O-nn | Konsistenzbericht | Befund, Nicht-Befund, offener Punkt | fortlaufend über alle Prüfläufe; ein neuer Lauf setzt die Nummern fort |
| V-nn | Workplan | korrigierte Vorüberlegung | fortlaufend über das Projekt |
| SB-nn | Workplan | Befund aus einer Sichtung oder Querprüfung | fortlaufend über das Projekt |
| EP-nn, EP-nn Z | Workplan | Entscheidungspunkt, Sach- oder Zweckentscheidung | fortlaufend über das Projekt |
| AK-nn | Workplan | Abnahmekriterium | fortlaufend über das Projekt |
| Block 1, Schritt 1.1 | Workplan | Block und Schritt | Blöcke fortlaufend über das Projekt, Schritte je Block |

Die Dimensionen D1 bis D6 sind feste Bezeichnungen aus `science-interne-konsistenz-pruefung` und keine Projektkennungen. Deshalb heißen Entscheidungspunkte in Skill-Projekten EP statt D wie in `science-arbeitsplan-erstellen`. Blöcke werden nummeriert, nicht mit Buchstaben bezeichnet, damit sie mit keinem Präfix zusammenfallen.

In Fließtext werden keine festen Spannen genannt, die weiterwachsen, also nicht "E-01 bis E-09", sondern "die E-Einträge der Organisation".

## 6. Ablauf: Projekt anlegen

1. **Umfeld lesen.** Vorgänger, installierte Skills derselben Familie und die Dateien, die der Skill als Eingabe nutzt, werden vor jeder Änderung gelesen. Bei einer Übernahme werden alle Selbstbezüge auf den alten Namen gezählt: `name`, H1, Querverweise. Was auffällt, wird in der Organisation als Maßnahme oder im Workplan als Vorüberlegung festgehalten.
2. **Benennen.** Für einen neuen Namen werden drei Alternativen im Schema der vorhandenen Familienpräfixe vorgelegt, bei einer neuen Familie nach Regel 3.8. Die Wahl wird Entscheidung in der Organisation.
3. **Skill anlegen oder übernehmen.** `name`, H1, `description` und Dateinamen im Paket setzen, Version unter `metadata`. Bei einer Übernahme wird der Name an allen gezählten Stellen ersetzt, und der Diff gegen den Vorgänger muss genau diese Stellen zeigen. Danach Validator, Tests und Paketbau. Das Paketwerkzeug benennt die Datei nach dem Skill; sie wird danach nach Regel 3.1 umbenannt.
4. **Ist aufnehmen.** Die Fähigkeiten des Skills werden als Tabelle erfasst, getrennt nach vorhanden, teilweise und fehlend. Grundlage ist die `SKILL.md`, gelesen nach Gliederung und nach Schlüsselbegriffen wie ändern, löschen, suchen, auswerten. Lücken gegenüber dem Namen oder dem erklärten Zweck werden hier sichtbar.
5. **Organisation anlegen** nach der Vorlage Organisation, mit allen fünf Abschnitten und den externen Betriebsdateien. Soll-Punkte sind Kandidaten, keine Entscheidungen, bis der Auftraggeber sie wählt.
6. **Log anlegen** nach der Vorlage Log. L-01 ist die Anlage. Frühere Stände nennt die Einleitung.
7. **Änderungen am Skill.** Jede Änderung wird vor dem Schreiben auf alle betroffenen Stellen hin gesucht, nicht nur nach Schlüsselbegriffen. Eine Umstellung, etwa vom sofortigen Schreiben auf einen Puffer, betrifft auch Regeln, die das alte Verhalten stillschweigend voraussetzen: Nummernvergabe, Korrekturen, Fehlerregeln. Danach gilt Abschnitt 11.
8. **Version setzen** nach Abschnitt 4.
9. **Konsistenzprüfung** nach der Vorlage Konsistenzbericht über den ganzen Dateisatz. Der Bericht wird eingefroren. Seine Erkenntnisse gelten erst als erfasst, wenn sie im Workplan stehen.
10. **Workplan anlegen** mit `science-arbeitsplan-erstellen` und den Zusätzen der Vorlage Workplan, über alle bekannten offenen Punkte, nicht nur über die Befunde der letzten Prüfung. Vorab wird nur gefragt, was den Zuschnitt ändert. Fragen, die nur der Auftraggeber beantworten kann, werden Entscheidungspunkte im Plan.
11. **Nachziehen.** Die Organisation erhält die beteiligten Dateien, Maßnahmen und Entscheidungen, und jede Aktion wird geloggt.

Reihenfolge der Blöcke im Workplan, die sich bewährt hat:

1. Voraussetzungen: Betriebsdateien sichten, bevor entschieden wird (Abschnitt 8.1).
2. Plan berichtigen, falls eine Prüfung Fehler im Plan selbst gefunden hat.
3. Entscheidungen einholen, einzeln.
4. Skill korrigieren, alle Änderungen in einem Zug.
5. Betriebsdateien angleichen und gegebenenfalls zusammenführen (Abschnitt 8.2).
6. Abschluss: Nachprüfung mit neuem Konsistenzlauf, Paketbau, Nachziehen der Organisation.
7. Neue Funktionen, als eigene Etappe im selben Workplan: je Funktion ein Vorhaben mit eigenem Vorspann und den nächsten freien Blocknummern.

## 7. Ablauf: Projekt ergänzen

Vor jeder Ergänzung wird der Stand aufgenommen, nicht angenommen.

1. **Bestand gegen den Dateisatz halten.** Jede Datei des Ausgabeordners wird in der Organisation gesucht, und jede Datei der Organisation im Ausgabeordner. Fehlt eine der Pflichtdateien aus Abschnitt 2, wird sie angelegt.
2. **Namen prüfen** gegen Abschnitt 3 und bei Bedarf nach Regel 3.7 umbenennen.
3. **Log nachtragen.** Rückwirkende Einträge erhalten die Uhrzeit, soweit sie sich aus Dateizeiten feststellen lässt, sonst OFFEN. Die Einleitung nennt, ab wann das Log vollständig ist.
4. **Fortschritt prüfen.** Die Fortschrittstabelle des Workplans wird gegen die tatsächlich erledigten Schritte gehalten.
5. **Vorüberlegungen und Kopfangaben prüfen.** Sie veralten zuerst, weil niemand sie beim Erledigen eines Schritts ansieht.
6. **Kennungen prüfen** gegen Abschnitt 5.
7. **Neue Anforderung einordnen:** Soll-Kandidat in der Organisation, Befund im Workplan, oder beides.
8. **Einarbeiten** nach den Abschnitten 9 und 11, danach Kennungen und Abdeckungstabelle neu zählen.
9. **Konsistenzprüfung** über alle Dateien, dann alle Erkenntnisse in den Workplan übernehmen.

## 8. Betriebsdateien

### 8.1 Sichten

Masterdatei, Zweitfassungen und Protokolle werden angefordert und nur lesend geprüft: Aufbau, Zählungen, Gleichlauf zwischen den Fassungen, Validierungen. Das Ergebnis kommt als Sichtungstabelle in den Workplan, jeder Befund als SB-nn. Die Sichtung liegt vor den Entscheidungen, weil sie Entscheidungspunkte regelmäßig ändert: Eine Zweckentscheidung wird zur Sachentscheidung oder entfällt, wenn die Datei die Frage schon beantwortet.

### 8.2 Zusammenführen

Liegen Teildateien vor, etwa mehrere Protokolle, wird vor dem Zusammenführen geprüft: tatsächlicher Umfang gegen den Dateinamen, Überlappungen auf Wortgleichheit, Lücken gegen den Bestand. Inhalte werden wörtlich übernommen. Formate werden nur angeglichen, wenn der Skill das Format vorschreibt. Fehlende Angaben werden nur aus einer belegten Quelle ergänzt, etwa ein Datum aus dem Erfassungsfeld der Masterdatei. Abgelöste Teildateien bleiben in der Dateiliste der Organisation, mit Verweis auf die Datei, die sie ablöst.

## 9. Pflegeregeln

Jedes Ereignis zieht die genannten Dateien im selben Arbeitsschritt nach.

| Ereignis | Log | Organisation | Workplan |
|---|---|---|---|
| Datei angelegt, umbenannt oder gelöscht | Eintrag | Beteiligte Dateien, Maßnahme | Verweise nachziehen |
| Entscheidung des Auftraggebers | Eintrag der Art Entscheidung, vor der Aktion, die darauf beruht | Entscheidung; Soll-Status nachziehen | Entscheidungspunkt schließen |
| Neue Version | Eintrag | Kopfzeile, Maßnahme, Entscheidung | Kopfzeile Gegenstand |
| Paket gebaut | Eintrag mit Testergebnis und Dateizahl | keine | keine |
| Konsistenzlauf | Eintrag mit Befundzahlen | Beteiligte Dateien | jede Erkenntnis als Schritt, Entscheidungspunkt oder Nachweis; Abdeckungstabelle; Fortschritt |
| Betriebsdateien gesichtet | Eintrag der Art Prüfung | Stand der Dateien | Sichtungstabelle; Befunde wie Konsistenzlauf; Entscheidungspunkte neu einstufen |
| Neue Erkenntnis aus Querprüfung | Eintrag | keine | wie Konsistenzlauf |
| Teildateien zusammengeführt | Eintrag | neue Datei, abgelöste mit Verweis | Verweise nachziehen |
| Workplan-Schritt erledigt | Eintrag | im Abschlussblock: Maßnahme, Entscheidung | Fortschritt; Vorarbeiten zum Schritt entfernen; zugehörige Vorüberlegungen nachziehen |
| Arbeitssitzung endet, oder der Chatverlauf wird zusammengefasst | Eintrag; zuvor Chatprotokoll fortschreiben | Dateiliste beim ersten Protokoll | wiederkehrender Schritt Chatprotokoll |

Ein Befund, der nur in einem Prüfbericht steht, gilt als nicht erfasst.

## 10. Logregeln

### 10.1 Log

1. Ein Eintrag je Aktion, angehängt am Ende.
2. Nach der Ausgabe wird ein Eintrag nicht mehr geändert. Eine Korrektur ist ein neuer Eintrag mit Verweis auf den alten.
3. Jeder Eintrag nennt die betroffenen Dateien und einen Messwert. Platzhalter wie "siehe unten" sind nicht zulässig.
4. Die Uhrzeit ist die Systemzeit beim Schreiben, sonst OFFEN.
5. Eine Entscheidung wird vor der Aktion geloggt, die auf ihr beruht.
6. Arten: Anlegen, Ändern, Umbenennen, Löschen, Version, Paket, Prüfung, Entscheidung. Trifft mehr als eine zu, werden alle genannt.

### 10.2 Chatprotokoll

Es gelten die Regeln von `template-dokumentprojekt`, Abschnitt 11.3, mit der dortigen Vorlage: fortschreiben am Ende jeder Arbeitssitzung und vor jedem Zusammenfassen des Verlaufs; je Eingabe C-nn, Zeit, Wortlaut unverändert, Ergebnis als kurzer Satz ohne Messwerte und Nachweis; nur angehängt; Verlorenes wird benannt. Ein Log-Eintrag, der auf eine Eingabe zurückgeht, nennt deren C-Kennung.

### 10.3 Wortlautvorlagen

Für neuen oder geänderten Wortlaut in `SKILL.md` und den Dateien des Pakets, der nicht mechanisch ist, gelten die Wortlautvorlagen nach `template-dokumentprojekt`, Abschnitt 9: Kennung WV-nn, Ort, voller Wortlaut, Belege, Folgen; eingefügt wird nur der bestätigte Wortlaut, unverändert; eine ergänzte Vorlage wird neu vorgelegt; danach Log mit WV- und C-Kennung und Vergleich mit der Vorlage. Eine Anweisung, ohne Rückfrage zu arbeiten, ersetzt die Vorlage für diesen Auftrag.

## 11. Prüfung nach jedem Schreibvorgang

Jede Änderung an einer Projektdatei wird gemessen, bevor Erfolg gemeldet wird. Gemeldet werden Messwerte, keine Zusicherungen.

| Prüfung | Erwartung |
|---|---|
| Diff je geänderter Datei | entfernte und hinzugefügte Zeilen gezählt; jede entfernte Zeile ist gewollt; Zahl der geänderten Blöcke gleich Zahl der beabsichtigten Änderungen, oder die Abweichung ist erklärt |
| Ersetzungen | mit engstem möglichem Anker ausgeführt |
| Kennungsfolgen je Präfix | lückenlos, ohne Doppelvergabe |
| Tabellen, einzeln | einheitliche Spaltenzahl; Trennzeile an zweiter Stelle; keine Leerzeile innerhalb einer Tabelle |
| Überschriftenliste | unverändert, außer bei beabsichtigter Änderung; Überschriften in Codeblöcken ausgeschlossen |
| Gedankenstriche und `--` außerhalb von Code | 0 |
| Ketten aus drei Umbrüchen, CR-Zeichen | 0 |
| Dateien des Ausgabeordners in der Organisation | alle aufgeführt |
| Alte Dateinamen nach einer Umbenennung | 0 Treffer in allen Projektdateien |
| Tests des Skills | vollständig bestanden |
| Beispielausgaben | bytegleich, solange die Ausgabelogik nicht geändert wurde; sonst neu erzeugen und ansehen |
| Paket | enthält genau die Dateien aus Organisation, Abschnitt 5.1; jede Datei bytegleich mit dem Arbeitsstand |
| Übergabe | nur das Paket, keine einzelne `SKILL.md` daneben; `metadata.version` im Paket gleich der Organisation |
| Eingefügter Wortlaut nach einer Wortlautvorlage | gleich der bestätigten Vorlage; Unterschiede einzeln benannt |
| Wiederherstellungen | wortweiser Vergleich gegen die Quelle; Unterschiede einzeln benannt |
| Chatprotokoll | C-Kennungen lückenlos; jede Eingabe seit dem letzten Eintrag erfasst; jeder Nachweis zeigt auf eine vorhandene Kennung; keine Messwerte in der Spalte Ergebnis |

## 12. Vorlagen

`references/vorlagen.md` enthält die Vorlagen Organisation, Log, Workplan und Konsistenzbericht; die Vorlage Chatprotokoll steht in `template-dokumentprojekt`, Abschnitt 11.3. Die Vorlage wird vor dem Anlegen der Datei gelesen und nicht aus dem Gedächtnis nachgebaut.

## 13. Regeln mit Anlass

| Regel | Anlass |
|---|---|
| Jedes Präfix hat genau eine Bedeutung | "D" stand für vier und "E" für drei Dinge; Sätze, die beide nannten, wurden mehrdeutig |
| Eine Umstellung wird über alle Regeln gesucht, die das alte Verhalten voraussetzen, nicht über Begriffe | Die Nummernvergabe kannte den neuen Puffer nicht, obwohl kein gesuchter Begriff darin vorkam |
| Abbruchkriterien werden gegen den Zielzustand formuliert, nicht gegen den Ist-Zustand | Ein Kriterium erwartete eine Zahl, die schon vor der Korrektur erreicht war, und hätte die korrekte Korrektur als Fehler gemeldet |
| Vorüberlegungen im Workplan werden beim Erledigen der zugehörigen Schritte mitgezogen | Abschnitt 0 meldete ein fehlendes Protokoll, als die Sichtung es längst ausgewertet hatte |
| Betriebsdateien werden vor den Entscheidungen gesichtet | Eine Entscheidung erwies sich nach der Sichtung als bereits beantwortet |
| Dateinamen von Teildateien werden nicht geglaubt, sondern ausgezählt | Eine Datei "51-105" enthielt nur 84 bis 105 |
| Eingefrorene Berichte werden nicht nachgeführt; ihre Aussagen gelten für ihren geprüften Stand | Der erste Bericht nannte eine Zeilenzahl, die sich danach änderte |
| Befunde gelten erst als erfasst, wenn sie im Workplan stehen | Die Befunde der Gesamtprüfung standen zunächst nur im Bericht |
| Ein Projekt hat genau einen Workplan, seine Kennungen laufen über das ganze Projekt | Ein zweiter Workplan für eine neue Funktion vergab SB, EP, AK und Blöcke doppelt; das Log verwies auf gleichlautende Befunde aus zwei Plänen |
| Der Arbeitschat wird regelmäßig als Chatprotokoll geführt, vor jedem Zusammenfassen des Verlaufs | In einem Dokumentprojekt blieb von 30 Eingaben nach dem Zusammenfassen nur die Reihenfolge erhalten; die Arbeitsmuster, aus denen die Skills entstanden, ließen sich nur durch nachträgliches Lesen der Chats gewinnen |
| Übergeben wird nur das vollständige Paket, nie die einzelne `SKILL.md` daneben | Sechs Skills verloren ihre Regeldateien, weil neben dem Paket die einzelne `SKILL.md` übergeben und installiert wurde; zwei Templates verloren beim Speichern über die Vorschlagskarte ihre Versionsangabe |
| Neuer Wortlaut wird als Wortlautvorlage vorgelegt und nur bestätigt eingefügt | In einem Dokumentprojekt gingen zehn Vorlagen so in den Text und wurden vom Auftraggeber ausdrücklich als bewährt bezeichnet; die Regel gilt für den Wortlaut eines Skills ebenso |
