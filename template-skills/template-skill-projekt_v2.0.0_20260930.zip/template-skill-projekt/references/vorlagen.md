# Vorlagen für Skill-Projekte

Gehört zu `template-skill-projekt`. Abschnittsnummern verweisen auf dessen `SKILL.md`.

## Organisation

~~~markdown
# Organisation: <projekt>

Arbeitsdokument zur Weiterentwicklung des Skills. Es wird fortlaufend geführt und gehört nicht in das Skill-Paket.

| Feld | Wert |
|---|---|
| Skill | `<projekt>` |
| Vorgänger | `<name>` <Version>, <Betriebsstatus> |
| Geschwister | `<name>`, <Beziehung> |
| Skill-Version | <volle Version> |
| Versionsträger im Dateinamen | <Hauptversion oder volle Version> |
| Angelegt | <JJJJ-MM-TT> |
| Letzte Änderung | <JJJJ-MM-TT> |

## 1. Was der Skill kann (Ist)

| Nr. | Fähigkeit | Vorhanden | Umfang |
|---|---|---|---|
| I-01 | | ja, teilweise, nein | |

## 2. Was der Skill können soll (Soll)

| Nr. | Kandidat | Bezug | Status |
|---|---|---|---|
| S-01 | | I-nn | offen, gewählt (E-nn), verworfen (E-nn) |

## 3. Was dafür zu tun ist (Maßnahmen)

Die Ausführung der offenen Maßnahmen steuert der Workplan (DAT-nn).

| Nr. | Maßnahme | Status | Datum |
|---|---|---|---|
| M-01 | | offen, erledigt | |

## 4. Entscheidungen

| Nr. | Entscheidung | Datum |
|---|---|---|
| E-01 | | |

## 5. Beteiligte Dateien

### 5.1 Im Skill-Paket

| Datei | Zweck |
|---|---|

### 5.2 Außerhalb des Skill-Pakets

| Nr. | Datei | Art | Rolle | Herkunft | Ort | Stand |
|---|---|---|---|---|---|---|
| DAT-01 | | Arbeitsdokument, Betriebsdatei, abgelöst (DAT-nn) | | | | |
~~~

Ein Vorgänger je Zeile, jeweils mit eigenem Betriebsstatus.

## Log

~~~markdown
# Log: <projekt>

Arbeitsdokument. Fortlaufendes Protokoll der wichtigsten Aktionen am Skill und seinen Begleitdateien. Es gehört nicht in das Skill-Paket. Das Log beginnt mit L-01 am <JJJJ-MM-TT>; frühere Stände stehen in der Organisation.

## Logregel

<Regeln 1 bis 6 aus Abschnitt 10 der SKILL.md>

## Einträge

| Nr. | Datum | Uhrzeit | Art | Aktion | Dateien | Messwert |
|---|---|---|---|---|---|---|
| L-01 | | | Anlegen | | | |
~~~

## Workplan

Der Workplan wird mit `science-arbeitsplan-erstellen` angelegt, mit den Kennungen aus Abschnitt 5. Zusätzlich zu dessen Pflichtteil enthält er:

| Zusatz | Inhalt |
|---|---|
| Kopfzeile Gegenstand | Skill mit voller Version |
| Kopfzeile Grundlage | alle Konsistenzberichte, aus denen Befunde stammen, mit ihren Befundkennungen, und die Organisation |
| Regel Log | Jeder erledigte Schritt wird sofort geloggt. |
| Regel Übernahme | Alle Erkenntnisse aus Prüfungen, Sichtungen und Querprüfungen werden aufgenommen: Befunde als Schritt oder Entscheidungspunkt, offene Punkte als Schritt, Entscheidungspunkt oder Voraussetzung, Nicht-Befunde als Nachweis. |
| Sichtungstabelle | sobald Betriebsdateien gesichtet sind, je Sichtung eine |
| Abschlussblock | Nachprüfung mit neuem Konsistenzlauf, Paketbau, Nachziehen der Organisation |
| Abdeckungstabelle | jede Kennung K, O, N und SB sowie jede offene Maßnahme M genau einmal abgedeckt |
| Vorhaben | je neue Funktion ein Abschnitt mit eigenem Vorspann (Entscheidungen, Lehren, Was schiefgehen kann, Umfang) und den nächsten freien Blocknummern; Entscheidungspunkte, Abdeckung, Abnahme und Fortschritt stehen in den gemeinsamen Abschnitten |
| Konkordanz | wird ein zweiter Workplan übernommen, ordnet eine Tabelle jede alte Kennung der neuen zu; das Log bleibt unverändert und wird über die Konkordanz gelesen |

~~~markdown
#### Sichtung <Schritte> (<JJJJ-MM-TT>)

| Nr. | Prüfpunkt | Befund |
|---|---|---|
| SB-01 | | |

## <n>. Abdeckung der offenen Punkte

| Kennung | Erkenntnis | Quelle | Aufgenommen als |
|---|---|---|---|
| K-01 | | <Konsistenzbericht> | Schritt 4.2 |
~~~

Die Abdeckungstabelle ist die Brücke zwischen Berichten und Plan. "Aufgenommen als" nennt Schritt, Entscheidungspunkt, Voraussetzung oder Nachweis mit Kennung.

## Konsistenzbericht

Der Bericht wird mit `science-interne-konsistenz-pruefung` erstellt. Geprüft wird der ganze Dateisatz, nicht eine einzelne Datei; ein engerer Umfang ist nach Regel 3.4 im Namen kenntlich.

| Dimension | Anwendung auf ein Skill-Projekt |
|---|---|
| D1 Konventionen | Regeln der `SKILL.md` gegen Skript und Tests; Namens-, Versions- und Kennungsregeln von `template-skill-projekt` |
| D2 Selbstbeschreibungen | `description`, `SKILL.md`, `README.md` und Organisation Ist gegen das tatsächliche Verhalten von Skript und Tests |
| D3 Wiederholte Werte | Version, Zahlen, Dateinamen und Kennungen dateiübergreifend; Reihenfolge im Log |
| D4 Quellenbasis | Herkunft der Referenzdaten im Paket und der Eingabedaten |
| D5 Darstellung | alle Markdown-Dateien mit Parser: Tabellen, Listen, Striche |
| D6 Zählungen | Tests, Dateien im Paket, Einträge in Tabellen gegen Angaben im Text |

Ein neuer Lauf setzt die Kennungen des vorigen fort und führt fortbestehende Befunde in einem eigenen Abschnitt, ohne sie neu zu zählen.
