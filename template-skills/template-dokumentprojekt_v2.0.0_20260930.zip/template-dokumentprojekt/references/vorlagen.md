# Vorlagen

Fünf Vorlagen. Jede wird vor dem Anlegen der Datei gelesen und nicht aus dem Gedächtnis nachgebaut. Platzhalter stehen in spitzen Klammern. Die Sprache der Arbeitsdokumente folgt der Sprache des Projekts; weicht sie ab, wird das in den Ablageregeln der Organisation festgehalten.

---

## Vorlage Organisation

Dateiname `<projekt>_Organisation_v<F>_<JJJJMMTT>.md`. Fortlaufend geführt. Sie beantwortet drei Fragen: welche Dateien gehören dazu, wie ist das Ergebnisdokument gebaut, und was gilt für seine Form.

```markdown
# Organisation des Berichts: <projekt>

**Zweck:** Dieses Dokument hält fest, wie der Bericht gegliedert und abgelegt ist, welche Dateien zum Projekt gehören und welche Entscheidungen seine Gestalt betreffen. Inhaltliche Entscheidungen stehen im Entscheidungslog, Aktionen im Log, Befunde im Konsistenzbericht, offene Punkte im Workplan.

**Angelegt:** <JJJJ-MM-TT>. **Stand:** Projektfassung v<F> vom <JJJJ-MM-TT>.

## 0. Projektdateien

### Aktuelle Dateien

| Kennung | Datei | Art | Rolle | Zustand |
|---|---|---|---|---|
| DAT-01 | <Dateiname> | Abgabe oder Arbeitsdokument | <Rolle in einem Satz> | gültig, fortgeschrieben oder eingefroren |

### Noch nicht vorhanden, im Bericht als Platzhalter geführt

| Datei | Rolle |
|---|---|

### Abgelöste Dateien

| Datei | Zustand |
|---|---|

## 1. Umfang

Gemessene Zahlen, keine Schätzungen. Werden vor jeder Entscheidung über Aufteilung oder Umfang neu gezählt.

| Block | Wörter | Abbildungen |
|---|---|---|

## 2. Gliederung des Berichts

Je Kapitel die Abschnitte, ihr Gegenstand und, wo es wiederkehrt, das Muster der Unterabschnitte.

## 3. Entscheidungen zur Gestalt

Nur Entscheidungen, die die Form des Berichts oder die Ordnung der Dateien betreffen. Die Begründung steht im Entscheidungslog und wird hier nicht wiederholt.

| Kennung | Datum | Entscheidung | Beleg |
|---|---|---|---|
| G-01 | <JJJJ-MM-TT> | <Entscheidung in einem Satz> | Entscheidungslog <nn> |

## 4. Dateien und ihre Rollen

Getrennt nach Abgabedateien, Arbeitsdokumenten und eingefrorenen Prüfdokumenten.

## 5. Ablageregeln

| Kennung | Regel |
|---|---|
| R-01 | <Regel> |

Mindestens zu regeln: Fassungswechsel, Verweise, Sprache, Zeichensatz und Trennzeichen der Datentabellen, Umgang mit historischen Aussagen.

## 6. Abbildungen

| Nr. | Ort | Gegenstand | Grundlage | Unterschrift | Offene Punkte |
|---|---|---|---|---|---|

## 7. Offene Punkte

Verweist auf die O-Kennungen des Konsistenzberichts und vergibt keine eigenen.

| Kennung | Gegenstand | Stand |
|---|---|---|

## 8. Änderungsprotokoll

| Datum | Änderung |
|---|---|
```

---

## Vorlage Log

Dateiname `<projekt>_Log_v<F>_<JJJJMMTT>.md`. Ein Eintrag je Aktion, angehängt. Nach der Ausgabe wird ein Eintrag nicht geändert.

```markdown
# <projekt>: Log

Protokoll der Aktionen. Einträge werden angehängt und nach der Ausgabe nicht geändert; eine Korrektur ist ein neuer Eintrag mit Verweis auf den alten. Vollständig ab <JJJJ-MM-TT>; frühere Stände sind aus den Dateien rekonstruiert und tragen die Uhrzeit OFFEN.

| Kennung | Datum | Uhrzeit | Art | Aktion | Betroffene Dateien | Messwert |
|---|---|---|---|---|---|---|
| L-01 | <JJJJ-MM-TT> | <HH:MM> | Anlegen | Projekt angelegt | <Dateien> | <Zahl> |
```

Arten: Anlegen, Ändern, Umbenennen, Löschen, Fassung, Prüfung, Entscheidung. Trifft mehr als eine zu, werden alle genannt. Ein Eintrag der Art Entscheidung trägt in der Spalte Aktion nur Nummer und Gegenstand der Entscheidung und in der Spalte Messwert die Nummer des Eintrags im Entscheidungslog. Der Messwert ist eine Zahl aus der Prüfung nach dem Schreibvorgang, etwa geänderte Zeilen, Zeilen der Datei, Zahl der Befunde, Treffer nach einer Umbenennung.

---

## Vorlage Entscheidungslog

Dateiname `<projekt>_Decision_Log_v<F>_<JJJJMMTT>.md`. Nur Entscheidungen, die über ihren Arbeitsschritt hinaus gelten.

```markdown
# <projekt>: Entscheidungslog

Entscheidungen, die über den Arbeitsschritt hinaus gelten, in dem sie getroffen wurden. Einträge werden angehängt und nach der Ausgabe nicht geändert; eine aufgehobene Entscheidung bleibt stehen und wird durch einen neuen Eintrag mit Rückverweis abgelöst.

Version v<F>, <Datum>.

| Nr. | Datum | Uhrzeit | Gegenstand | Entscheidung | Grund | Betroffene Dateien |
|---|---|---|---|---|---|---|
| 1 | <JJJJ-MM-TT> | <HH:MM> | <Gegenstand> | <was gilt> | <warum, in der Sache> | <Dateien> |
```

Der Grund ist der Teil, der nach Monaten noch gebraucht wird; er nennt die Sachlage, nicht den Arbeitsschritt. Ausführungsdetails stehen im Log. Die Uhrzeit ist die Systemzeit beim Schreiben, sonst OFFEN; ohne sie ist die Reihenfolge gegen das Log nicht herstellbar. Eine Aufhebung sagt ausdrücklich, welcher Teil des alten Eintrags weiter gilt.

---

## Vorlage Workplan

Dateiname `<projekt>_Workplan_v<F>_<JJJJMMTT>.md`. Erstellt mit `science-arbeitsplan-erstellen`, ergänzt um die folgenden Teile.

```markdown
# <projekt>: Workplan

**Gegenstand:** <Ergebnisdokument> in der Fassung v<F> vom <Datum>, mit seinen Begleitdateien.

## 0. Vorüberlegungen

| Kennung | Vorüberlegung | Stand |
|---|---|---|
| V-01 | <Annahme, die sich als falsch erwiesen hat, und ihre Berichtigung> | berichtigt am <Datum> |

Vorüberlegungen werden beim Erledigen der zugehörigen Schritte mitgezogen, sonst melden sie Zustände, die längst geklärt sind.

## 1. Sichtung der Belegunterlagen

| Kennung | Unterlage | Geprüft | Befund |
|---|---|---|---|
| SB-01 | <Datei> | <was geprüft wurde> | <Befund> |

## 2. Blöcke und Schritte

### Block 1: <Titel>

| Schritt | Auftrag | Ergebnis | Abbruchkriterium |
|---|---|---|---|
| 1.1 | <Auftrag> | <prüfbares Ergebnis> | <Bedingung, gegen den Zielzustand formuliert> |
| 1.n | Block abschließen: Fassung setzen, alle Verweise nachziehen, Organisation und Log nachführen | alle Projektdateien auf einer Fassung | ein älterer Dateiname außerhalb einer historischen Aussage |

## 3. Entscheidungspunkte

| Kennung | Frage | Klasse | Vorschlag | Stand |
|---|---|---|---|---|
| EP-01 | <Frage> | Sach- oder Zweckentscheidung | <Vorschlag mit Begründung> | offen oder entschieden am <Datum>, Entscheidungslog <nn> |

## 4. Abdeckung

Jede Erkenntnis aus Prüfläufen, Sichtungen und Querprüfungen mit dem Schritt, der sie erledigt. Eine Erkenntnis ohne Zeile gilt als nicht erfasst.

| Erkenntnis | Herkunft | Schritt oder Entscheidungspunkt |
|---|---|---|
| K-01 | Konsistenzbericht <Datum> | 2.3 |

## 5. Abnahmekriterien

| Kennung | Kriterium | Fehlbar durch |
|---|---|---|
| AK-01 | <messbares Kriterium> | <was es verletzen würde> |

## 6. Fortschritt

| Block | Schritte | Erledigt | Offen |
|---|---|---|---|
```

Abbruch- und Abnahmekriterien werden gegen den Zielzustand formuliert, nicht gegen den Ist-Zustand, sonst meldet ein Kriterium die richtige Korrektur als Fehler.

---

## Vorlage Konsistenzbericht

Dateiname `<projekt>_Konsistenzbericht_v<F>_<JJJJMMTT>.md`. Erstellt mit `science-interne-konsistenz-pruefung`. Nach der Ausgabe eingefroren.

```markdown
# Konsistenzbericht: <projekt>

Version v<F>, <Datum>. Der unten genannte geprüfte Stand ist der Stand, auf dem der Lauf durchgeführt wurde, und wird mit der Projektfassung nicht mitgezogen.

**Geprüfter Stand:** <Dateiname mit Fassung>, <Umfang in Zahlen>.
**Geprüfte Dimensionen:** D1 bis D6, in der Reihenfolge <Reihenfolge>.
**Ergebnis:** <Zahl> Befunde, <Zahl> Nicht-Befunde, <Zahl> offene Punkte.

## 1. Zusammenfassung

## 2. Befunde

| Kennung | Dimension | Fundstellen | Befund | Schweregrad | Vorschlag |
|---|---|---|---|---|---|
| K-01 | D3 | <Zeilen oder Abschnitte> | <Befund> | Widerspruch, Unschärfe oder fehlende Ansage | <Vorschlag> |

## 3. Nicht-Befunde

| Kennung | Geprüft | Ergebnis |
|---|---|---|
| N-01 | <Stelle> | <warum es richtig ist> |

## 4. Offene Punkte

| Kennung | Gegenstand | Stand |
|---|---|---|
| O-01 | <Gegenstand> | offen |

## 5. Keine Änderungen

Dieser Lauf berichtet nur. Die Befunde warten auf Freigabe.
```

Nicht-Befunde gehören in den Bericht, besonders Stellen, die wie ein Zählfehler aussehen und keiner sind. Die Kennungen K, N und O laufen über alle Prüfläufe eines Projekts fort; ein neuer Lauf setzt sie fort und beginnt nicht bei 01.
