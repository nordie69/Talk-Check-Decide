---
name: "template-dokumentprojekt"
description: "Legt Dokumentprojekte nach festem Schema an oder ergänzt sie: Dateisatz aus Ergebnisdokument, Datentabelle, Organisation, Entscheidungslog, Konsistenzbericht, Workplan und Chatprotokoll, gemeinsame Projektfassung, Vorrangregeln zwischen Dateien, Kennungen, Wortlautvorlagen, Pflegeregeln und Prüfung nach jedem Schreibvorgang. Immer verwenden bei: Dokumentprojekt anlegen oder ergänzen, Organisation oder Log zu einem Bericht anlegen, mehrere Begleitdateien eines Berichts abgleichen, Versionsstände zusammenführen, Projektdateien eines Berichts prüfen oder nachziehen, Chatprotokoll anlegen oder fortschreiben. Auch triggern, wenn an einem Bericht mit Begleitdateien weitergearbeitet wird und seine Arbeitsdokumente fehlen oder veraltet sind."
metadata:
  version: "2.0.0"
---

# Dokumentprojekt anlegen und ergänzen

## 1. Geltungsbereich

Der Skill gilt für Vorhaben, deren Ergebnis ein Dokument oder ein Satz zusammengehöriger Dokumente ist, begleitet von Arbeitsdokumenten und Belegunterlagen. Typische Fälle sind Berichte, Gutachten, Konzepte, Exkursions- und Prüfberichte. Für Skill-Projekte gilt stattdessen `template-skill-projekt`.

Das Kennzeichen eines Dokumentprojekts ist, dass mehrere Dateien dieselben Tatsachen führen: der Bericht in Fließtext und Tabellen, eine Datentabelle als Export, Belegunterlagen je Gegenstand. Daraus entstehen Widersprüche zwischen Dateien, nicht nur innerhalb einer Datei. Abschnitt 8 regelt sie.

Zwei Fälle.

**Anlegen:** Ein Dokumentprojekt entsteht, oder ein vorhandener Bericht wird übernommen, und es gibt noch keine Projektdateien. Einstieg bei Abschnitt 6.

**Ergänzen:** Ein Projekt besteht, und neue Anforderungen, Befunde oder Dateien kommen hinzu, oder dem Projekt fehlen Dateien, Namensregeln oder Pflegeregeln. Einstieg bei Abschnitt 7, danach an der Stelle des Ablaufs weiter, zu der die Ergänzung gehört.

Zuerst wird der Fall bestimmt. Liegt im Ausgabeordner oder in den Uploads eine Organisation zum Projekt, ist es Ergänzen, sonst Anlegen. Rückfragen werden einzeln gestellt und nur, wenn die Antwort den Zuschnitt ändert.

Zusammenspiel: Konsistenzberichte erstellt `science-interne-konsistenz-pruefung`, Workplans `science-arbeitsplan-erstellen` ab Version 2.0.0, Quellenprüfungen `science-quellenapparat-pruefung`, Änderungen über mehrere Fundstellen `science-aenderungsfortpflanzung`. Die Vorlagen für Organisation, Log, Workplan und Konsistenzbericht stehen in `references/vorlagen.md` und werden vor dem Anlegen der jeweiligen Datei gelesen.

Platzhalter stehen in spitzen Klammern. `<projekt>` ist der Projektname, etwa `Norway`. `<F>` ist die Projektfassung. `<JJJJMMTT>` ist das Datum dieser Fassung.

## 2. Dateisatz

| Datei | Name | Art | Zweck | Pflicht ab |
|---|---|---|---|---|
| Ergebnisdokument | `<projekt>_<Titel>_v<F>_<JJJJMMTT>.md` | Abgabe | der Bericht selbst | Anlage |
| Datentabelle | `<projekt>_<Gegenstand>_v<F>_<JJJJMMTT>.csv` | Abgabe | maschinenlesbarer Auszug, Grundlage der Abbildungen | sobald Abbildungen oder Karten aus Daten entstehen |
| Organisation | `<projekt>_Organisation_v<F>_<JJJJMMTT>.md` | Arbeitsdokument, fortlaufend | Dateien, Gliederung, Entscheidungen zur Gestalt, Ablageregeln, offene Punkte | Anlage |
| Log | `<projekt>_Log_v<F>_<JJJJMMTT>.md` | Arbeitsdokument, fortlaufend | Protokoll der Aktionen | Anlage, erster Eintrag ist die Anlage selbst |
| Entscheidungslog | `<projekt>_Decision_Log_v<F>_<JJJJMMTT>.md` | Arbeitsdokument, fortlaufend, nur angehängt | Entscheidungen, die über ihren Arbeitsschritt hinaus gelten | erste Entscheidung mit Regelcharakter |
| Konsistenzbericht | `<projekt>_Konsistenzbericht_v<F>_<JJJJMMTT>.md` | Arbeitsdokument, eingefroren | Befunde eines Prüflaufs; wird nach der Ausgabe nicht nachgeführt | erster Prüflauf |
| Workplan | `<projekt>_Workplan_v<F>_<JJJJMMTT>.md` | Arbeitsdokument, fortlaufend | steuert die Ausführung aller offenen Punkte | erster Befund oder erste offene Maßnahme |
| Belegunterlagen | `<projekt>_<Art>_v<F>_<JJJJMMTT>.md` | Arbeitsdokument, fortlaufend | Bibliographie, Recherche, Quellenbilanz, Grunddaten, Entwürfe | sobald vorhanden |
| Chatprotokoll | `<projekt>_Chatprotokoll_v<F>_<JJJJMMTT>.md` | Arbeitsdokument, fortlaufend, nur angehängt | jede Eingabe des Auftraggebers im Arbeitschat, mit Ergebnis und Nachweis | erste Arbeitssitzung |

Abgabedateien beschreiben nur den Ist-Zustand. Entstehungsvermerke, Statusspalten, Erledigungsvermerke und Hinweise auf frühere Fassungen gehören ausschließlich in die Arbeitsdokumente. Was im Ergebnisdokument offen ist, zeigen die Marker OFFEN und UNKLAR und die Platzhalter der Abbildungen, nicht ein Statusapparat.

Log und Entscheidungslog sind zwei Dateien mit zwei Zwecken. Das Log führt Aktionen, auch solche ohne Regelcharakter. Das Entscheidungslog führt nur, was über den Arbeitsschritt hinaus gilt, und ist deshalb lesbar geblieben, wenn jemand nach einem halben Jahr fragt, warum etwas so ist.

Der Arbeitschat ist der Ort der Arbeit, aber kein Nachweis: Er wird lang, wird beim Überlaufen zusammengefasst und lässt sich nicht zitieren. Alles, was zählt, verlässt deshalb den Chat und liegt in einer Projektdatei, die gelesen, geprüft und exportiert werden kann: Ergebnisse, Prüfberichte, Entscheidungen, Zahlen. Das Chatprotokoll schließt die letzte Lücke, den Weg von der Eingabe des Auftraggebers zur Datei. Ein Wert, der nur im Chat genannt wurde, gilt als nicht belegt.

Log und Chatprotokoll teilen sich die Arbeit ohne Doppelung. Das Log führt, was an den Dateien getan wurde, mit Messwert. Das Chatprotokoll führt, was der Auftraggeber gesagt hat, im Wortlaut, und sagt in einem kurzen Satz ohne Messwerte, was daraus wurde; für alles Weitere verweist es auf die Log-Einträge. Das Log wiederum gibt den Wortlaut des Auftraggebers nicht wieder, sondern nennt die C-Kennung als Anlass. Eine Eingabe, die zu keiner Aktion führt, etwa eine Frage, steht nur im Chatprotokoll; eine Aktion ohne Eingabe, etwa eine mechanische Korrektur, steht nur im Log.

## 3. Namensregeln

1. Schema `<projekt>_<Art>_v<F>_<JJJJMMTT>.<Endung>`. Der Projektname steht immer voran.
2. Zwischen den Namensteilen steht `_`. Innerhalb der Art bleiben Großbuchstaben am Wortanfang, Leerzeichen gibt es nicht.
3. Das Datum steht in umgekehrter Form und ist das Datum der Fassung, nicht das der letzten Bearbeitung einer einzelnen Datei.
4. Prüft ein Konsistenzbericht einen anderen Umfang als den ganzen Dateisatz, steht der Umfang als Zusatz nach der Art. Entsteht am selben Tag eine zweite Datei mit gleichem Namen, erhält sie den Zusatz `_HHMM` nach dem Datum. Vorhandene Dateien werden dafür nicht umbenannt.
5. Ist der Kern des Namens zugleich die Art, etwa `<projekt>_Localities`, entfällt der Artzusatz.
6. Eine Datei ohne Fassung im Namen ist im Ordner nicht von einer überholten zu unterscheiden. Deshalb trägt jede Projektdatei die Fassung, auch die Organisation und auch Dateien, die fortgeschrieben statt versioniert werden.
7. Beim Umbenennen werden alle Verweise in allen Projektdateien nachgezogen, die alten Dateien aus dem Ausgabeordner entfernt, und die Umbenennung wird geloggt. Danach muss die Suche nach jedem alten Namen 0 Treffer ergeben.
8. Abbildungs- und Anlagendateien, die das Ergebnisdokument einbindet, tragen dieselbe Fassung wie das Dokument, das sie einbindet.

## 4. Fassungen

Alle Projektdateien tragen dieselbe Fassungsnummer und dasselbe Datum, auch die unveränderten. Die Fassung wird beim Zusammenführen für alle Dateien gemeinsam hochgezählt. Zählt jede Datei für sich, ist nach wenigen Runden aus keinem Dateinamen mehr zu erkennen, welche Stände zusammengehören.

Die Fassung wechselt am Ende eines Blocks des Workplans oder auf Weisung des Auftraggebers, nicht nach jeder einzelnen Runde von Änderungen. Zwischen zwei Fassungen sammeln sich die Änderungen unter dem aktuellen Namen; welche Datei wann geändert wurde, zeigt das Log mit seiner Uhrzeit. Jeder Block des Workplans endet deshalb mit einem Schritt, der die Fassung setzt. Nach einem Fassungswechsel werden alle Projektdateien vorgelegt, zwischen zwei Fassungen nur die geänderten.

Wird ein Projekt auf die gemeinsame Zählung umgestellt, wird als erste gemeinsame Fassung die höchste bisher vergebene Zahl plus eins gewählt, damit keine Nummer zweimal belegt ist.

Bei jedem Fassungswechsel werden alle Fundstellen gezählt und nachgezogen:

| Fundstelle | Form |
|---|---|
| Dateinamen aller Projektdateien | `v<F>_<JJJJMMTT>` |
| Kopfzeile jeder Datei | `Version v<F>, <Datum>` |
| Verweise einer Datei auf eine andere | Name mit Fassung |
| Platzhalter für Abbildungen und Anlagen | Name mit Fassung |
| Datentabellen ohne Kopfzeilenfeld | nur der Dateiname; die Fassung wird zusätzlich in der Organisation vermerkt |

Nicht mitgezogen werden Aussagen über vergangene Vorgänge: Versionshistorien, Einträge des Entscheidungslogs, die eine damalige Fassung nennen, und die Angabe im Konsistenzbericht, auf welchem Stand der Lauf stattfand. Was gilt, wandert mit; was war, bleibt stehen. Dass eine solche Stelle bewusst nicht gezogen wurde, wird in der betroffenen Datei in einem Satz festgehalten, damit die Auslassung nicht als Versäumnis gelesen wird.

Weichen Fundstellen nach dem Wechsel voneinander ab, kommt die Angleichung als Schritt in den Workplan.

## 5. Kennungen

Jedes Präfix hat genau eine Bedeutung, über alle Projektdateien hinweg. Jede Kennung wird vor der Vergabe gegen dieses Register und gegen die vorhandenen Projektdateien geprüft. Nummern werden zweistellig geführt.

| Kennung | Datei | Bedeutung | Nummerierung |
|---|---|---|---|
| DAT-nn | Organisation | Projektdatei | fortlaufend, abgelöste bleiben mit Verweis stehen |
| G-nn | Organisation | Entscheidung zur Gestalt, mit Verweis auf den Eintrag im Entscheidungslog | fortlaufend |
| R-nn | Organisation | Ablageregel | fortlaufend |
| L-nn | Log | Eintrag | fortlaufend |
| C-nn | Chatprotokoll | Eingabe des Auftraggebers | fortlaufend über alle Sitzungen und Chats des Projekts |
| WV-nn | Chat, Log, Workplan | Wortlautvorlage nach Abschnitt 9 | fortlaufend über das Projekt, auch für verworfene und ersetzte Vorlagen |
| D-nn | Entscheidungslog | Entscheidung | fortlaufend, abgelöste bleiben stehen und werden durch einen neuen Eintrag mit Rückverweis aufgehoben |
| K-nn, N-nn, O-nn | Konsistenzbericht | Befund, Nicht-Befund, offener Punkt | fortlaufend über alle Prüfläufe; ein neuer Lauf setzt die Nummern fort |
| V-nn | Workplan | korrigierte Vorüberlegung | je Workplan |
| SB-nn | Workplan | Befund aus einer Sichtung oder Querprüfung | je Workplan |
| EP-nn, EP-nn Z | Workplan | Entscheidungspunkt, Sach- oder Zweckentscheidung | je Workplan |
| AK-nn | Workplan | Abnahmekriterium | je Workplan |
| Block 1, Schritt 1.1 | Workplan | Block und Schritt | je Workplan |

Die Dimensionen D1 bis D6 sind feste Bezeichnungen aus `science-interne-konsistenz-pruefung`. Weil D dort schon vergeben ist, tragen Entscheidungen im Entscheidungslog zwar die Kennung D-nn, werden im Fließtext aber immer als "Entscheidung nn" genannt, nie als "D-nn", und Entscheidungspunkte des Workplans heißen EP. Blöcke werden nummeriert, nicht mit Buchstaben bezeichnet, damit sie mit keinem Präfix zusammenfallen.

Offene Punkte gehören in den Konsistenzbericht, in dem sie entstanden sind, und werden von dort in den Workplan übernommen. Führt die Organisation eine Sammelliste, verweist sie auf die O-Kennungen und vergibt keine eigenen.

In Fließtext werden keine festen Spannen genannt, die weiterwachsen, also nicht "D-01 bis D-09", sondern "die Einträge des Entscheidungslogs".

## 6. Ablauf: Projekt anlegen

1. **Umfeld lesen.** Vorgängerberichte, Mustervorlagen und die Unterlagen, aus denen das Dokument entsteht, werden vor jeder Änderung gelesen. Wird ein Muster aus einem anderen Projekt übernommen, wird jede Konvention des Musters einzeln geprüft, statt sie mitzunehmen; eine übernommene Konvention, die der eigenen Regel widerspricht, ist die häufigste Fehlerquelle beim Anlegen.
2. **Benennen.** Projektname, Titel des Ergebnisdokuments und die Arten der Begleitdateien werden festgelegt und als Entscheidung im Entscheidungslog festgehalten.
3. **Ergebnisdokument anlegen oder übernehmen.** Gliederung, Kopfangaben und Fassungszeile setzen. Bei einer Übernahme werden alle Selbstbezüge auf den alten Namen gezählt und ersetzt, und der Diff muss genau diese Stellen zeigen.
4. **Ist aufnehmen.** Der Umfang wird gemessen, nicht geschätzt: Wortzahlen je Kapitel, Zahl der Abbildungen und Tabellen, Zahl der Abschnitte, Zahl der Belegstellen. Diese Zahlen tragen später jede Entscheidung über Aufteilung und Umfang.
5. **Organisation anlegen** nach der Vorlage Organisation, mit allen Abschnitten und allen Dateien des Ausgabeordners.
6. **Log anlegen** nach der Vorlage Log. L-01 ist die Anlage. Frühere Stände nennt die Einleitung.
7. **Entscheidungslog anlegen**, sobald die erste Entscheidung mit Regelcharakter fällt. Entscheidungen zur Benennung aus Schritt 2 sind bereits solche.
8. **Fassung setzen** nach Abschnitt 4.
9. **Konsistenzprüfung** mit `science-interne-konsistenz-pruefung` über den ganzen Dateisatz. Der Bericht wird nach der Ausgabe eingefroren. Seine Erkenntnisse gelten erst als erfasst, wenn sie im Workplan stehen.
10. **Workplan anlegen** mit `science-arbeitsplan-erstellen` und den Zusätzen der Vorlage Workplan, über alle bekannten offenen Punkte, nicht nur über die Befunde der letzten Prüfung. Fragen, die nur der Auftraggeber beantworten kann, werden Entscheidungspunkte im Plan.
11. **Nachziehen.** Die Organisation erhält die beteiligten Dateien, die Entscheidungen zur Gestalt und die Ablageregeln, und jede Aktion wird geloggt.

Reihenfolge der Blöcke im Workplan, die sich bewährt hat:

1. Voraussetzungen: Belegunterlagen sichten, bevor entschieden wird (Abschnitt 8.1).
2. Plan berichtigen, falls eine Prüfung Fehler im Plan selbst gefunden hat.
3. Entscheidungen einholen, einzeln.
4. Ergebnisdokument korrigieren, nach Befundklassen gebündelt (Abschnitt 9).
5. Datentabelle und Belegunterlagen angleichen (Abschnitt 8.2).
6. Abschluss: Nachprüfung mit neuem Konsistenzlauf, Fassungswechsel, Nachziehen der Organisation.
7. Neue Kapitel oder Gegenstände, als eigene Etappe mit eigenem Workplan.

## 7. Ablauf: Projekt ergänzen

Vor jeder Ergänzung wird der Stand aufgenommen, nicht angenommen. Wer eine gelieferte Datei ohne Bestandsaufnahme einarbeitet, überschreibt regelmäßig eine frühere Entscheidung.

1. **Bestand gegen den Dateisatz halten.** Jede Datei des Ausgabeordners wird in der Organisation gesucht, und jede Datei der Organisation im Ausgabeordner. Fehlt eine der Pflichtdateien aus Abschnitt 2, wird sie angelegt.
2. **Gelieferte Fassungen gegen das Entscheidungslog halten.** Bringt eine neue Fassung einen Wert oder eine Ordnung, die einer Entscheidung widerspricht, wird das als Kollision gemeldet und nicht stillschweigend übernommen. Die Meldung nennt Datei, Stelle, alten und neuen Wert und die Nummer der betroffenen Entscheidung.
3. **Namen prüfen** gegen Abschnitt 3, Fassungen gegen Abschnitt 4, und bei Bedarf nach Regel 3.7 umbenennen.
4. **Verweise prüfen.** Jeder Verweis einer Datei auf eine andere wird gegen den tatsächlichen Stand gehalten.
5. **Log nachtragen.** Rückwirkende Einträge erhalten die Uhrzeit, soweit sie sich aus Dateizeiten feststellen lässt, sonst OFFEN. Die Einleitung nennt, ab wann das Log vollständig ist.
6. **Fortschritt prüfen.** Die Fortschrittstabelle des Workplans wird gegen die tatsächlich erledigten Schritte gehalten.
7. **Vorüberlegungen und Kopfangaben prüfen.** Sie veralten zuerst, weil niemand sie beim Erledigen eines Schritts ansieht.
8. **Kennungen prüfen** gegen Abschnitt 5.
9. **Neue Anforderung einordnen:** Entscheidung im Entscheidungslog, Befund im Workplan, oder beides.
10. **Einarbeiten** nach den Abschnitten 9 und 11, danach Kennungen und Abdeckungstabelle neu zählen.
11. **Konsistenzprüfung** über alle Dateien, dann alle Erkenntnisse in den Workplan übernehmen.

## 8. Belegunterlagen und Datentabellen

### 8.1 Sichten

Bibliographie, Rechercheunterlagen, Quellenbilanz, Grunddaten und Datentabellen werden angefordert und zuerst nur lesend geprüft: Aufbau, Zählungen, Gleichlauf zwischen den Fassungen, Feldtrennung und Quotierung bei Tabellen. Das Ergebnis kommt als Sichtungstabelle in den Workplan, jeder Befund als SB-nn. Die Sichtung liegt vor den Entscheidungen, weil sie Entscheidungspunkte regelmäßig ändert: Eine Zweckentscheidung wird zur Sachentscheidung oder entfällt, wenn die Unterlage die Frage schon beantwortet.

### 8.2 Vorrang zwischen Dateien

Führen zwei Dateien dieselbe Tatsache und widersprechen sich, wird nicht jeder Widerspruch einzeln entschieden, sondern einmal, welche Datei in dieser Sache führt. Die Vorrangregel kommt als Entscheidung ins Entscheidungslog und schließt damit auch den nächsten Widerspruch derselben Art.

Vorrang wird je Sache festgelegt, nicht je Datei. Eine Datei kann bei den Sachangaben führen und bei der Reihenfolge nicht. Eine Vorrangregel schließt nur die Klasse, die sie benennt; was sie nicht nennt, bleibt offen und gehört in den Workplan.

Vor dem Angleichen wird die Herkunft des abweichenden Werts erfragt, nicht seine Richtigkeit beurteilt. Stammt er aus einer neuen Auswertung, folgt die führende Datei ihm; ist er vorläufig gesetzt, wird er zurückgesetzt. Dieselbe Abweichung führt je nach Antwort zu entgegengesetzten Arbeitsgängen, deshalb steht die Frage vor der Korrektur.

Wird ein Wert angeglichen, wird auch sein Beleg angeglichen. Ein Wert aus der führenden Datei ohne den dort zitierten Beleg ist nur halb übernommen.

Lässt sich ein Beleg nicht bestätigen, bleibt er stehen und trägt UNKLAR, mit einem Satz darüber, was geprüft wurde und was offen blieb. Er wird nicht entfernt: Eine Quelle, die der Autor einmal eingetragen hat, ist ein Hinweis, auch wenn sie sich im Augenblick nicht nachweisen lässt, und ihr stilles Verschwinden lässt sich später nicht mehr von einem Versehen unterscheiden. Ist eine Seite maschinell nicht abrufbar, wird das mit gesagt, damit der nächste Versuch nicht dieselbe Sackgasse läuft.

### 8.3 Zusammenführen

Liegen Teildateien vor, wird vor dem Zusammenführen geprüft: tatsächlicher Umfang gegen den Dateinamen, Überlappungen auf Wortgleichheit, Lücken gegen den Bestand. Inhalte werden wörtlich übernommen. Fehlende Angaben werden nur aus einer belegten Quelle ergänzt. Abgelöste Teildateien bleiben in der Dateiliste der Organisation, mit Verweis auf die Datei, die sie ablöst.

### 8.4 Fremde Abbildungen als Eingabe

Braucht ein Skript Ausschnitte fremder Abbildungen als Eingabe, etwa um eine Karte neu zu zeichnen, gehören die Ausschnitte in den Dateisatz, damit das Skript nachrechenbar bleibt. Sie sind Arbeitsdokumente, tragen Fassung und Datum im Namen wie jede Projektdatei und führen in der Dateitabelle der Organisation Quelle, Abbildungsnummer, Seite und den Vermerk "nicht zur Weitergabe". Die Lizenz jeder Vorlage wird in der Organisation oder im Entscheidungslog festgehalten; ob das neu gezeichnete Ergebnis veröffentlicht wird, entscheidet der Auftraggeber.

### 8.5 Projektskripte aus Testfassungen

Entsteht eine Abbildung zuerst in einem Test aus mehreren Einzelskripten, wird sie für den Dateisatz in ein Projektskript überführt: ein Skript mit Kopfkommentar zu Stufen, Eingaben und Aufruf, Dateinamen nach Abschnitt 3, keine festen Pfade. Das Projektskript wird in einem leeren Verzeichnis neu gerechnet und pixelweise mit der bestätigten Testfassung verglichen. Aufgenommen wird es erst bei 0 abweichenden Pixeln oder wenn jede Abweichung erklärt ist; der Messwert kommt ins Log.

## 9. Befunde abarbeiten

Befunde werden vor der Abarbeitung nach Entscheidungsbedarf sortiert, nicht nach Schwere. Die Sortierung geschieht vollständig vor der ersten Änderung, sonst entsteht die Reihenfolge aus der Bequemlichkeit des Bearbeiters.

| Klasse | Kennzeichen | Vorgehen |
|---|---|---|
| mechanisch | eine bestehende Regel wird angewandt, es gibt nur ein richtiges Ergebnis | ohne Rückfrage ausführen, Messwerte melden |
| bestätigungsbedürftig | das Ergebnis steht fest, aber eine Annahme ist zu bestätigen | eine kurze Bestätigungsfrage mit Vorschlag |
| entscheidungsbedürftig, Sachentscheidung | es gibt eine belegbar bessere Antwort, eine Quelle kann die Frage entscheiden | Möglichkeiten vorlegen, die Quelle nennen, eine Antwort empfehlen |
| entscheidungsbedürftig, Zweckentscheidung | mehrere Fassungen sind sachlich richtig, die Wahl hängt davon ab, was das Ergebnis leisten soll | Folgen auszählen, dann fragen; Kennung EP-nn Z |

Vor jeder Frage werden die Folgen jeder Möglichkeit im Bestand ausgezählt, nicht geschätzt: betroffene Fundstellen, davon zu ändern, abhängige Artefakte, Folgeentscheidungen. Eine Frage ohne Mengenangabe zwingt den Auftraggeber, ins Blaue zu entscheiden. Das Auszählen eines einzelnen Entscheidungspunkts führt `science-entscheidungspunkt-klaeren`. Die Nulloption, also alles so lassen und die Abweichung ansagen, gehört zu den Möglichkeiten und ist oft die billigste.

Verworfene Möglichkeiten werden mit ihren ausgezählten Kosten und dem Grund der Ablehnung im Entscheidungslog festgehalten. Wer nur die getroffene Entscheidung festhält, rollt dieselbe Frage beim nächsten Lauf wieder auf.

Fragen werden einzeln gestellt, die Gesamtzahl darf angekündigt werden. Eine Frage, die Auswahlmöglichkeiten anbietet, steht trotzdem vollständig im Fließtext; sonst kommt sie nicht an.

Ein Vorschlag nennt seine Begründung. Wird er mit der Zahl der Folgeänderungen begründet, wird das ausgesprochen, denn eine Empfehlung nach Änderungskosten sagt nichts darüber, welche Fassung sachlich richtig ist.

Nicht-Befunde werden mit Begründung festgehalten, nicht nur die Beanstandungen. Sonst wird beim nächsten Lauf dieselbe Stelle noch einmal aufgerollt. Das gilt besonders für Stellen, die auf den ersten Blick wie ein Zählfehler aussehen und keiner sind.

Je länger die Abarbeitung dauert, desto weniger sagt ein Prüfbefund über den aktuellen Stand. Zieht sich die Abarbeitung über mehrere Fassungen, wird der Lauf am Ende wiederholt, statt den alten Bericht als Nachweis zu führen.

**Wortlautvorlagen.** Neuer oder geänderter Wortlaut im Ergebnisdokument, der nicht mechanisch ist, wird vor dem Schreiben als Wortlautvorlage vorgelegt. Sie trägt die Kennung WV-nn und nennt den Ort (Abschnitt und Nachbarabsatz), den neuen Wortlaut vollständig, bei einer Ersetzung auch den alten, die Belege mit ihrem Prüfstand und die Folgen: weitere Fundstellen, neue Einträge im Verzeichnis, Zahlen, die sich ändern. Eine Zusammenfassung des geplanten Texts ersetzt die Vorlage nicht, denn bestätigt wird der Wortlaut, nicht die Absicht.

Eingefügt wird nur der bestätigte Wortlaut, unverändert. Auch eine Glättung beim Einfügen ist eine Änderung und braucht eine neue Vorlage. Ergänzt oder ändert der Auftraggeber die Vorlage, wird die neue Fassung als neue WV-Kennung vorgelegt und nicht stillschweigend eingearbeitet. Nach dem Einfügen folgen der Log-Eintrag mit WV-Kennung und der C-Kennung der Bestätigung und die Prüfung nach Abschnitt 12, darunter der Vergleich des eingefügten Texts mit der Vorlage in jeder Fassung des Dokuments.

Weist der Auftraggeber an, ohne Rückfrage zu arbeiten, entfällt die Vorlage für diesen Auftrag. Gewählt wird dann die am besten belegte und am leichtesten rückgängig zu machende Fassung, und jede so geänderte Stelle wird im Log einzeln benannt.

## 10. Pflegeregeln

Jedes Ereignis zieht die genannten Dateien im selben Arbeitsschritt nach.

| Ereignis | Log | Entscheidungslog | Organisation | Workplan |
|---|---|---|---|---|
| Datei angelegt, umbenannt oder gelöscht | Eintrag | nur bei Regelcharakter | Dateiliste | Verweise nachziehen |
| Entscheidung des Auftraggebers | Eintrag der Art Entscheidung, vor der Aktion, die darauf beruht | Eintrag mit Datum, Gegenstand, Entscheidung, Grund, betroffenen Dateien | bei Entscheidungen zur Gestalt eine G-Zeile mit Verweis | Entscheidungspunkt schließen |
| Reine Vereinheitlichung nach bestehender Regel | Eintrag | kein Eintrag | keine | Schritt erledigen |
| Neue Fassung, am Blockende oder auf Weisung | Eintrag | Eintrag, wenn das Fassungsschema selbst betroffen ist | Kopfzeile, Dateiliste | Kopfzeile Gegenstand |
| Konsistenzlauf | Eintrag mit Befundzahlen | keine | beteiligte Dateien | jede Erkenntnis als Schritt, Entscheidungspunkt oder Nachweis; Abdeckungstabelle; Fortschritt |
| Belegunterlagen gesichtet | Eintrag der Art Prüfung | keine | Stand der Dateien | Sichtungstabelle; Befunde wie Konsistenzlauf; Entscheidungspunkte neu einstufen |
| Kollision zwischen gelieferter Fassung und Entscheidung | Eintrag | neuer Eintrag, wenn die Entscheidung geändert wird | keine | Entscheidungspunkt |
| Neue Erkenntnis aus Querprüfung | Eintrag | keine | keine | wie Konsistenzlauf |
| Teildateien zusammengeführt | Eintrag | keine | neue Datei, abgelöste mit Verweis | Verweise nachziehen |
| Workplan-Schritt erledigt | Eintrag | keine | im Abschlussblock die Entscheidungen zur Gestalt | Fortschritt; Vorarbeiten zum Schritt entfernen; zugehörige Vorüberlegungen nachziehen |
| Arbeitssitzung endet, oder der Chatverlauf wird zusammengefasst | Eintrag; zuvor Chatprotokoll fortschreiben | keine | Dateiliste beim ersten Protokoll | wiederkehrender Schritt Chatprotokoll |
| Wortlautvorlage bestätigt | Eintrag mit WV- und C-Kennung und Messwert | nur bei Regelcharakter | keine | Schritt erledigen |
| Prüfergebnis oder Zahl nur im Chat genannt | Eintrag, sobald als Datei abgelegt | keine | Dateiliste | Schritt, bis die Datei vorliegt |

Ein Befund, der nur in einem Prüfbericht steht, gilt als nicht erfasst.

## 11. Logregeln

### 11.1 Log

1. Ein Eintrag je Aktion, angehängt am Ende.
2. Nach der Ausgabe wird ein Eintrag nicht mehr geändert. Eine Korrektur ist ein neuer Eintrag mit Verweis auf den alten.
3. Jeder Eintrag nennt die betroffenen Dateien und einen Messwert. Platzhalter wie "siehe unten" sind nicht zulässig.
   Ausnahme: Ein Eintrag der Art Entscheidung nennt nur Nummer und Gegenstand der Entscheidung und verweist auf das Entscheidungslog. Entscheidung, Grund und betroffene Dateien stehen dort und nur dort, damit nichts doppelt geführt wird.
4. Die Uhrzeit ist die Systemzeit beim Schreiben, sonst OFFEN.
5. Eine Entscheidung wird vor der Aktion geloggt, die auf ihr beruht.
6. Arten: Anlegen, Ändern, Umbenennen, Löschen, Fassung, Prüfung, Entscheidung. Trifft mehr als eine zu, werden alle genannt.

### 11.2 Entscheidungslog

1. Einträge werden angehängt und nach der Ausgabe nicht geändert.
2. Eine aufgehobene Entscheidung bleibt stehen; die Aufhebung ist ein neuer Eintrag, der auf den alten verweist und sagt, welcher Teil weiter gilt.
3. Jeder Eintrag nennt Nummer, Datum, Uhrzeit, Gegenstand, Entscheidung, Grund und betroffene Dateien. Der Grund ist der Teil, der nach Monaten noch gebraucht wird. Ausführungsdetails stehen im Log und werden hier nicht wiederholt.
   Die Uhrzeit ist nötig, weil die Regel, eine Entscheidung vor der auf ihr beruhenden Aktion zu protokollieren, über zwei Dateien hinweg nur über Datum und Uhrzeit prüfbar ist. Fehlt sie, trägt allein die Nummer die Reihenfolge, und bei mehreren Entscheidungen an einem Tag ist sie gegen das Log nicht mehr herstellbar.
4. Eingetragen wird, was über den Arbeitsschritt hinaus gilt. Eine Änderung, die nur eine bestehende Regel anwendet, wird nicht eingetragen.
5. Das Entscheidungslog läuft automatisch mit, im selben Arbeitsgang wie die Änderung, nicht gesammelt am Ende.
6. Entscheidung und Dateiherstellung laufen oft an verschiedenen Stellen. Deshalb wird jede gelieferte Fassung gegen das Entscheidungslog gehalten, siehe Abschnitt 7, Schritt 2. Das Log macht eine überholte Entscheidung sichtbar, es verhindert sie nicht.

### 11.3 Chatprotokoll

1. Fortgeschrieben wird am Ende jeder Arbeitssitzung und vor jedem Zusammenfassen des Chatverlaufs, spätestens wenn es angekündigt wird. Danach sind die Eingaben nur noch in Zusammenfassung vorhanden.
2. Je Eingabe eine Zeile: C-nn, Datum und Uhrzeit (Systemzeit, sonst nur Datum), Eingabe im Wortlaut, Ergebnis, Nachweis. Das Ergebnis ist ein kurzer Satz ohne Messwerte; Messwerte stehen nur im Log. Der Nachweis nennt die Kennung, zu der die Eingabe geführt hat: L-nn, Entscheidung nn, DAT-nn, Schritt oder EP.
3. Der Wortlaut bleibt unverändert, auch mit Tippfehlern und Diktierfehlern. Lange Eingaben werden mit "…" gekürzt. Eine Deutung steht in Klammern dahinter, nie an Stelle des Wortlauts.
4. Uploads, Aufrufe von Skills und kurze Bestätigungen werden wie jede Eingabe erfasst.
5. Zeilen werden angehängt und nach der Ausgabe nicht geändert; eine Korrektur ist eine neue Zeile oder ein Satz im Abschnitt Zahlen. Ausnahme: ein nachweislich falsch wiedergegebener Wortlaut wird berichtigt und die Berichtigung geloggt.
6. Was verloren ist, wird benannt: Ist ein Verlauf bereits zusammengefasst, steht im Kopf, für welche Eingaben nur die Reihenfolge oder nur der Inhalt erhalten ist.
7. Am Ende stehen Zahlen: Eingaben je Teil, kurze Bestätigungen, Uploads, Aufträge ohne Rückfrage.
8. Ein Log-Eintrag, der auf eine Eingabe zurückgeht, nennt deren C-Kennung als Anlass, nicht ihren Wortlaut.

Vorlage, solange `references/vorlagen.md` keine eigene führt:

```
# <projekt>: Chatprotokoll <n>

Arbeitsdokument. Zeitraum, Quelle, Hinweis auf erhaltene und verlorene Angaben.

| Nr. | Zeit | Eingabe des Auftraggebers | Ergebnis | Nachweis |
|---|---|---|---|---|
| C-01 | <JJJJ-MM-TT HH:MM> | "<Wortlaut>" | <was daraus wurde, ohne Messwerte> | <L-nn, Entscheidung nn, DAT-nn> |

## Zahlen
```

## 12. Prüfung nach jedem Schreibvorgang

Jede Änderung an einer Projektdatei wird gemessen, bevor Erfolg gemeldet wird. Gemeldet werden Messwerte, keine Zusicherungen.

| Prüfung | Erwartung |
|---|---|
| Diff je geänderter Datei | entfernte und hinzugefügte Zeilen gezählt; jede entfernte Zeile ist gewollt; Zahl der geänderten Blöcke gleich Zahl der beabsichtigten Änderungen, oder die Abweichung ist erklärt |
| Ersetzungen | mit engstem möglichem Anker ausgeführt, niemals von einem Element bis zum übernächsten |
| Kennungsfolgen je Präfix | lückenlos, ohne Doppelvergabe, und in der Reihenfolge der Kennungen im Dokument; das gilt auch für die eigenen Regeln und Listen der Organisation |
| Abbildungs- und Tabellennummern | lückenlos; jede Nummer im Text hat eine Unterschrift und umgekehrt |
| Nach einer Umnummerierung: Verweise auf Nummern im ganzen Dokument | gesucht wird über alle Kapitel, nicht nur über die, die man beim Ändern im Blick hatte; jede gefundene Nummer liegt im gültigen Bereich, und Nummern aus fremden Zählungen, etwa Lokalitätsnummern zitierter Literatur, sind ausdrücklich ausgenommen |
| Abschnittsliste | unverändert, außer bei beabsichtigter Änderung; Überschriften in Codeblöcken ausgeschlossen |
| Tabellen, einzeln | einheitliche Spaltenzahl; Trennzeile an zweiter Stelle; keine Leerzeile innerhalb einer Tabelle |
| Datentabellen, nach jeder Änderung an einem einzelnen Feld | Zeilen- und Spaltenzahl; jedes Feld mit Trennzeichen im Inhalt quotiert; Zeichensatz und Zeilenende unverändert. Ein eingefügter Wert mit Komma verschiebt sonst genau eine Zeile, und die Datei bleibt lesbar genug, dass es niemandem auffällt |
| Zitate und Belege | jede im Text zitierte Quelle steht im Verzeichnis, jeder Eintrag des Verzeichnisses wird im Text zitiert |
| Marker | Zahl der OFFEN- und UNKLAR-Marker je Datei gezählt |
| Gedankenstriche und `--` außerhalb von Code | 0 |
| Ketten aus drei Umbrüchen, CR-Zeichen | 0 |
| Dateien des Ausgabeordners in der Organisation | alle aufgeführt |
| Alte Dateinamen nach einer Umbenennung | 0 Treffer in allen Projektdateien |
| Verweise auf andere Projektdateien | nennen die aktuelle Fassung, außer bei historischen Aussagen nach Abschnitt 4 |
| Wiederherstellungen | wortweiser Vergleich gegen die Quelle; Unterschiede einzeln benannt |
| Projektskript einer Abbildung, aus einer Testfassung übernommen | in einem leeren Verzeichnis neu gerechnet; pixelweise gleich der bestätigten Fassung, oder jede Abweichung erklärt |
| Eingefügter Wortlaut nach einer Wortlautvorlage | gleich der bestätigten Vorlage, in jeder Fassung des Dokuments, etwa Datei und verbundenem Doc; Unterschiede einzeln benannt |
| Chatprotokoll | C-Kennungen lückenlos; jede Eingabe seit dem letzten Eintrag erfasst; Wortlaut gegen den Verlauf gehalten; jeder Nachweis zeigt auf eine vorhandene Kennung; keine Messwerte in der Spalte Ergebnis |

## 13. Vorlagen

`references/vorlagen.md` enthält die Vorlagen Organisation, Log, Entscheidungslog, Workplan und Konsistenzbericht; die Vorlage Chatprotokoll steht in Abschnitt 11.3. Die Vorlage wird vor dem Anlegen der Datei gelesen und nicht aus dem Gedächtnis nachgebaut.

## 14. Regeln mit Anlass

| Regel | Anlass |
|---|---|
| Log und Entscheidungslog werden getrennt geführt, ohne Doppeleintrag | Ein Entscheidungslog mit einem Eintrag je Aktion wäre nach vierzig Schreibvorgängen nicht mehr lesbar gewesen; ein Projekt ohne Aktionslog verlor dafür zwei Arbeitspläne und eine neue Datei aus dem Bestand, ohne dass es auffiel |
| Beide Protokolle tragen die Uhrzeit | Über zwei Dateien hinweg ist sonst nicht prüfbar, ob die Entscheidung vor der Aktion steht |
| Alle Projektdateien tragen eine gemeinsame Fassung | Zehn Dateien trugen sechs Zählstände von 15 bis 38 und ein Datum, das zwei Wochen alt war; aus keinem Namen ging hervor, was zusammengehört |
| Bei der Umstellung auf die gemeinsame Zählung wird die höchste bisherige Zahl plus eins gewählt | Eine niedrigere Zahl hätte eine bereits vergebene Fassung ein zweites Mal belegt |
| Vorrang wird je Sache entschieden, nicht je Widerspruch | Sechs Abweichungen zwischen Datentabelle und Bericht waren mit einer Vorrangregel erledigt statt mit sechs Einzelentscheidungen |
| Eine Vorrangregel schließt nur die Klasse, die sie benennt | Die Regel zum Vorrang der Dateien regelte die Sachangaben, nicht die Nummerierung; die Nummernkollision blieb offen |
| Vor der Korrektur wird die Herkunft des abweichenden Werts erfragt | Dieselbe Abweichung hätte je nach Herkunft in entgegengesetzte Richtungen korrigiert werden müssen |
| Gelieferte Fassungen werden gegen das Entscheidungslog gehalten | Eine gelieferte Fassung machte eine zwei Schritte alte Entscheidung rückgängig, und die Kollision blieb offen |
| Historische Aussagen werden beim Fassungswechsel nicht mitgezogen | Versionshistorien und die Angabe des geprüften Stands hätten sonst behauptet, sich auf die neue Fassung zu beziehen |
| Eine Konvention aus einem Mustervorhaben wird einzeln geprüft, nicht übernommen | Das Muster führte sein Organisationsdokument ohne Fassung, was der eigenen Regel widersprach und am selben Tag zurückgenommen werden musste |
| Befunde werden nach Entscheidungsbedarf sortiert, vor der ersten Änderung | Sieben Befunde zerfielen in zwei mechanische, zwei bestätigungsbedürftige und drei entscheidungsbedürftige; nur die letzten drei brauchten Aufmerksamkeit |
| Eine Frage mit Auswahlmöglichkeiten steht trotzdem vollständig im Fließtext | Eine Frage stand nur im Auswahlelement und kam nicht an |
| Nicht-Befunde werden mit Begründung festgehalten | Eine Stelle sah wie ein Zählfehler aus und war keiner; ohne Vermerk wird sie beim nächsten Lauf erneut aufgerollt |
| Eingefrorene Berichte werden nicht nachgeführt; ihre Aussagen gelten für ihren geprüften Stand | Der Prüflauf fand auf einer Fassung statt, gearbeitet wurde bis zu einer späteren weiter |
| Befunde gelten erst als erfasst, wenn sie im Workplan stehen | Achtzehn Befunde und neun offene Punkte standen in Prüfbericht und Organisation, in keinem Workplan |
| Felder mit Trennzeichen im Inhalt werden quotiert | Ein Beleg mit zwei Kommata hätte eine Datentabelle um zwei Spalten verschoben |
| Ersetzungen mit engstem möglichem Anker | Ein Verweis stand mitten in einer Tabellenzelle; ein weiter Anker hätte die Zelle zerlegt |
| Vor der Frage werden die Folgen jeder Möglichkeit ausgezählt | Eine Frage nach der Nummerierung einer Lokalität sah nach zwei gleichwertigen Wegen aus; ausgezählt standen 5 Fundstellen gegen 67 gegen 67 plus einen neuen Abschnitt |
| Verworfene Möglichkeiten werden mit ihren Kosten festgehalten | Die verworfene Möglichkeit, die Lokalitätsnummer zur festen Kennung zu machen, hätte jede spätere Richtungsänderung von rund 380 auf rund 48 Stellen gesenkt; ohne diesen Vermerk käme die Frage beim nächsten Mal ohne dieses Wissen wieder |
| Ein unbestätigter Beleg bleibt stehen und trägt UNKLAR | Eine Altersquelle ließ sich nicht nachweisen, weil die Datenbankseite den Abruf blockierte; gelöscht wäre sie später nicht mehr von einem Versehen zu unterscheiden gewesen |
| Nach einer Umnummerierung wird der ganze Bestand durchsucht | Der erste Durchgang ersetzte die Nummernverweise nur in den Kapiteln, an die man beim Ändern denkt; die zweite Prüfung fand acht weitere in den übrigen |
| Die Feldquotierung wird nach jeder Änderung an einer Datentabelle geprüft | Ein neuer Quellenwert enthielt ein Komma und machte aus einer Zeile mit 12 Spalten eine mit 13 |
| Die Fassung wechselt am Blockende oder auf Weisung, nicht nach jeder Runde | Ein Fassungswechsel kostete 15 umbenannte Dateien und 57 Zeilen, die nichts als die Fassung trugen, und fiel an einem Tag dreimal an, ohne dass einer der Zwischenstände gebraucht wurde |
| Die Kennungsprüfung gilt auch für die eigenen Listen der Organisation | Die Ablageregeln standen in der Reihenfolge R-01, R-06, R-08, R-07, R-02 bis R-05, weil zwei von ihnen an den falschen Absatz angehängt worden waren |
| Der Arbeitschat wird regelmäßig als Chatprotokoll geführt, vor jedem Zusammenfassen des Verlaufs | Von 30 Eingaben eines Arbeitschats blieb nach dem Zusammenfassen des Verlaufs nur die Reihenfolge erhalten, keine Uhrzeit; 268 Arbeitsmuster ließen sich nur durch nachträgliches Lesen der Chats gewinnen |
| Prüfergebnisse und Zahlen werden als Datei abgelegt, nicht nur im Chat berichtet | 32 von 117 geprüften Aussagen eines Artikels über zwei Projekte ließen sich nur über ein aus den Chats zusammengestelltes Dossier belegen, zu keinem gespeicherten Prüfbericht |
| Eingaben stehen im Chatprotokoll im Wortlaut, auch mit Tippfehlern | Im ersten Chatprotokoll waren drei Eingaben stillschweigend geglättet und mussten wiederhergestellt werden |
| Das Chatprotokoll führt keine Messwerte, das Log keinen Wortlaut | Im ersten Chatprotokoll standen Befundzahlen, die schon im Log standen; zwei Dateien mit derselben Zahl laufen beim nächsten Nachzählen auseinander |
| Neuer Wortlaut wird als Wortlautvorlage im vollen Text vorgelegt und nur bestätigt eingefügt | In einem Methodenartikel gingen Forschungsfragen und neue Absätze über zehn nummerierte Vorlagen in den Text; der Auftraggeber bestätigte jede einzeln, ergänzte eine vor der Übernahme um einen weiteren Gedanken und nannte das Vorgehen ausdrücklich als bewährt |
| Ergänzt der Auftraggeber eine Vorlage, wird die neue Fassung erneut vorgelegt | Ohne neue Vorlage stünde im Dokument ein Wortlaut, den niemand in dieser Form gesehen hat |
| Tatsachen werden an ihrer Quelle oder in den Projektdateien neu nachgeschlagen, nicht aus dem früheren Chatverlauf übernommen | Ein langer Arbeitschat wird zusammengefasst; von 30 Eingaben blieb danach nur die Reihenfolge erhalten, und was früher im Chat stand, war nicht mehr im Wortlaut prüfbar. Die Regel galt in der Praxis des Auftraggebers, stand aber in keinem Skill, bis eine Querprüfung am 28. September 2026 die Lücke fand |
| Ausschnitte fremder Abbildungen stehen als Eingabe im Dateisatz, mit dem Vermerk "nicht zur Weitergabe" | Eine neu gezeichnete Karte brauchte zwei Ausschnitte aus Zeitschriftenabbildungen ohne offene Lizenz; ohne sie im Satz wäre das Skript nicht nachrechenbar gewesen, ohne Vermerk wären fremde Abbildungen wie eigene weitergegeben worden |
| Ein Projektskript aus Testskripten wird in einem leeren Verzeichnis neu gerechnet und pixelweise geprüft | Acht Testskripte mit Zwischendateien wurden zu einem Skript zusammengeführt; erst 0 abweichende Pixel belegten, dass die aufgenommene Karte die bestätigte ist |
